using TestMinimalWebAPI;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment()) {
  app.UseSwagger();
  app.UseSwaggerUI();
}

app.MapGet("/testsql", () =>
{
  List<Product> list = new();

  try {
    using (AdventureWorksDbContext db = new()) {
      list = db.Products.ToList();
    }
  }
  catch (Exception) {
    throw;
  }

  return list;
});

app.Run();
