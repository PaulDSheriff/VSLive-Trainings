﻿using Microsoft.EntityFrameworkCore;

// TODO: Add the NuGet Package 'Microsoft.EntityFrameworkCore.SqlServer'

namespace TestMinimalWebAPI;

public partial class AdventureWorksDbContext : DbContext
{  
  protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
  {
    optionsBuilder.UseSqlServer(@"Server=Localhost;Database=AdventureWorksLT2019;Trusted_Connection=Yes;MultipleActiveResultSets=true;TrustServerCertificate=True;Application Name=AdventureWorks");
  }

  // Add your DbSet Classes for Tables/Views here
  public virtual DbSet<Product> Products { get; set; }
}
