﻿#nullable disable

using System.Text;

namespace LINQLab;

public class SongStats {
  #region Constructor
  public SongStats() {
    TotalSongs = 0;
    MinRating = int.MaxValue;
    MaxRating = int.MinValue;
    AverageRating = double.MaxValue;
  }
  #endregion

  public int? GenreId { get; set; }
  public int? TotalSongs { get; set; }
  public int? MinRating { get; set; }
  public int? MaxRating { get; set; }
  public double? AverageRating { get; set; }

  #region ToString Override
  public override string ToString() {
    StringBuilder sb = new(1024);

    sb.AppendLine($"Genre: {GenreId}");
    sb.AppendLine($"  Total Songs: {TotalSongs}");
    sb.AppendLine($"  Minimum Rating: {MinRating}");
    sb.AppendLine($"  Maximum Rating: {MaxRating}");
    sb.AppendLine($"  Average Rating: {AverageRating}");

    return sb.ToString();
  }
  #endregion
}
