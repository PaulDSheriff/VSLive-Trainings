﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab02() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    List<IGrouping<int?, Song>> list;

    // Query Syntax
    list = (from row in songs
            group row by row.GenreId into genreGroup
            where genreGroup.Count() >= 10
            orderby genreGroup.Count()
            select genreGroup).ToList();

    // Method Syntax
    //list = songs.GroupBy(row => row.GenreId)
    //            .Where(genreGroup => genreGroup.Count() >= 10)
    //            .OrderBy(genreGroup => genreGroup.Count()).ToList();

    // Loop through each Genre
    foreach (var group in list) {
      // Display the GenreId and the Count of Songs
      Console.WriteLine($"GenreId: {group.Key?.ToString().PadLeft(2)}\tCount: {group.Count()}");
    }

    // Pause for Results
    Console.ReadKey();
  }
}
