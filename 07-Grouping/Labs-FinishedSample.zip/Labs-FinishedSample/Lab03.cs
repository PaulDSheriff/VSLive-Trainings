﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab03() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    List<SongStats> list;

    // Query Syntax
    list = (from row in songs
            group row by row.GenreId into genreGroup
            select new SongStats {
              GenreId = genreGroup.Key,
              TotalSongs = genreGroup.Count(),
              MinRating = genreGroup.Min(row => row.Rating),
              MaxRating = genreGroup.Max(row => row.Rating),
              AverageRating = genreGroup.Average(row => row.Rating)
            }).ToList();

    // Method Syntax
    //list = songs.GroupBy(row => row.GenreId)
    //            .Select(genreGroup => new SongStats {
    //              GenreId = genreGroup.Key,
    //              TotalSongs = genreGroup.Count(),
    //              MinRating = genreGroup.Min(row => row.Rating),
    //              MaxRating = genreGroup.Max(row => row.Rating),
    //              AverageRating = genreGroup.Average(row => row.Rating)
    //            }).ToList();

    // Loop through each SongStat object
    foreach (var stat in list) {
      // Display the statistics in Debug window because of the buffer size on console window
      System.Diagnostics.Debug.WriteLine(stat);
    }
  }
}
