﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab01() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    List<IGrouping<int?, Song>> list;

    // Query Syntax
    list = (from row in songs
            group row by row.GenreId).ToList();

    // Method Syntax
    //list = songs.GroupBy(row => row.GenreId).ToList();

    // Loop through each Genre
    foreach (var group in list) {
      // Display the GenreId and the Count of Songs
      Console.WriteLine($"GenreId: {group.Key}\tCount: {group.Count()}");
    }

    // Pause for Results
    Console.ReadKey();
  }
}
