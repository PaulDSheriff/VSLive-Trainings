﻿#nullable disable

namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// Group products by Size property and calculate min/max/average prices
  /// </summary>
  public static void AggregateUsingGroupByMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<ProductStats> list;

    // Write Method Syntax Here
    list = products.GroupBy(row => row.Size)
                    .Select(sizeGroup => new ProductStats {
                      Size = sizeGroup.Key,
                      TotalProducts = sizeGroup.Count(),
                      MinListPrice = sizeGroup.Min(s => s.ListPrice),
                      MaxListPrice = sizeGroup.Max(s => s.ListPrice),
                      AverageListPrice = sizeGroup.Average(s => s.ListPrice)
                    })
                    .OrderBy(result => result.Size).ToList();

    // Display product stats
    foreach (ProductStats stat in list) {
      Console.Write(stat);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
