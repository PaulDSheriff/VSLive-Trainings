﻿#nullable disable

namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// Use Aggregate() method with a custom class and methods to gather the data in one pass
  /// </summary>
  public static void AggregateMoreEfficientMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<ProductStats> list;

    // Write Method Syntax Here
    list = products.GroupBy(row => row.Size)
            .Where(sizeGroup => sizeGroup.Any())
            .Select(sizeGroup =>
            {
              // Create the accumulator object and set the Size
              ProductStats acc = new() {
                Size = sizeGroup.Key
              };

              // Iterate over the collection one time
              // and calculate all stats for this Size Group
              sizeGroup.Aggregate(acc, (acc, prod) => acc.Accumulate(prod),
                                  acc => acc.ComputeAverage());

              // return the accumulated results
              return acc;
            })
            .OrderBy(result => result.Size).ToList();

    // Display product stats
    foreach (ProductStats stat in list) {
      Console.Write(stat);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
