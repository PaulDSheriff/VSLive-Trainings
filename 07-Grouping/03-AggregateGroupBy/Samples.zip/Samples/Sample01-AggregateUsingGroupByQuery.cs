﻿#nullable disable

namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// Group products by Size property and calculate min/max/average prices
  /// </summary>
  public static void AggregateUsingGroupByQuery() {
    List<Product> products = ProductRepository.GetAll();
    List<ProductStats> list;

    // Write Query Syntax Here
    list = (from row in products
            group row by row.Size
            into sizeGroup
            where sizeGroup.Any()
            select new ProductStats {
              Size = sizeGroup.Key,
              TotalProducts = sizeGroup.Count(),
              MinListPrice = sizeGroup.Min(s => s.ListPrice),
              MaxListPrice = sizeGroup.Max(s => s.ListPrice),
              AverageListPrice = sizeGroup.Average(s => s.ListPrice)
            }
            into result
            orderby result.Size
            select result).ToList();

    // Display product stats
    foreach (ProductStats stat in list) {
      Console.Write(stat);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
