﻿Description of Samples
--------------------------------------------------
01-AggregateUsingGroupByQuery() - Group products by Size property and calculate min/max/average prices
02-AggregateUsingGroupByMethod() - Group products by Size property and calculate min/max/average prices

03-AggregateMoreEfficient() - Use Aggregate() method with a custom class and methods to gather the data in one pass