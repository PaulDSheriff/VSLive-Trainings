﻿using LINQSamples;

// Call Sample Method
Sample01.AggregateUsingGroupByQuery();
//Sample02.AggregateUsingGroupByMethod();
//Sample03.AggregateMoreEfficientMethod();