﻿#nullable disable

namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// Group products by Size property. orderby is optional, but generally used
  /// </summary>
  public static void GroupByQuery() {
    List<Product> products = ProductRepository.GetAll();
    List<IGrouping<string, Product>> list;

    // Write Query Syntax Here
    list = (from row in products
            orderby row.Size
            group row by row.Size).ToList();

    // Loop through each size
    foreach (var group in list) {
      // The value in the 'Key' property is 
      // whatever data you grouped upon
      Console.WriteLine($"Size: {group.Key}  Count: {group.Count()}");

      // Loop through the products in each size
      foreach (Product product in group) {
        Console.Write($"  ProductID: {product.ProductID}");
        Console.Write($"  Name: {product.Name}");
        Console.WriteLine($"  Color: {product.Color}");
      }
    }

    // Pause for Results
    Console.ReadKey();
  }
}
