﻿using LINQSamples;

// Call Sample Method
Sample01.GroupByQuery();
//Sample02.GroupByMethod();
//Sample03.GroupByUsingKeyQuery();
//Sample04.GroupByUsingKeyMethod();
//Sample05.GroupByWhereQuery();
//Sample06.GroupByWhereMethod();