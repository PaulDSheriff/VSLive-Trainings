﻿#nullable disable

namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// After selecting 'into' new variable, can sort on the 'Key' property. Key property has the value of what you grouped on.
  /// </summary>
  public static void GroupByUsingKeyQuery() {
    List<Product> products = ProductRepository.GetAll();
    List<IGrouping<string, Product>> list;

    // Write Query Syntax Here
    list = (from row in products
            group row by row.Size into sizeGroup
            orderby sizeGroup.Key
            select sizeGroup).ToList();

    // Loop through each size
    foreach (var group in list) {
      // The value in the 'Key' property is 
      // whatever data you grouped upon
      Console.WriteLine($"Size: {group.Key}  Count: {group.Count()}");

      // Loop through the products in each size
      foreach (Product product in group) {
        Console.Write($"  ProductID: {product.ProductID}");
        Console.Write($"  Name: {product.Name}");
        Console.WriteLine($"  Color: {product.Color}");
      }
    }

    // Pause for Results
    Console.ReadKey();
  }
}
