﻿#nullable disable

namespace LINQSamples;

public class Sample06 {
  /// <summary>
  /// Group products by Size property and where the group has more than 2 members
  /// This simulates a HAVING clause in SQL
  /// </summary>
  public static void GroupByWhereMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<IGrouping<string, Product>> list;

    // Write Method Syntax Here
    list = products.OrderBy(row => row.Size)
                   .GroupBy(row => row.Size)
                   .Where(sizeGroup => sizeGroup.Count() > 2)
                   .Select(sizeGroup => sizeGroup).ToList();

    // Loop through each size
    foreach (var group in list) {
      // The value in the 'Key' property is 
      // whatever data you grouped upon
      Console.WriteLine($"Size: {group.Key}  Count: {group.Count()}");

      // Loop through the products in each size
      foreach (Product product in group) {
        Console.Write($"  ProductID: {product.ProductID}");
        Console.Write($"  Name: {product.Name}");
        Console.WriteLine($"  Color: {product.Color}");
      }
    }

    // Pause for Results
    Console.ReadKey();
  }
}
