﻿Description of Samples
--------------------------------------------------
01-GroupByQuery() - Group all products by size.
02-GroupByMethod() - Group all products by size.

03-GroupByUsingKeyQuery() - Order by the 'Key' property and use the 'into' keyword
04-GroupByUsingKeyMethod() - Order by the 'Key' property and use the 'into' keyword

05-GroupByWhereQuery() - Search for those sizes with 2 or more products. Simulates a SQL HAVING clause.
06-GroupByWhereMethod() - Search for those sizes with 2 or more products. Simulates a SQL HAVING clause.
