﻿#nullable disable

namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// Group Sales by SalesOrderID, add Products into new Sales Order object using a subquery
  /// </summary>
  public static void GroupBySubQueryQuery() {
    List<Product> products = ProductRepository.GetAll();
    List<SalesOrder> sales = SalesOrderRepository.GetAll();
    List<SaleProducts> list;

    // Write Query Syntax Here
    list = (from row in sales
            orderby row.SalesOrderID
            group row by row.SalesOrderID into orderGroup
            select new SaleProducts {
              SalesOrderID = orderGroup.Key,
              Products = (from productRow in products
                          orderby productRow.ProductID
                          join salesRow in sales
                            on productRow.ProductID equals salesRow.ProductID
                          where salesRow.SalesOrderID == orderGroup.Key
                          select productRow).ToList()
            }).ToList();

    // Display Sales
    foreach (SaleProducts sale in list) {
      Console.WriteLine($"Sales ID: {sale.SalesOrderID}");

      if (sale.Products.Count > 0) {
        // Loop through the products in each sale
        foreach (Product prod in sale.Products) {
          Console.Write($"  ProductID: {prod.ProductID}");
          Console.Write($"  Name: {prod.Name}");
          Console.WriteLine($"  Color: {prod.Color}");
        }
      }
      else {
        Console.WriteLine("   Product ID not found for this sale.");
      }
    }

    Console.WriteLine();
    Console.WriteLine($"Total Sales: {sales.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
