﻿#nullable disable

namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// Group Sales by SalesOrderID, add Products into new Sales Order object using a subquery
  /// </summary>
  public static void GroupBySubQueryMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<SalesOrder> sales = SalesOrderRepository.GetAll();
    List<SaleProducts> list;

    // Write Method Syntax Here
    list = sales.OrderBy(row => row.SalesOrderID)
                .GroupBy(row => row.SalesOrderID)
                .Select(orderGroup => new SaleProducts {
                  SalesOrderID = orderGroup.Key,
                  Products = products.OrderBy(productRow => productRow.ProductID)
                    .Join(orderGroup, productRow => productRow.ProductID,
                          salesRow => salesRow.ProductID,
                          (productRow, salesRow) => productRow).ToList()
                }).ToList();


    // Display Sales
    foreach (SaleProducts sale in list) {
      Console.WriteLine($"Sales ID: {sale.SalesOrderID}");

      if (sale.Products.Count > 0) {
        // Loop through the products in each sale
        foreach (Product prod in sale.Products) {
          Console.Write($"  ProductID: {prod.ProductID}");
          Console.Write($"  Name: {prod.Name}");
          Console.WriteLine($"  Color: {prod.Color}");
        }
      }
      else {
        Console.WriteLine("   Product ID not found for this sale.");
      }
    }

    Console.WriteLine();
    Console.WriteLine($"Total Sales: {sales.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
