﻿using LINQSamples;

// Call Sample Method
Sample01.GroupBySubQueryQuery();
//Sample02.GroupBySubQueryMethod();