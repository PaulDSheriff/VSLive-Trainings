﻿Description of Samples
--------------------------------------------------
01-GroupedSubqueryQuery() - Group Sales by SalesOrderID, add Products into new Sales Order object using a subquery.
02-GroupedSubqueryMethod() - Group Sales by SalesOrderID, add Products into new Sales Order object using a subquery.