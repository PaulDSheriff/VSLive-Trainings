﻿#nullable disable

using System.Xml.Linq;

namespace Samples;

public class Lab02 {
  public static void WhereClause() {
    XElement elem = XElement.Load(FileNameHelper.SongsFile);
    List<XElement> list;

    // Query Syntax
    list = (from row in elem.Elements("Song")
            where row.Element("GenreId").Value == "30"
            select row).ToList();

    // Method Syntax
    //list = elem.Elements("Song")
    //  .Where(row => row.Element("GenreId").Value == "30").ToList();

    // Display Songs
    foreach (XElement row in list) {
      Console.WriteLine(row);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Songs: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
