﻿using Samples;

// Run the Lab
Lab01.GetAll();
//Lab02.WhereClause();
//Lab03.OrderBy();
//Lab04.CreateClass();