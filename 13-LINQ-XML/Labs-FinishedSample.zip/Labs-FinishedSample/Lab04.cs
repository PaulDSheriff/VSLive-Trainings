﻿#nullable disable

using System.Xml.Linq;

namespace Samples;

public class Lab04 {
  public static void CreateClass() {
    XElement elem = XElement.Load(FileNameHelper.SongsFile);
    List<Song> list;

    // Query Syntax
    list = (from row in elem.Elements("Song")
            orderby row.GetAs<string>("SongName")
            select new Song {
              SongId = row.GetAs<int>("SongId"),
              SongName = row.GetAs<string>("SongName", "n/a"),
              Artist = row.GetAs<string>("Artist"),
              Album = row.GetAs<string>("Album", "n/a"),
              GenreId = row.GetAs<int>("GenreId"),
              KindId = row.GetAs<int>("KindId"),
              TrackNumber = row.GetAs<string>("TrackNumber", "n/a"),
              Rating = row.GetAs<int>("Rating"),
              Year = row.GetAs<int>("Year"),
              ReleaseDate = row.GetAs<DateTime>("ReleaseDate"),
              Plays = row.GetAs<int>("Plays"),
              DateAdded = row.GetAs<DateTime>("DateAdded")
            }).ToList();

    // Method Syntax
    //list = elem.Elements("Song")
    //  .OrderBy(row => row.Element("SongName").Value)
    //  .Select(row => new Song {
    //    SongId = row.GetAs<int>("SongId"),
    //    SongName = row.GetAs<string>("SongName", "n/a"),
    //    Artist = row.GetAs<string>("Artist"),
    //    Album = row.GetAs<string>("Album", "n/a"),
    //    GenreId = row.GetAs<int>("GenreId"),
    //    KindId = row.GetAs<int>("KindId"),
    //    TrackNumber = row.GetAs<string>("TrackNumber", "n/a"),
    //    Rating = row.GetAs<int>("Rating"),
    //    Year = row.GetAs<int>("Year"),
    //    ReleaseDate = row.GetAs<DateTime>("ReleaseDate"),
    //    Plays = row.GetAs<int>("Plays"),
    //    DateAdded = row.GetAs<DateTime>("DateAdded")
    //  }).ToList();

    // Display Songs
    foreach (Song row in list) {
      Console.WriteLine(row);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Songs: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
