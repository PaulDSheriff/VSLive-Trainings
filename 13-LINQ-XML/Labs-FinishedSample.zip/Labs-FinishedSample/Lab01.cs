﻿using System.Xml.Linq;

namespace Samples;

public class Lab01 {
  public static void GetAll() {
    XElement elem = XElement.Load(FileNameHelper.SongsFile);
    List<XElement> list;

    // Query Syntax
    list = (from row in elem.Elements("Song")
            select row).ToList();

    // Method Syntax
    //list = elem.Elements("Song").ToList();

    // Display Songs
    foreach (XElement row in list) {
      Console.WriteLine(row);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Songs: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
