﻿#nullable disable

using System.Xml.Linq;

namespace Samples;

public class Lab03 {
  public static void OrderBy() {
    XElement elem = XElement.Load(FileNameHelper.SongsFile);
    List<XElement> list;

    // Query Syntax
    list = (from row in elem.Elements("Song")
            where row.Element("GenreId").Value == "30"
            orderby row.Element("SongName").Value
            select row).ToList();

    // Method Syntax
    //list = elem.Elements("Song")
    //  .Where(row => row.Element("GenreId").Value == "30")
    //  .OrderBy(row => row.Element("SongName").Value).ToList();

    // Display Songs
    foreach (XElement row in list) {
      Console.WriteLine(row);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Songs: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
