﻿#nullable disable

using System.Xml.Linq;

namespace XmlSamples;

public class Sample04 {
  /// <summary>
  /// Get a single node of XML data
  /// </summary>
  public static void GetSingleNode() {
    XElement elem = XElement.Load(FileNameHelper.ProductsFile);
    XElement product;

    // Write Query Syntax Here
    product = (from row in elem.Elements("Product")
               where row.Element("ProductID").Value == "706"
               select row).SingleOrDefault();

    // Display products
    if (product != null) {
      Console.WriteLine(product);
    }
    else {
      Console.WriteLine("Product Not Found");
    }

    // Pause for Results
    Console.ReadKey();
  }
}