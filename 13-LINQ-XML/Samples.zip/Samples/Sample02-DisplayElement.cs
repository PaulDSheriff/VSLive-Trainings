﻿#nullable disable

using System.Xml.Linq;

namespace XmlSamples;

public class Sample02 {
  /// <summary>
  /// Put all products into a collection using LINQ
  /// </summary>
  public static void DisplayElement() {
    XElement elem = XElement.Load(FileNameHelper.ProductsFile);
    List<XElement> list;

    // Write Query Syntax Here
    list = (from row in elem.Elements("Product")
            select row).ToList();

    // Display element(s) of XElement
    foreach (XElement prod in list) {
      Console.Write(prod.Element("Name").Value);
      Console.Write(" (");
      Console.Write(prod.Element("ProductID").Value);
      Console.WriteLine(")");
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}