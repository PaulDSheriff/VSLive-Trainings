﻿using System.Xml.Linq;

namespace XmlSamples;

public class Sample01 {
  /// <summary>
  /// Put all products into a collection using LINQ
  /// </summary>
  public static void GetAllQuery() {
    XElement elem = XElement.Load(FileNameHelper.ProductsFile);
    List<XElement> list;

    // Write Query Syntax Here
    list = (from row in elem.Elements("Product")
            select row).ToList();

    // Display products
    foreach (XElement prod in list) {
      Console.WriteLine(prod);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}