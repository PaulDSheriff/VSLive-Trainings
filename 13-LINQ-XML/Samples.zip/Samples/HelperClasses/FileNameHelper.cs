﻿namespace XmlSamples;

/// <summary>
/// Creates path to XML file and sets the ProductsFile property
/// </summary>
public static class FileNameHelper {
  static FileNameHelper() {
    //string path = @"..\..\..\..\..\Xml\";
    // Get path to current directory and remove everything from \bin\ forward
    // Then add on the folder where the database is located
    string path = Directory.GetCurrentDirectory();
    if (path.Contains("\\bin")) {
      path = path.Substring(0, path.LastIndexOf("bin") - 1);
    }
    path += @"\Xml\";

    ProductsFile = $"{path}Products.xml";
    ProductsAttributesFile = $"{path}ProductsAttributes.xml";
  }

  public static string ProductsFile { get; set; }
  public static string ProductsAttributesFile { get; set; }
}