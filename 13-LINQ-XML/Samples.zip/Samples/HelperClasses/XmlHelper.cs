﻿#nullable disable

using System.Globalization;
using System.Xml.Linq;

namespace XmlSamples
{
  /// <summary>
  /// Extension methods to help process XML files easily
  /// </summary>
  public static class XmlHelper
  {
    #region GetAs<T> Method
    public static T GetAs<T>(this XElement elem, string name, T defaultValue = default)
    {
      T ret = defaultValue;

      if (elem != null && elem.Element(name) != null && !string.IsNullOrEmpty(elem.Element(name).Value))
      {
        // Cast to Return Data Type
        // NOTE: ChangeType can not cast to a Nullable type
        ret = (T)Convert.ChangeType(elem.Element(name).Value, typeof(T), CultureInfo.InvariantCulture);
      }

      return ret;
    }
    #endregion

    #region GetAttrAs<T> Method
    public static T GetAttrAs<T>(this XElement elem, string name, T defaultValue = default)
    {
      T ret = defaultValue;

      if (elem != null && elem.Attribute(name) != null && !string.IsNullOrEmpty(elem.Attribute(name).Value))
      {
        // Cast to Return Data Type
        // NOTE: ChangeType can not cast to a Nullable type
        ret = (T)Convert.ChangeType(elem.Attribute(name).Value, typeof(T), CultureInfo.InvariantCulture);
      }

      return ret;
    }
    #endregion

    #region GetMaxValue Method
    public static T GetMaxValue<T>(this XElement elem, string elemName, string parentNodeName)
    {
      // Get the largest node value
      T maxValue =
        (from node in elem.Elements(parentNodeName)
         select node.GetAs<T>(elemName, default)).Max();

      return maxValue;
    }
    #endregion

    #region GetCount Method
    public static int GetCount(this XElement elem, string parentNodeName)
    {
      // Get total rows in XML file
      int count = (from node in elem.Elements(parentNodeName)
                   select node).Count();

      return count;
    }
    #endregion
  }
}
