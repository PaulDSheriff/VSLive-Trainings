﻿using System.Xml.Linq;

namespace XmlSamples;

public class Sample08 {
  /// <summary>
  /// Create a class from XML data
  /// </summary>
  public static void CreateClass() {
    XElement elem = XElement.Load(FileNameHelper.ProductsFile);
    List<Product> list;

    // Write Query Here
    list = (from row in elem.Elements("Product")
            orderby row.GetAs<string>("Name")
            select new Product {
              ProductID = row.GetAs<int>("ProductID"),
              Name = row.GetAs<string>("Name", "n/a"),
              Color = row.GetAs<string>("Color"),
              StandardCost = row.GetAs<decimal>("StandardCost", 0),
              ListPrice = row.GetAs<decimal>("ListPrice", 0),
              Size = row.GetAs<string>("SalesPerson", "n/a"),
            }).ToList();

    // Display products
    foreach (Product prod in list) {
      Console.WriteLine(prod);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}