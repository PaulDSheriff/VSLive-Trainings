﻿Description of the Samples
--------------------------------------------------
01-GetAllQuery() - Get all Element-Based Products
02-DisplayElement() - Display Single Elements
03-WhereClause() - Filter Products on Color
04-GetSingleNode() - Get a Single Element Node
05-OrderBy() - Order by two Elements
06-AttributeBased() - Read Attribute Based XML
07-Aggregate() - Aggregate Functions
08-CreateClass() - Create a Collection of Product Objects