﻿using XmlSamples;

// Call Sample Method
Sample01.GetAllQuery();
//Sample02.DisplayElement();
//Sample03.WhereClause();
//Sample04.GetSingleNode();
//Sample05.OrderBy();
//Sample06.AttributeBased();
//Sample07.Aggregate();
//Sample08.CreateClass();