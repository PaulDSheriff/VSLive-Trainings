﻿#nullable disable

using System.Xml.Linq;

namespace XmlSamples;

public class Sample07 {
  /// <summary>
  /// Use Aggregate Functions on XML
  /// </summary>
  public static void Aggregate() {
    XElement elem = XElement.Load(FileNameHelper.ProductsFile);

    int count = (from row in elem.Elements("Product")
                 select row).Count();

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {count}");

    decimal total = (from row in elem.Elements("Product")
         select Convert.ToDecimal(row.Element("StandardCost").Value)).Sum();

    // Display Total Standard Cost
    Console.WriteLine();
    Console.WriteLine($"Total Standard Cost: {total.ToString("c")}");

    // Pause for Results
    Console.ReadKey();
  }
}