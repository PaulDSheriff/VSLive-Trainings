﻿#nullable disable

using System.Xml.Linq;

namespace XmlSamples;

public class Sample05 {
  /// <summary>
  /// Order the XML data returned by Color and ListPrice
  /// </summary>
  public static void OrderBy() {
    XElement elem = XElement.Load(FileNameHelper.ProductsFile);
    List<XElement> list;

    // Write Query Syntax Here
    list = (from row in elem.Elements("Product")
            orderby row.Element("Color").Value,
                    Convert.ToDecimal(row.Element("ListPrice").Value)
            select row).ToList();

    // Display products
    foreach (XElement prod in list) {
      Console.Write(prod);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}