﻿#nullable disable

using System.Xml.Linq;

namespace XmlSamples;

public class Sample06 {
  /// <summary>
  /// Get all data from attribute-based XML file
  /// </summary>
  public static void AttributeBased() {
    XElement elem = XElement.Load(FileNameHelper.ProductsAttributesFile);
    List<XElement> list;

    // Write Query Syntax Here
    list = (from row in elem.Elements("Product")
            where row.Attribute("Color").Value == "Silver"
            orderby row.Attribute("Color").Value,
                    Convert.ToDecimal(row.Attribute("ListPrice").Value)
            select row).ToList();

    // Display products
    foreach (XElement prod in list) {
      Console.WriteLine(prod);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}