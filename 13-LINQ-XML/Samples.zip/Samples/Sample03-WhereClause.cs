﻿#nullable disable

using System.Xml.Linq;

namespace XmlSamples;

public class Sample03 {
  /// <summary>
  /// Select a subset of the XML
  /// </summary>
  public static void WhereClause() {
    XElement elem = XElement.Load(FileNameHelper.ProductsFile);
    List<XElement> list;

    // Write Query Syntax Here
    list = (from row in elem.Elements("Product")
            where row.Element("Color").Value == "Silver"
            select row).ToList();

    // Display products
    foreach (XElement prod in list) {
      Console.WriteLine(prod);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}