﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab04() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    List<string> list;

    // Method Syntax
    list = songs.Select(row => row.SongName).ToList();

    // Display Songs
    foreach (string name in list) {
      Console.WriteLine(name);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Songs: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
