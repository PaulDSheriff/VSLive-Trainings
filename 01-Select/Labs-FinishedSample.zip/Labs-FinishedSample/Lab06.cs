﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab06() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    List<Song> list;

    // Method Syntax
    list = songs.Select(row => new Song {
      SongId = row.SongId,
      SongName = row.SongName,
      Artist = row.Artist,
      Album = row.Album,
      Year = row.Year
    }).ToList();

    // Display Songs
    foreach (Song song in list) {
      Console.Write(song);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Songs: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
