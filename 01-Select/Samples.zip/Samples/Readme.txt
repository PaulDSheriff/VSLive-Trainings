﻿Description of the Samples
--------------------------------------------------
01-GetAllQuery() - Put all products into a collection using LINQ query
02-GetAllMethod() - Put all products into a collection using LINQ method

03-GetSingleColumnQuery() - Select a single column
04-GetSingleColumnMethod() - Select a single column

05-GetSpecificColumnsQuery() - Select a few specific properties from products and create new Product objects
06-GetSpecificColumnsMethod() - Select a few specific properties from products and create new Product objects

07-AnonymousClassQuery() - Create an anonymous class from selected product properties
08-AnonymousClassMethod() - Create an anonymous class from selected product properties