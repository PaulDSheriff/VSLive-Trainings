﻿using LINQSamples;

// Call Sample Method
Sample01.GetAllQuery();
//Sample02.GetAllMethod();
//Sample03.GetSingleColumnQuery();
//Sample04.GetSingleColumnMethod();
//Sample05.GetSpecificColumnsQuery();
//Sample06.GetSpecificColumnsMethod();
//Sample07.AnonymousClassQuery();
//Sample08.AnonymousClassMethod();