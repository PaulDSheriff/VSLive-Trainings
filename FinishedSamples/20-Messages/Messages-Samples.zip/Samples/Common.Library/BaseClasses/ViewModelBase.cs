﻿namespace Common.Library;

public class ViewModelBase : CommonBase
{
  #region Private Variables
  private bool _IsAdding;
  private int _RowsAffected;
  private bool _IsDataProcessing;
  private bool _ExceptionHappened;
  #endregion

  #region Public Properties
  /// <summary>
  /// Get/Set whether or not the page is in add mode
  /// </summary>
  public bool IsAdding
  {
    get { return _IsAdding; }
    set
    {
      _IsAdding = value;
      RaisePropertyChanged(nameof(IsAdding));
    }
  }

  /// <summary>
  /// Get/Set the Numbers of Rows Affected by the last operation
  /// </summary>
  public int RowsAffected
  {
    get { return _RowsAffected; }
    set
    {
      _RowsAffected = value;
      RaisePropertyChanged(nameof(RowsAffected));
    }
  }

  /// <summary>
  /// Get/Set if data is being processed
  /// </summary>
  public bool IsDataProcessing
  {
    get { return _IsDataProcessing; }
    set
    {
      _IsDataProcessing = value;
      RaisePropertyChanged(nameof(IsDataProcessing));
    }
  }

  /// <summary>
  /// Get/Set whether or not the page had exception occur
  /// </summary>
  public bool ExceptionHappened
  {
    get { return _ExceptionHappened; }
    set
    {
      _ExceptionHappened = value;
      RaisePropertyChanged(nameof(ExceptionHappened));
    }
  }
  #endregion

  #region BeginProcessing Method
  protected virtual void BeginProcessing()
  {
    InfoMessage = string.Empty;
    LastErrorMessage = string.Empty;
    LastException = null;
    RowsAffected = 0;
    IsDataProcessing = true;
    ExceptionHappened = false;
  }
  #endregion

  #region EndProcessing Methods
  protected virtual void EndProcessing()
  {
    IsDataProcessing = false;
    if (!string.IsNullOrEmpty(LastErrorMessage) ||
        LastException != null) {
      ExceptionHappened = true;
    }
  }
  #endregion

  #region PublishException Method
  protected virtual void PublishException(Exception ex)
  {
    LastException = ex;

    System.Diagnostics.Debug.WriteLine(ex.ToString());
  }
  #endregion
}
