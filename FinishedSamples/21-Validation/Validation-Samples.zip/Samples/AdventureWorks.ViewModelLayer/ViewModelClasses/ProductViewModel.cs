﻿using AdventureWorks.EntityLayer;
using Common.Library;
using System.Collections.ObjectModel;

namespace AdventureWorks.ViewModelLayer;

public class ProductViewModel : ViewModelBase
{
  #region Constructors
  public ProductViewModel() : base()
  {
  }

  public ProductViewModel(IRepository<Product> repo) : base()
  {
    Repository = repo;
  }
  #endregion

  #region Private Variables
  private readonly IRepository<Product>? Repository;

  private ObservableCollection<Product> _Products = new();
  private Product? _CurrentEntity = new();
  #endregion

  #region Public Properties
  public ObservableCollection<Product> Products
  {
    get { return _Products; }
    set
    {
      _Products = value;
      RaisePropertyChanged(nameof(Products));
    }
  }

  public Product? CurrentEntity
  {
    get { return _CurrentEntity; }
    set
    {
      _CurrentEntity = value;
      RaisePropertyChanged(nameof(CurrentEntity));
    }
  }
  #endregion

  #region GetAsync Method
  public async Task<ObservableCollection<Product>> GetAsync()
  {
    BeginProcessing();
    try {
      if (Repository == null) {
        LastErrorMessage = REPO_NOT_SET;
      }
      else {
        InfoMessage = "Please wait while loading products...";
        Products = new ObservableCollection<Product>(await Repository.GetAsync());
        RowsAffected = Products.Count;
        InfoMessage = $"Found {RowsAffected} Products";
      }
    }
    catch (Exception ex) {
      PublishException(ex);
    }
    EndProcessing();

    return Products;
  }
  #endregion

  #region GetAsync(id) Method
  /// <summary>
  /// Get a single Product object
  /// </summary>
  /// <param name="id">The ProductId to locate</param>
  /// <returns>An instance of a Product object</returns>
  public async Task<Product?> GetAsync(int id)
  {
    BeginProcessing();
    try {
      // Get a Product from a data store
      if (Repository != null) {
        CurrentEntity = await Repository.GetAsync(id);
      }
      else {
        LastErrorMessage = REPO_NOT_SET;

        // MOCK Data
        CurrentEntity = await Task.FromResult(new Product {
          ProductID = id,
          Name = "A New Product",
          Color = "Black",
          StandardCost = 10,
          ListPrice = 20,
          SellStartDate = Convert.ToDateTime("7/1/2023"),
          Size = "LG"
        });
      }

      InfoMessage = "Found the Product";
      RowsAffected = 1;
    }
    catch (Exception ex) {
      PublishException(ex);
    }
    EndProcessing();

    return CurrentEntity;
  }
  #endregion

  #region SaveAsync Method
  public async virtual Task<Product?> SaveAsync()
  {
    // TODO: Write code to save data


    return await Task.FromResult(new Product());
  }
  #endregion
}
