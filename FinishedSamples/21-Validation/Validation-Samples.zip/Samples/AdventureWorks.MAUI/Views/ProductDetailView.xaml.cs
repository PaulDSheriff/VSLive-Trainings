using AdventureWorks.MAUI.CommandClasses;

namespace AdventureWorks.MAUI.Views;

[QueryProperty(nameof(ProductId), "id")]
[QueryProperty(nameof(IsAdding), "isAdding")]
public partial class ProductDetailView : ContentPage
{
  public ProductDetailView(ProductViewModelCommands viewModel)
  {
    InitializeComponent();

    ViewModel = viewModel;
  }

  public ProductViewModelCommands ViewModel { get; set; }
  public int ProductId { get; set; }
  public bool IsAdding { get; set; }

  protected async override void OnAppearing()
  {
    base.OnAppearing();

    // Set the Page BindingContext
    BindingContext = ViewModel;

    ViewModel.IsAdding = IsAdding;
    if (IsAdding) {
      // TODO: Create a new empty entity
    }
    else {
      // Retrieve a Product
      await ViewModel.GetAsync(ProductId);
    }
  }
}