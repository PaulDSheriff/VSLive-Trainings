using AdventureWorks.EntityLayer;

namespace AdventureWorks.MAUI.Views;

public partial class UserDetailView : ContentPage
{
	public UserDetailView()
	{
		InitializeComponent();

    ViewModel = (User)this.Resources["viewModel"];
  }

  public User ViewModel { get; set; }

  protected override void OnAppearing()
  {
    base.OnAppearing();

    ViewModel.LoginId = "PeterPiper384";
    ViewModel.FirstName = "Peter";
    ViewModel.LastName = "Piper";
    ViewModel.Email = "Peter@pipering.com";
  }

  private void SaveButton_Clicked(object sender, EventArgs e)
  {
    System.Diagnostics.Debugger.Break();
  }
}