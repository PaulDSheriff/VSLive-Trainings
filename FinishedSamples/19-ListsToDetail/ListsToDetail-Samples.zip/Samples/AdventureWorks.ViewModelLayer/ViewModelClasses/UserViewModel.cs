﻿using AdventureWorks.EntityLayer;
using Common.Library;
using System.Collections.ObjectModel;

namespace AdventureWorks.ViewModelLayer;

public class UserViewModel : ViewModelBase
{
  #region Constructors
  public UserViewModel() : base()
  {
  }

  public UserViewModel(IRepository<User> repo) : base()
  {
    Repository = repo;
  }

  public UserViewModel(IRepository<User> repo, IRepository<PhoneType> phoneRepo) : base()
  {
    Repository = repo;
    _PhoneTypeRepository = phoneRepo;
  }
  #endregion

  #region Private Variables
  private readonly IRepository<User>? Repository;
  private User? _CurrentEntity = new();
  private ObservableCollection<User> _Users = new();

  private readonly IRepository<PhoneType>? _PhoneTypeRepository;
  private ObservableCollection<string> _PhoneTypesList = new();
  #endregion

  #region Public Properties
  public User? CurrentEntity
  {
    get { return _CurrentEntity; }
    set
    {
      _CurrentEntity = value;
      RaisePropertyChanged(nameof(CurrentEntity));
    }
  }

  public ObservableCollection<User> Users
  {
    get { return _Users; }
    set
    {
      _Users = value;
      RaisePropertyChanged(nameof(Users));
    }
  }

  public ObservableCollection<string> PhoneTypesList
  {
    get { return _PhoneTypesList; }
    set
    {
      _PhoneTypesList = value;
      RaisePropertyChanged(nameof(PhoneTypesList));
    }
  }
  #endregion

  #region GetAsync Method
  public async Task<ObservableCollection<User>> GetAsync()
  {
    RowsAffected = 0;

    try {
      if (Repository == null) {
        LastErrorMessage = REPO_NOT_SET;
      }
      else {
        Users = new ObservableCollection<User>(await Repository.GetAsync());
        RowsAffected = Users.Count;
        InfoMessage = $"Found {RowsAffected} Users";
      }
    }
    catch (Exception ex) {
      PublishException(ex);
    }

    return Users;
  }
  #endregion

  #region GetAsync(id) Method
  /// <summary>
  /// Get a single user object
  /// </summary>
  /// <param name="id">The UserId to locate</param>
  /// <returns>An instance of a User object</returns>
  public async Task<User?> GetAsync(int id)
  {
    try {
      // Get a User from a data store
      if (Repository != null) {
        CurrentEntity = await Repository.GetAsync(id);
      }
      else {
        LastErrorMessage = REPO_NOT_SET;

        // MOCK Data
        CurrentEntity = await Task.FromResult(new User {
          UserId = id,
          LoginId = "SallyJones",
          FirstName = "Sally",
          LastName = "Jones",
          Email = "Sallyj@jones.com",
          Phone = "615.987.3456",
          PhoneType = "Mobile",
          IsEnrolledIn401k = true,
          IsEnrolledInFlexTime = false,
          IsEnrolledInHealthCare = true,
          IsEnrolledInHSA = false,
          IsActive = true,
          BirthDate = Convert.ToDateTime("08-13-1989"),
          StartTime = new TimeSpan(7, 30, 0)
        });
      }

      InfoMessage = "Found the User";
      RowsAffected = 1;
    }
    catch (Exception ex) {
      RowsAffected = 0;
      PublishException(ex);
    }

    return CurrentEntity;
  }
  #endregion

  #region SaveAsync Method
  public async virtual Task<User?> SaveAsync()
  {
    // TODO: Write code to save data
    //System.Diagnostics.Debugger.Break();

    return await Task.FromResult(new User());
  }
  #endregion

  #region GetPhoneTypes Method
  public async Task<ObservableCollection<string>> GetPhoneTypes()
  {
    if (_PhoneTypeRepository != null) {
      var list = await _PhoneTypeRepository.GetAsync();

      PhoneTypesList = new ObservableCollection<string>(list.Select(row => row.TypeDescription));
    }

    return PhoneTypesList;
  }
  #endregion
}
