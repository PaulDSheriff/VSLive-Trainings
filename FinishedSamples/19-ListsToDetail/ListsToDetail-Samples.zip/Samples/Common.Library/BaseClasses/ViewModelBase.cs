﻿namespace Common.Library;

public class ViewModelBase : CommonBase
{
  #region Private Variables
  private bool _IsAdding;
  private int _RowsAffected;
  #endregion

  #region Public Properties
  /// <summary>
  /// Get/Set whether or not the page is in add mode
  /// </summary>
  public bool IsAdding
  {
    get { return _IsAdding; }
    set
    {
      _IsAdding = value;
      RaisePropertyChanged(nameof(IsAdding));
    }
  }

  /// <summary>
  /// Get/Set the Numbers of Rows Affected by the last operation
  /// </summary>
  public int RowsAffected
  {
    get { return _RowsAffected; }
    set
    {
      _RowsAffected = value;
      RaisePropertyChanged(nameof(RowsAffected));
    }
  }
  #endregion

  #region PublishException Method
  protected virtual void PublishException(Exception ex)
  {
    LastException = ex;

    System.Diagnostics.Debug.WriteLine(ex.ToString());
  }
  #endregion
}
