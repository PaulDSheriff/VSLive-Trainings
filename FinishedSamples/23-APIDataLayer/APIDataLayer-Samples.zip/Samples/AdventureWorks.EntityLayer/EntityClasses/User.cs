﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

using System.Text.Json.Serialization;
using Common.Library;

namespace AdventureWorks.EntityLayer;

/// <summary>
/// This class contains properties that map to each field in the dbo.User table.
/// </summary>
[Table("User", Schema = "dbo")]
public partial class User : EntityBase
{
  #region Private Variables
  private int _UserId;
  private string _LoginId = string.Empty;
  private string _FirstName = string.Empty;
  private string _LastName = string.Empty;
  private string _Email = string.Empty;
  private string _Password = "P@ssW0Rd";
  private string _Phone = string.Empty;
  private string? _PhoneType;
  private bool? _IsFullTime;
  private bool? _IsEnrolledIn401k;
  private bool? _IsEnrolledInHealthCare;
  private bool? _IsEnrolledInHSA;
  private bool? _IsEnrolledInFlexTime;
  private bool? _IsActive;
  private DateTime? _BirthDate;
  private TimeSpan? _StartTime;
  #endregion

  #region Public Properties
  /// <summary>
  /// Get/Set User Id
  /// </summary>
  [Key]
  [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
  [Display(Name = "User Id")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [Column("UserId", TypeName = "int")]
  [JsonPropertyName("userId")]
  public int UserId
  {
    get { return _UserId; }
    set
    {
      _UserId = value;
      RaisePropertyChanged(nameof(UserId));
    }
  }

  /// <summary>
  /// Get/Set Login Id
  /// </summary>
  [Display(Name = "Login Id")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [Column("LoginId", TypeName = "nvarchar")]
  [StringLength(20, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  [JsonPropertyName("loginId")]
  public string LoginId
  {
    get { return _LoginId; }
    set
    {
      _LoginId = value;
      RaisePropertyChanged(nameof(LoginId));
    }
  }

  /// <summary>
  /// Get/Set First Name
  /// </summary>
  [Display(Name = "First Name")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [Column("FirstName", TypeName = "nvarchar")]
  [StringLength(50, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  [JsonPropertyName("firstName")]
  public string FirstName
  {
    get { return _FirstName; }
    set
    {
      _FirstName = value;
      RaisePropertyChanged(nameof(FirstName));
    }
  }

  /// <summary>
  /// Get/Set Last Name
  /// </summary>
  [Display(Name = "Last Name")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [Column("LastName", TypeName = "nvarchar")]
  [StringLength(50, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  [JsonPropertyName("lastName")]
  public string LastName
  {
    get { return _LastName; }
    set
    {
      _LastName = value;
      RaisePropertyChanged(nameof(LastName));
    }
  }

  /// <summary>
  /// Get/Set Email
  /// </summary>
  [Display(Name = "Email")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [Column("Email", TypeName = "nvarchar")]
  [StringLength(256, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  [EmailAddress()]
  [JsonPropertyName("email")]
  public string Email
  {
    get { return _Email; }
    set
    {
      _Email = value;
      RaisePropertyChanged(nameof(Email));
    }
  }

  /// <summary>
  /// Get/Set Password
  /// </summary>
  [Display(Name = "Password")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [Column("Password", TypeName = "nvarchar")]
  [StringLength(50, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  [JsonPropertyName("password")]
  public string Password
  {
    get { return _Password; }
    set
    {
      _Password = value;
      RaisePropertyChanged(nameof(Password));
    }
  }

  /// <summary>
  /// Get/Set Phone
  /// </summary>
  [Display(Name = "Phone")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [Column("Phone", TypeName = "nvarchar")]
  [StringLength(25, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  [Phone()]
  [JsonPropertyName("phone")]
  public string Phone
  {
    get { return _Phone; }
    set
    {
      _Phone = value;
      RaisePropertyChanged(nameof(Phone));
    }
  }

  /// <summary>
  /// Get/Set Phone Type
  /// </summary>
  [Display(Name = "Phone Type")]
  [Column("PhoneType", TypeName = "nvarchar")]
  [StringLength(10, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  [JsonPropertyName("phoneType")]
  public string? PhoneType
  {
    get { return _PhoneType; }
    set
    {
      _PhoneType = value;
      RaisePropertyChanged(nameof(PhoneType));
    }
  }

  /// <summary>
  /// Get/Set Is Full Time
  /// </summary>
  [Display(Name = "Is Full Time")]
  [Column("IsFullTime", TypeName = "bit")]
  [JsonPropertyName("isFullTime")]
  public bool? IsFullTime
  {
    get { return _IsFullTime; }
    set
    {
      _IsFullTime = value;
      RaisePropertyChanged(nameof(IsFullTime));
    }
  }

  /// <summary>
  /// Get/Set Is Enrolled In 40 1K
  /// </summary>
  [Display(Name = "Is Enrolled In 40 1K")]
  [Column("IsEnrolledIn401k", TypeName = "bit")]
  [JsonPropertyName("isEnrolledIn401k")]
  public bool? IsEnrolledIn401k
  {
    get { return _IsEnrolledIn401k; }
    set
    {
      _IsEnrolledIn401k = value;
      RaisePropertyChanged(nameof(IsEnrolledIn401k));
    }
  }

  /// <summary>
  /// Get/Set Is Enrolled In Health Care
  /// </summary>
  [Display(Name = "Is Enrolled In Health Care")]
  [Column("IsEnrolledInHealthCare", TypeName = "bit")]
  [JsonPropertyName("isEnrolledInHealthCare")]
  public bool? IsEnrolledInHealthCare
  {
    get { return _IsEnrolledInHealthCare; }
    set
    {
      _IsEnrolledInHealthCare = value;
      RaisePropertyChanged(nameof(IsEnrolledInHealthCare));
    }
  }

  /// <summary>
  /// Get/Set Is Enrolled In Hsa
  /// </summary>
  [Display(Name = "Is Enrolled In Hsa")]
  [Column("IsEnrolledInHSA", TypeName = "bit")]
  [JsonPropertyName("isEnrolledInHSA")]
  public bool? IsEnrolledInHSA
  {
    get { return _IsEnrolledInHSA; }
    set
    {
      _IsEnrolledInHSA = value;
      RaisePropertyChanged(nameof(IsEnrolledInHSA));
    }
  }

  /// <summary>
  /// Get/Set Is Enrolled In Flex Time
  /// </summary>
  [Display(Name = "Is Enrolled In Flex Time")]
  [Column("IsEnrolledInFlexTime", TypeName = "bit")]
  [JsonPropertyName("isEnrolledInFlexTime")]
  public bool? IsEnrolledInFlexTime
  {
    get { return _IsEnrolledInFlexTime; }
    set
    {
      _IsEnrolledInFlexTime = value;
      RaisePropertyChanged(nameof(IsEnrolledInFlexTime));
    }
  }

  /// <summary>
  /// Get/Set Is Active
  /// </summary>
  [Display(Name = "Is Active")]
  [Column("IsActive", TypeName = "bit")]
  [JsonPropertyName("isActive")]
  public bool? IsActive
  {
    get { return _IsActive; }
    set
    {
      _IsActive = value;
      RaisePropertyChanged(nameof(IsActive));
    }
  }

  /// <summary>
  /// Get/Set Birth Date
  /// </summary>
  [Display(Name = "Birth Date")]
  [Column("BirthDate", TypeName = "date")]
  [DataType(DataType.Date)]
  [JsonPropertyName("birthDate")]
  public DateTime? BirthDate
  {
    get { return _BirthDate; }
    set
    {
      _BirthDate = value;
      RaisePropertyChanged(nameof(BirthDate));
    }
  }

  /// <summary>
  /// Get/Set Start Time
  /// </summary>
  [Display(Name = "Start Time")]
  [Column("StartTime", TypeName = "time")]
  [JsonPropertyName("startTime")]
  public TimeSpan? StartTime
  {
    get { return _StartTime; }
    set
    {
      _StartTime = value;
      RaisePropertyChanged(nameof(StartTime));
    }
  }

  public string FullName
  {
    get { return FirstName + " " + LastName; }
  }

  public string LastNameFirstName
  {
    get { return LastName + ", " + FirstName; }
  }
  #endregion

  #region ToString Override
  public override string ToString()
  {
    return $"{LastName}";
  }
  #endregion
}
