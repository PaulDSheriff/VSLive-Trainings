using AdventureWorks.MAUI.CommandClasses;

namespace AdventureWorks.MAUI.Views;

public partial class UserDetailView : ContentPage
{
  public UserDetailView(UserViewModelCommands viewModel)
  {
    InitializeComponent();

    ViewModel = viewModel;
  }

  public UserViewModelCommands ViewModel { get; set; }

  protected async override void OnAppearing()
  {
    base.OnAppearing();

    // Set the Page BindingContext
    BindingContext = ViewModel;

    // Get the Phone Types
    await ViewModel.GetPhoneTypes();

    // Retrieve a User
    await ViewModel.GetAsync(1);
  }
}