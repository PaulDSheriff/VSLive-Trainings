﻿using AdventureWorks.EntityLayer;
using AdventureWorks.ViewModelLayer;
using Common.Library;
using System.Windows.Input;

namespace AdventureWorks.MAUI.CommandClasses;

public class UserViewModelCommands : UserViewModel
{
  #region Constructors
  public UserViewModelCommands() : base()
  {
  }

  public UserViewModelCommands(IRepository<User> repo) : base(repo)
  {
  }

  public UserViewModelCommands(IRepository<User> repo, IRepository<PhoneType> phoneRepo) : base(repo, phoneRepo)
  {
  }
  #endregion

  #region Commands
  public ICommand? SaveCommand { get; private set; }
  #endregion

  #region Init Method
  public override void Init()
  {
    base.Init();

    // Create commands for this view
    SaveCommand = new Command(
      execute: async () => await SaveAsync(),
      canExecute: () => true);
  }
  #endregion
}