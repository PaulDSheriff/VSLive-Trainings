﻿using AdventureWorks.EntityLayer;
using Common.Library;
using System.Collections.ObjectModel;

namespace AdventureWorks.ViewModelLayer;

public class UserViewModel : ViewModelBase
{
  #region Private Variables
  private User? _CurrentEntity = new();
  #endregion

  #region Public Properties
  public User? CurrentEntity
  {
    get { return _CurrentEntity; }
    set
    {
      _CurrentEntity = value;
      RaisePropertyChanged(nameof(CurrentEntity));
    }
  }
  #endregion

  #region GetAsync Method
  public async Task<ObservableCollection<User>> GetAsync()
  {
    return await Task.FromResult(new ObservableCollection<User>());
  }
  #endregion

  #region GetAsync(id) Method
  /// <summary>
  /// Get a single user object
  /// </summary>
  /// <param name="id">The UserId to locate</param>
  /// <returns>An instance of a User object</returns>
  public async Task<User?> GetAsync(int id)
  {
    try {
      // TODO: Get a User from a data store

      // MOCK Data
      CurrentEntity = await Task.FromResult(new User {
        UserId = id,
        LoginId = "SallyJones615",
        FirstName = "Sally",
        LastName = "Jones",
        Email = "Sallyj@jones.com",
        Phone = "615.987.3456",
        PhoneType = "Mobile",
        IsFullTime = true,
        IsEnrolledIn401k = true,
        IsEnrolledInFlexTime = false,
        IsEnrolledInHealthCare = true,
        IsEnrolledInHSA = false,
        IsActive = true,
        BirthDate = Convert.ToDateTime("08-13-1989"),
        StartTime = new TimeSpan(7, 30, 0)
      });

      RowsAffected = 1;
    }
    catch (Exception ex) {
      RowsAffected = 0;
      PublishException(ex);
    }

    return CurrentEntity;
  }
  #endregion

  #region SaveAsync Method
  public async virtual Task<User?> SaveAsync()
  {
    // TODO: Write code to save data
    System.Diagnostics.Debugger.Break();

    return await Task.FromResult(new User());
  }
  #endregion
}
