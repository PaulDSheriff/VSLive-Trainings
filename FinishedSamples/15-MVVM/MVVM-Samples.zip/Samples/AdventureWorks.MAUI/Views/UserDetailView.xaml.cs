using AdventureWorks.ViewModelLayer;

namespace AdventureWorks.MAUI.Views;

public partial class UserDetailView : ContentPage
{
	public UserDetailView()
	{
		InitializeComponent();
  }

  public UserViewModel ViewModel { get; set; }

  protected async override void OnAppearing()
  {
    base.OnAppearing();

    // Create a new instance of UserViewModel
    ViewModel = new();

    // Set the Page BindingContext
    BindingContext = ViewModel;

    // Retrieve a User
    await ViewModel.GetAsync(1);
  }

  private void SaveButton_Clicked(object sender, EventArgs e)
  {
    System.Diagnostics.Debugger.Break();
  }
}