﻿using System.Collections.ObjectModel;

namespace Common.Library;

public interface IRepository<TEntity>
{
  Task<ObservableCollection<TEntity>> GetAsync();

  Task<TEntity?> GetAsync(int id);
  Task<TEntity?> InsertAsync(TEntity? entity);
  Task<TEntity?> UpdateAsync(TEntity? entity);
  Task<TEntity?> DeleteAsync(TEntity? entity);
}
