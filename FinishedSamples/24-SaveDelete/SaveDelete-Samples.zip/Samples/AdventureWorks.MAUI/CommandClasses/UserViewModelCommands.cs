﻿using AdventureWorks.EntityLayer;
using AdventureWorks.ViewModelLayer;
using AdventureWorks.MAUI.Views;
using Common.Library;
using System.Windows.Input;

namespace AdventureWorks.MAUI.CommandClasses;

public class UserViewModelCommands : UserViewModel
{
  #region Constructors
  public UserViewModelCommands() : base()
  {
  }

  public UserViewModelCommands(IRepository<User> repo) : base(repo)
  {
  }

  public UserViewModelCommands(IRepository<User> repo, IRepository<PhoneType> phoneRepo) : base(repo, phoneRepo)
  {
  }
  #endregion

  #region Commands
  public ICommand? SaveCommand { get; private set; }
  public ICommand? EditCommand { get; private set; }
  public ICommand? CancelCommand { get; private set; }
  public ICommand? AddCommand { get; private set; }
  public ICommand? DeleteCommand { get; private set; }
  #endregion

  #region Public Properties
  public UserListView? TheView { get; set; }
#endregion

  #region Init Method
  public override void Init()
  {
    base.Init();

    // Create commands for this view
    SaveCommand = new Command(execute: async () => await SaveAsync(), canExecute: () => true);
    EditCommand = new Command<int>(async (int id) => await EditAsync(id), (id) => true);
    CancelCommand = new Command(async () => await CancelAsync(), () => true);
    AddCommand = new Command(async () => await AddAsync(), () => true);
    DeleteCommand = new Command<int>(async (int id) => await DeleteAsync(id), (id) => true);
  }
  #endregion

  #region SaveAsync Method
  protected new async Task<User?> SaveAsync()
  {
    User? ret = await base.SaveAsync();

    if (ret != null) {
      await Shell.Current.GoToAsync("..");
    }

    return ret;
  }
  #endregion

  #region CancelAsync Method
  protected async Task CancelAsync()
  {
    await Shell.Current.GoToAsync("..");
  }
  #endregion

  #region AddAsync Method
  protected async Task AddAsync()
  {
    await Shell.Current.GoToAsync($"{nameof(Views.UserDetailView)}?id={0}&isAdding={true}");
  }
  #endregion

  #region EditAsync Method
  protected async Task EditAsync(int id)
  {
    await Shell.Current.GoToAsync($"{nameof(Views.UserDetailView)}?id={id}&isAdding={false}");
  }
  #endregion

  #region DeleteAsync Method
  protected new async Task DeleteAsync(int id)
  {
    if (TheView != null) {
      // Ask user for confirmation
      string action = await TheView.DisplayActionSheet("Delete this User?", "Cancel", "Delete");
      if (action == "Delete") {
        // Perform delete
        User? response = await base.DeleteAsync(id);
        if (response != null) {
          InfoMessage = "User Deleted";
        }

        // Redisplay list
        await GetAsync();
      }
    }
  }
  #endregion
}