using AdventureWorks.MAUI.CommandClasses;

namespace AdventureWorks.MAUI.Views;

public partial class UserListView : ContentPage
{
  public UserListView(UserViewModelCommands viewModel)
  {
    InitializeComponent();

    ViewModel = viewModel;
  }

  private readonly UserViewModelCommands ViewModel;

  protected async override void OnAppearing()
  {
    base.OnAppearing();

    BindingContext = ViewModel;

    // Set 'TheView' property to 'this' so you can display alerts
    ViewModel.TheView = this;

    await ViewModel.GetAsync();
  }
}
