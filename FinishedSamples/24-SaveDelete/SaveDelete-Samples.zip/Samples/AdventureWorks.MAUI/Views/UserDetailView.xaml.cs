using AdventureWorks.MAUI.CommandClasses;

namespace AdventureWorks.MAUI.Views;

[QueryProperty(nameof(UserId), "id")]
[QueryProperty(nameof(IsAdding), "isAdding")]
public partial class UserDetailView : ContentPage
{
  public UserDetailView(UserViewModelCommands viewModel)
  {
    InitializeComponent();

    ViewModel = viewModel;
  }

  public UserViewModelCommands ViewModel { get; set; }
  public int UserId { get; set; }
  public bool IsAdding { get; set; }

  protected async override void OnAppearing()
  {
    base.OnAppearing();

    // Set the Page BindingContext
    BindingContext = ViewModel;

    // Get the Phone Types
    await ViewModel.GetPhoneTypes();

    ViewModel.IsAdding = IsAdding;
    if (IsAdding) {
      ViewModel.CurrentEntity = ViewModel.CreateEmpty();
    }
    else {
      // Retrieve a User
      await ViewModel.GetAsync(UserId);
    }
  }
}