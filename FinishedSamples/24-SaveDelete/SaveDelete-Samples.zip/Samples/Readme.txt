To run this sample, you must set the solution to run multiple projects. Follow the steps below.

Right mouse-click on the Solution and choose Properties from the menu.
Under Common Properties | Startup Project...
Select the Multiple Startup Projects radio button.
Move the AdventureWorks.MinWebAPI project to the top of the list.
Set its Action to 'Start'.
Move the AdventureWorksTraining.MAUI project to the second one in the list.
Set its Action to 'Start'.
Click on the Configuration Properties... tab.
Check the Deploy button next to the AdventureWorks.MAUI project, if it is not already checked.
Click the OK button.
