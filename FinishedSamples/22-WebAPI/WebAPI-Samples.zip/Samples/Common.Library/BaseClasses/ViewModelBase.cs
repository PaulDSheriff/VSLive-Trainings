﻿using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;

namespace Common.Library;

public class ViewModelBase : CommonBase
{
  #region Private Variables
  private bool _IsAdding;
  private int _RowsAffected;
  private bool _IsDataProcessing;
  private bool _ExceptionHappened;
  private bool _HasValidationErrors;
  private ObservableCollection<ValidationMessage> _ValidationMessages = new();
  #endregion

  #region Public Properties
  /// <summary>
  /// Get/Set whether or not the page is in add mode
  /// </summary>
  public bool IsAdding
  {
    get { return _IsAdding; }
    set
    {
      _IsAdding = value;
      RaisePropertyChanged(nameof(IsAdding));
    }
  }

  /// <summary>
  /// Get/Set the Numbers of Rows Affected by the last operation
  /// </summary>
  public int RowsAffected
  {
    get { return _RowsAffected; }
    set
    {
      _RowsAffected = value;
      RaisePropertyChanged(nameof(RowsAffected));
    }
  }

  /// <summary>
  /// Get/Set if data is being processed
  /// </summary>
  public bool IsDataProcessing
  {
    get { return _IsDataProcessing; }
    set
    {
      _IsDataProcessing = value;
      RaisePropertyChanged(nameof(IsDataProcessing));
    }
  }

  /// <summary>
  /// Get/Set whether or not the page had exception occur
  /// </summary>
  public bool ExceptionHappened
  {
    get { return _ExceptionHappened; }
    set
    {
      _ExceptionHappened = value;
      RaisePropertyChanged(nameof(ExceptionHappened));
    }
  }

  /// <summary>
  /// Get/Set if the current selected entity has passed all validation
  /// </summary>
  public bool HasValidationErrors
  {
    get { return _HasValidationErrors; }
    set
    {
      _HasValidationErrors = value;
      RaisePropertyChanged(nameof(HasValidationErrors));
    }
  }

  /// <summary>
  /// Get/Set a list of validation messages to display
  /// </summary>
  public ObservableCollection<ValidationMessage> ValidationMessages
  {
    get { return _ValidationMessages; }
    set
    {
      _ValidationMessages = value;
      RaisePropertyChanged(nameof(ValidationMessages));
    }
  }
  #endregion

  #region BeginProcessing Method
  protected virtual void BeginProcessing()
  {
    InfoMessage = string.Empty;
    LastErrorMessage = string.Empty;
    LastException = null;
    RowsAffected = 0;
    IsDataProcessing = true;
    ExceptionHappened = false;
    HasValidationErrors = false;
    ValidationMessages.Clear();
  }
  #endregion

  #region EndProcessing Methods
  protected virtual void EndProcessing()
  {
    IsDataProcessing = false;
    if (!string.IsNullOrEmpty(LastErrorMessage) ||
        LastException != null) {
      ExceptionHappened = true;
    }
    HasValidationErrors = ValidationMessages.Count > 0;
  }
  #endregion

  #region Validate Method
  public bool Validate<T>(T entity)
  {
    ValidationMessages.Clear();

    if (entity != null) {
      // Create instance of ValidationContext object
      ValidationContext context = new(entity, serviceProvider: null, items: null);
      List<ValidationResult> results = new();

      // Call TryValidateObject() method
      if (!Validator.TryValidateObject(entity, context, results, true)) {
        // Get validation results
        foreach (ValidationResult item in results) {
          string propName = string.Empty;
          if (item.MemberNames.Any()) {
            propName = ((string[])item.MemberNames)[0];
          }
          // Build new ValidationMessage object
          ValidationMessage msg = new() {
            Message = item.ErrorMessage ?? string.Empty,
            PropertyName = propName
          };

          // Add validation object to list
          ValidationMessages.Add(msg);
        }
      }
    }

    HasValidationErrors = ValidationMessages.Count > 0;

    return !HasValidationErrors;
  }
  #endregion

  #region PublishException Method
  protected virtual void PublishException(Exception ex)
  {
    LastException = ex;

    System.Diagnostics.Debug.WriteLine(ex.ToString());
  }
  #endregion
}
