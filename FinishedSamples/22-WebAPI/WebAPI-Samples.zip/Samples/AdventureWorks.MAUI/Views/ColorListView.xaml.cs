namespace AdventureWorks.MAUI.Views;

public partial class ColorListView : ContentPage
{
	public ColorListView()
	{
		InitializeComponent();
	}
}