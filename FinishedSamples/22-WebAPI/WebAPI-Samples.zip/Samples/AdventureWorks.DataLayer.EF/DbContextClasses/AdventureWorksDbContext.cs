﻿using AdventureWorks.EntityLayer;
using Microsoft.EntityFrameworkCore;

// TODO: Add the NuGet Package 'Microsoft.EntityFrameworkCore.SqlServer'

namespace AdventureWorks.DataLayer;

public partial class AdventureWorksDbContext : DbContext
{
  public AdventureWorksDbContext(DbContextOptions<AdventureWorksDbContext> options) : base(options)
  {
  }

  // Add your DbSet Classes for Tables/Views here
  public virtual DbSet<PhoneType> PhoneTypes { get; set; }
  public virtual DbSet<User> Users { get; set; }
  public virtual DbSet<Product> Products { get; set; }

  protected override void OnModelCreating(ModelBuilder modelBuilder)
  {
    // TODO: Add any additional code you need here

    base.OnModelCreating(modelBuilder);
  }
}
