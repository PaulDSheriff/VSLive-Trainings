using AdventureWorks.EntityLayer;

namespace AdventureWorks.MAUI.Views;

public partial class UserDetailView : ContentPage
{
	public UserDetailView()
	{
		InitializeComponent();

    ViewModel = (User)this.Resources["viewModel"];
  }

  public User ViewModel { get; set; }

  private void SaveButton_Clicked(object sender, EventArgs e)
  {
    System.Diagnostics.Debugger.Break();
  }
}