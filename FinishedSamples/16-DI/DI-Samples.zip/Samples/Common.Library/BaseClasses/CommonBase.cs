﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Common.Library;

public abstract class CommonBase : INotifyPropertyChanged
{
  #region Constructor
  /// <summary>
  /// Constructor for CommonBase class
  /// </summary>
  public CommonBase()
  {
    Init();
  }
  #endregion

  #region Private/Protected Variables
  private string _InfoMessage = string.Empty;
  private string _LastErrorMessage = string.Empty;
  private Exception? _LastException = null;

  protected const string REPO_NOT_SET = "The Repository Object is not Set.";
  #endregion

  #region Public Properties
  /// <summary>
  /// Get/Set the last informational message to display
  /// </summary>
  [NotMapped]
  [JsonIgnore]
  public string InfoMessage
  {
    get { return _InfoMessage; }
    set
    {
      _InfoMessage = value;
      RaisePropertyChanged(nameof(InfoMessage));
    }
  }

  /// <summary>
  /// Get/Set the last error message from the last operation
  /// </summary>
  [NotMapped]
  [JsonIgnore]
  public string LastErrorMessage
  {
    get { return _LastErrorMessage; }
    set
    {
      _LastErrorMessage = value;
      RaisePropertyChanged(nameof(LastErrorMessage));
    }
  }

  /// <summary>
  /// Get/Set the last exception object from the last operation
  /// Sets the ErrorMessage to LastException.Message if ErrorMessage is blank
  /// </summary>
  [NotMapped]
  [JsonIgnore]
  public Exception? LastException
  {
    get { return _LastException; }
    set
    {
      _LastException = value;
      if (_LastException != null) {
        if (string.IsNullOrEmpty(LastErrorMessage)) {
          LastErrorMessage = _LastException.Message;
        }
      }
      RaisePropertyChanged(nameof(LastException));
    }
  }
  #endregion

  #region Init Method
  /// <summary>
  /// Initialize any properties of this class
  /// </summary>
  public virtual void Init()
  {
  }
  #endregion

  #region RaisePropertyChanged Method
  /// <summary>
  /// Event used to raise changes to any bound UI objects
  /// </summary>
  public event PropertyChangedEventHandler? PropertyChanged;

  public virtual void RaisePropertyChanged(string propertyName)
  {
    this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
  }
  #endregion
}
