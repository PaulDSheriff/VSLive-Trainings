﻿namespace LINQLab;

public partial class Program {
  public static void Main() {
    Lab03();
  }
}
