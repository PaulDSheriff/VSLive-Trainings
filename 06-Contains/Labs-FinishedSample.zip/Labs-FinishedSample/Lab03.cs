﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab03() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    SongComparer sc = new();
    bool value;

    // Query Syntax
    value = (from row in songs select row)
            .Contains(new Song { SongId = 115 }, sc);

    // Method Syntax
    //value = songs
    //        .Contains(new Song { SongId = 115 }, sc);

    // Display Result
    Console.WriteLine();
    Console.WriteLine($"Result: {value}");

    // Pause for Results
    Console.ReadKey();
  }
}
