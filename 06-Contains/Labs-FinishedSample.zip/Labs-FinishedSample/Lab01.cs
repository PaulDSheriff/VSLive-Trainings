﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab01() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    bool value;

    // Query Syntax
    value = (from row in songs select row)
            .All(row => row.Rating > 0);

    // Method Syntax
    //value = songs
    //        .All(row => row.Rating > 0);

    // Display Result
    Console.WriteLine();
    Console.WriteLine($"Result: {value}");

    // Pause for Results
    Console.ReadKey();
  }
}
