#nullable disable

using LINQLab.EntityClasses;

namespace LINQLab.RepositoryClasses;

public partial class MusicKindRepository
{
  #region GetAll Method
  /// <summary>
  /// Get all MusicKind objects
  /// </summary>
  /// <returns>A list of MusicKind objects</returns>
  public static List<MusicKind> GetAll()
  {
    return new List<MusicKind>
    {
      new MusicKind {
         KindId = 1,
         Kind = @"iTunes LP",
         LastUpdated = Convert.ToDateTime("8/9/2012 12:00:00 AM"),
      },
      new MusicKind {
         KindId = 2,
         Kind = @"Protected AAC audio file",
         LastUpdated = Convert.ToDateTime("9/6/2011 11:28:31 AM"),
      },
      new MusicKind {
         KindId = 3,
         Kind = @"MPEG audio file",
         LastUpdated = Convert.ToDateTime("9/6/2011 11:28:31 AM"),
      },
      new MusicKind {
         KindId = 4,
         Kind = @"Purchased AAC audio file",
         LastUpdated = Convert.ToDateTime("9/6/2011 11:28:31 AM"),
      },
      new MusicKind {
         KindId = 5,
         Kind = @"Purchased MPEG-4 video file",
         LastUpdated = Convert.ToDateTime("9/6/2011 11:28:31 AM"),
      },
      new MusicKind {
         KindId = 6,
         Kind = @"Protected MPEG-4 video file",
         LastUpdated = Convert.ToDateTime("9/6/2011 11:28:31 AM"),
      },
      new MusicKind {
         KindId = 7,
         Kind = @"PDF document",
         LastUpdated = Convert.ToDateTime("9/6/2011 11:28:31 AM"),
      },
      new MusicKind {
         KindId = 8,
         Kind = @"AAC audio file",
         LastUpdated = Convert.ToDateTime("9/6/2011 11:28:31 AM"),
      },
      new MusicKind {
         KindId = 10,
         Kind = @"A New Kind",
         LastUpdated = Convert.ToDateTime("8/9/2012 12:00:00 AM"),
      }
    };
  }
  #endregion

  #region Get Method
  /// <summary>
  /// Get a single MusicKind object
  /// </summary>
  /// <param name="id">The value to locate</param>
  /// <returns>A valid MusicKind object object, or null if not found</returns>
  public MusicKind Get(int id) {
    return GetAll().Where(row => row.KindId == id).FirstOrDefault();
  }
  #endregion

  #region Insert Method
  /// <summary>
  /// Insert a new MusicKind object
  /// </summary>
  /// <param name="entity">The data to insert</param>
  /// <returns>The inserted MusicKind object</returns>
  public MusicKind Insert(MusicKind entity) {
    GetAll().Add(entity);

    // TODO: Insert into data store
    entity.KindId = GetAll().Max(row => row.KindId) + 1;

    return entity;
  }
  #endregion

  #region Update Method
  /// <summary>
  /// Update existing MusicKind object
  /// </summary>
  /// <param name="entity">The data to update</param>
  /// <returns>The updated MusicKind object</returns>
  public MusicKind Update(MusicKind entity) {
    // Look up the data by the specified id
    MusicKind current = Get(entity.KindId);

    if (current != null) {
      // TODO: Update the entity
      current.Kind = entity.Kind;
      current.LastUpdated = entity.LastUpdated;

      // TODO: Update data store

    }

    return current;
  }
  #endregion

  #region Delete Method
  /// <summary>
  /// Delete a MusicKind object
  /// </summary>
  /// <param name="id">The value to delete</param>
  /// <returns>True if delete, false if not found</returns>
  public bool Delete(int id) {
    bool ret = false;

    // Look up the data by the specified id
    MusicKind current = Get(id);

    if (current != null) {
      // TODO: Delete data from data store
      GetAll().RemoveAll(row => row.KindId == id);
      ret = true;
    }

    return ret;
  }
  #endregion
}