﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab02() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    bool value;

    // Query Syntax
    value = (from row in songs select row)
            .Any(row => row.Rating > 90);

    // Method Syntax
    //value = songs
    //        .Any(row => row.Rating > 90);

    // Display Result
    Console.WriteLine();
    Console.WriteLine($"Result: {value}");

    // Pause for Results
    Console.ReadKey();
  }
}
