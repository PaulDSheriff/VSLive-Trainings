﻿Description of Samples
--------------------------------------------------
01-ContainsQuery() - Use the Contains() method to see if a collection contains a specific value
02-ContainsMethod() - Use the Contains() method to see if a collection contains a specific value

03-ContainsComparerQuery() - Use the Contains() method to see if a collection contains a specific value. When comparing classes, you need to write a EqualityComparer class.
04-ContainsComparerMethod() - Use the Contains() method to see if a collection contains a specific value. When comparing classes, you need to write a EqualityComparer class.