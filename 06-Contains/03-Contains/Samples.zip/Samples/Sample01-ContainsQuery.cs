﻿namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// Use the Contains() method to see if a collection contains a specific value
  /// </summary>
  public static void ContainsQuery() {
    List<int> numbers = new() { 1, 2, 3, 4, 5 };
    bool value;

    // Write Query Syntax Here
    value = (from row in numbers
             select row).Contains(3);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
