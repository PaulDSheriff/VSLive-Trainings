﻿using LINQSamples;

// Call Sample Method
Sample01.ContainsQuery();
//Sample02.ContainsMethod();
//Sample03.ContainsComparerMethod();
//Sample04.ContainsComparerMethod();