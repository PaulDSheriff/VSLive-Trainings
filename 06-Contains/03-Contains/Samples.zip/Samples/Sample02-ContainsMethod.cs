﻿namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// Use the Contains() method to see if a collection contains a specific value
  /// </summary>
  public static void ContainsMethod() {
    List<int> numbers = new() { 1, 2, 3, 4, 5 };
    bool value;

    // Write Method Syntax Here
    value = numbers.Contains(3);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
