﻿namespace LINQSamples;

public class Sample04 {
  /// <summary>
  /// Use the Contains() operator to see if a collection contains a specific value.
  /// When comparing classes, you need to write a EqualityComparer class.
  /// </summary>
  public static void ContainsComparerMethod() {
    List<Product> products = ProductRepository.GetAll();
    ProductIdComparer pc = new();
    bool value;

    // Write Method Syntax Here
    value = products.Contains(new Product { ProductID = 744 }, pc);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
