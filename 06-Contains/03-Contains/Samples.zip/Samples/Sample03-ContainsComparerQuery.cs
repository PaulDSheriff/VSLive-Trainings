﻿namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// Use the Contains() method to see if a collection contains a specific value. When comparing classes, you need to write a EqualityComparer class.
  /// </summary>
  public static void ContainsComparerMethod() {
    List<Product> products = ProductRepository.GetAll();
    ProductIdComparer pc = new();
    bool value;

    // Write Query Syntax Here
    value = (from row in products
             select row)
             .Contains(new Product { ProductID = 744 }, pc);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
