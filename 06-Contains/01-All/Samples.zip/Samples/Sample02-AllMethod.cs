﻿namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// Use All() to see if all items in a collection meet a specified condition
  /// </summary>
  public static void AllMethod() {
    List<Product> products = ProductRepository.GetAll();
    bool value;

    // Write Method Syntax Here
    value = products.All(row => row.ListPrice > row.StandardCost);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
