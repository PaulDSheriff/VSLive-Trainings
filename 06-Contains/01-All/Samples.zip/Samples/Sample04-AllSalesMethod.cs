﻿namespace LINQSamples;

public class Sample04 {
  /// <summary>
  /// Use All() to see if all items in a collection meet a specified condition
  /// </summary>
  public static void AllSalesMethod() {
    List<SalesOrder> sales = SalesOrderRepository.GetAll();
    bool value;

    // Write Method Syntax Here
    value = sales.All(row => row.OrderQty >= 1);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
