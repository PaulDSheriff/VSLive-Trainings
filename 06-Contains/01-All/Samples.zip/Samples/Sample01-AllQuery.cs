﻿namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// Use All() method to see if all items in a collection meet a specified condition
  /// </summary>
  public static void AllQuery() {
    List<Product> products = ProductRepository.GetAll();
    bool value;

    // Write Query Syntax Here
    value = (from row in products
             select row)
             .All(row => row.ListPrice > row.StandardCost);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
