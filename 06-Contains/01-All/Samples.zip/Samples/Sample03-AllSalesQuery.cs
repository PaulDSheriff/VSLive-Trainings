﻿namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// Use All() to see if all items in a collection meet a specified condition
  /// </summary>
  public static void AllSalesQuery() {
    List<SalesOrder> sales = SalesOrderRepository.GetAll();
    bool value;

    // Write Query Syntax Here
    value = (from row in sales
             select row)
             .All(row => row.OrderQty >= 1);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
