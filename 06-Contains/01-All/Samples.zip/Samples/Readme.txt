﻿Description of Samples
--------------------------------------------------
01-AllQuery() - Use All() method to see if all items in a collection meet a specified condition
02-AllMethod() - Use All() method to see if all items in a collection meet a specified condition

03-AllSalesQuery() - Use All() method to see if all items in a collection meet a specified condition
04-AllSalesMethod() - Use All() method to see if all items in a collection meet a specified condition