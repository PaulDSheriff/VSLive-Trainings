﻿using LINQSamples;

// Call Sample Method
Sample01.AllQuery();
//Sample02.AllMethod();
//Sample03.AllSalesQuery();
//Sample04.AllSalesMethod();