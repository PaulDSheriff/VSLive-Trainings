﻿Description of Samples
--------------------------------------------------
01-AnyQuery() - Use the Any() method to see if at least one item in a collection meets a specified condition
02-AnyMethod() - Use the Any() method to see if at least one item in a collection meets a specified condition
