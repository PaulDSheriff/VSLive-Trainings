﻿using LINQSamples;

// Call Sample Method
Sample01.AnyQuery();
Sample02.AnyMethod();
