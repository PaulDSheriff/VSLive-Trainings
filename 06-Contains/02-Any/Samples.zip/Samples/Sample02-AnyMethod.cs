﻿namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// Use the Any() method to see if at least one item in a collection meets a specified condition
  /// </summary>
  public static void AnyMethod() {
    List<SalesOrder> sales = SalesOrderRepository.GetAll();
    bool value;

    // Write Method Syntax Here
    value = sales.Any(row => row.LineTotal > 10000);

    // Check for any sales
    if (sales.Any()) {
      Console.WriteLine("There are some sales");
    }
    if (sales.Count > 0) {
      Console.WriteLine("There are some sales");
    }

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
