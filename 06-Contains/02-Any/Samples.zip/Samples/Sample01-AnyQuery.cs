﻿namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// Use the Any() method to see if at least one item in a collection meets a specified condition
  /// </summary>
  public static void AnyQuery() {
    List<SalesOrder> sales = SalesOrderRepository.GetAll();
    bool value;

    // Write Query Syntax Here
    value = (from row in sales
             select row)
             .Any(row => row.LineTotal > 10000);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
