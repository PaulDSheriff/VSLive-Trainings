﻿using AdvWorks.Common;
using AdvWorks.EntityLayer;

namespace AdvWorks.DataLayer
{
  public class ProductRepository : IRepository<Product, ProductSearch>
  {
    #region Constructor
    public ProductRepository(AdvWorksDbContext context)
    {
      _DbContext = context;
    }
    #endregion

    #region Private Variables
    private AdvWorksDbContext _DbContext;
    #endregion

    #region Public Properties
    public IQueryable<Product> QueryObject { get; set; }
    #endregion

    public Product Get(int id)
    {
      return _DbContext.Products.Where(row => row.ProductID == id).FirstOrDefault();
    }

    public IQueryable<Product> Search(ProductSearch search)
    {
      QueryObject = _DbContext.Products;

      // Add WHERE clause(s)
      QueryObject = AddWhereClause(QueryObject, search);

      // Add ORDER BY clause(s)
      QueryObject = AddOrderByClause(QueryObject, search);

      return QueryObject;
    }

    public IQueryable<Product> AddWhereClause(IQueryable<Product> query, ProductSearch search) {
      // Perform Searching      
      if (!string.IsNullOrEmpty(search.Name)) {
        query = query.Where(row => row.Name.StartsWith(search.Name));
      }
      if (search.ListPrice.HasValue) {
        query = query.Where(row => row.ListPrice >= search.ListPrice);
      }

      return query;
    }

    public IQueryable<Product> AddOrderByClause(IQueryable<Product> query, ProductSearch search) {
      query = query.OrderBy(row => row.Name);

      return query;
    }

    public int Count(ProductSearch search) {
      throw new NotImplementedException();
    }

    public Product CreateEmpty()
    {
      throw new NotImplementedException();
    }

    public Product Insert(Product entity)
    {
      throw new NotImplementedException();
    }

    public Product Update(Product entity)
    {
      throw new NotImplementedException();
    }

    public bool Delete(int id)
    {
      throw new NotImplementedException();
    }
  }
}
