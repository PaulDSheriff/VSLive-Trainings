namespace AdvWorks.EntityLayer
{
  public partial class Color
  {
    public int ColorId { get; set; }
    public string ColorName { get; set; }
    public bool IsActive { get; set; }

    public override string ToString() {
      return $"{ColorName} ({IsActive})";
    }
  }
}