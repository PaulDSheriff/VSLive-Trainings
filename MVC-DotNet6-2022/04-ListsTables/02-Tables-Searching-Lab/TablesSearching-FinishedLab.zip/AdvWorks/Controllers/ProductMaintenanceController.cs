﻿using AdvWorks.Common;
using AdvWorks.EntityLayer;
using AdvWorks.ViewModelLayer;
using Microsoft.AspNetCore.Mvc;

namespace AdvWorks.Controllers {
  public class ProductMaintenanceController : Controller {
    public ProductMaintenanceController(ILogger<ProductMaintenanceController> logger,
      IRepository<Product, ProductSearch> repo) {
      _logger = logger;
      _repo = repo;
    }

    private readonly ILogger<ProductMaintenanceController> _logger;
    private readonly IRepository<Product, ProductSearch> _repo;

    [HttpGet]
    public IActionResult ProductMaintenance() {
      // Create view model passing in repository
      ProductViewModel vm = new(_repo);

      // Call method to load products
      vm.Search();

      return View(vm);
    }

    [HttpGet]
    public IActionResult ProductEdit(int id) {
      // Create view model passing in repository
      ProductViewModel vm = new(_repo);

      // Call method to load a product
      vm.Get(id);

      return View("ProductMaintenance", vm);
    }

    [HttpGet]
    public IActionResult ProductSearch(ProductViewModel vm) {
      vm.Repository = _repo;

      // Call method to search for products
      vm.Search();

      return View("ProductMaintenance", vm);
    }
  }
}
