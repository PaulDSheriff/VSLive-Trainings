﻿using Microsoft.AspNetCore.Mvc;
using AdvWorks.Common;
using AdvWorks.EntityLayer;
using AdvWorks.ViewModelLayer;

namespace AdvWorks.Controllers {
  public class ListsController : Controller {
    public ListsController(IRepository<Product, ProductSearch> productRepo) {
      _productRepository = productRepo;
    }

    private readonly IRepository<Product, ProductSearch> _productRepository;

    public IActionResult Index() {
      return View();
    }

    [HttpGet]
    public IActionResult Sample01() {
      // Create view model passing in repository
      ProductViewModel vm = new(_productRepository);

      // Call method to load products
      vm.Search();

      return View(vm);
    }

    [HttpGet]
    public IActionResult Sample02() {
      // Create view model passing in repository
      ProductViewModel vm = new(_productRepository);

      // Call method to load products
      vm.Search();

      return View(vm);
    }

    [HttpGet]
    public IActionResult Sample03() {
      // Create view model passing in repository
      ProductViewModel vm = new(_productRepository);

      // Call method to load products
      vm.Search();

      return View(vm);
    }

  }
}
