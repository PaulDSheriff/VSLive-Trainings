using System.ComponentModel.DataAnnotations;

namespace AdvWorks.EntityLayer
{
  public class ProductSearch
  {
    [Display(Name = "Product Name or Partial Name")]
    public string Name { get; set; }

    [Display(Name = "Price Greater Than or Equal To")]
    public decimal? ListPrice { get; set; }
  }
}
