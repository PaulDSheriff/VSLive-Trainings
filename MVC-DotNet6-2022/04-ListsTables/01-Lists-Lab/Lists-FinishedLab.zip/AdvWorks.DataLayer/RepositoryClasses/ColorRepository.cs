using AdvWorks.Common;
using AdvWorks.EntityLayer;

namespace AdvWorks.DataLayer
{
  public partial class ColorRepository : IRepository<Color, ColorSearch>
  {
    #region Constructor
    public ColorRepository(AdvWorksDbContext context) {
      _DbContext = context;
    }
    #endregion

    #region Private Variables
    private AdvWorksDbContext _DbContext;
    #endregion

    #region Public Properties
    public IQueryable<Color> QueryObject { get; set; }
    #endregion

    #region Get Method
    private List<Color> Get() {
      return new List<Color> {
        new Color {
          ColorId = 0,
          ColorName = "",
          IsActive = true
        },
        new Color {
          ColorId = 1,
          ColorName = "Red",
          IsActive = true
        },
          new Color {
          ColorId = 2,
          ColorName = "Blue",
          IsActive = true
        },
          new Color {
          ColorId = 3,
          ColorName = "Green",
          IsActive = true
        },
          new Color {
          ColorId = 4,
          ColorName = "Yellow",
          IsActive = false
        },
          new Color {
          ColorId = 5,
          ColorName = "Grey",
          IsActive = true
        },
          new Color {
          ColorId = 6,
          ColorName = "Black",
          IsActive = true
        },
      };
    }
    #endregion

    public virtual Color Get(int id) {
      // Simulate getting colors from database
      return Get().Where(row => row.ColorId == id).FirstOrDefault();
    }

    public IQueryable<Color> Search(ColorSearch search) {
      // Simulate getting colors from database
      QueryObject = Get().AsQueryable<Color>();

      // Add WHERE clause(s)
      QueryObject = AddWhereClause(QueryObject, search);

      // Add ORDER BY clause(s)
      QueryObject = AddOrderByClause(QueryObject, search);

      return QueryObject;
    }

    public IQueryable<Color> AddWhereClause(IQueryable<Color> query, ColorSearch search) {
      return query;
    }

    public IQueryable<Color> AddOrderByClause(IQueryable<Color> query, ColorSearch search) {
      query = query.OrderBy(row => row.ColorName);

      return query;
    }

    public int Count(ColorSearch search) {
      throw new NotImplementedException();
    }

    public Color CreateEmpty()
    {
      throw new NotImplementedException();
    }

    public Color Insert(Color entity) {
      throw new NotImplementedException();
    }

    public Color Update(Color entity)
    {
      throw new NotImplementedException();
    }

    public bool Delete(int id) {
      throw new NotImplementedException();
    }
  }
}