using AdvWorks.EntityLayer;
using Microsoft.EntityFrameworkCore;

namespace AdvWorks.DataLayer
{
  public partial class AdvWorksDbContext : DbContext
  {
    public AdvWorksDbContext(DbContextOptions<AdvWorksDbContext> options) : base(options)
    {
    }

    public virtual DbSet<Product> Products { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
      base.OnModelCreating(modelBuilder);
    }
  }
}
