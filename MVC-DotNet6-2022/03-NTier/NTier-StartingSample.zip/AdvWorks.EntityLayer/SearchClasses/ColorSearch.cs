using System.ComponentModel.DataAnnotations;

namespace AdvWorks.EntityLayer
{
  public partial class ColorSearch
  {
    [Display(Name = "Color Name or Partial Name")]
    public string ColorName { get; set; }
  }
}
