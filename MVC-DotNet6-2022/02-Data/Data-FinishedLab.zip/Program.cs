using Microsoft.EntityFrameworkCore;
using DataSamples.Models;
using DataSamples.RespositoryClasses;

//*************************************
// Configure Services
//*************************************
var builder = WebApplication.CreateBuilder(args);

// Add MVC services to the Web Application
builder.Services.AddControllersWithViews();

// Read in the connection string from the appSettings.json file
string connString = builder.Configuration.GetConnectionString("DefaultConnection");

// Setup the AdvWorks DB Context
builder.Services.AddDbContext<AdvWorksLTDbContext>(options => options.UseSqlServer(connString));

// Create a scoped version of Product Repository
builder.Services.AddScoped<IProductRepository, ProductRepository>();

//*************************************
// Configure Application
// For a list of what services need to be started, in what order, see the following link
// https://docs.microsoft.com/en-us/aspnet/core/fundamentals/middleware/?view=aspnetcore-6.0#middleware-order
//*************************************
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
  app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
