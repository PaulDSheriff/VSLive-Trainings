﻿using DataSamples.EntityClasses;
using Microsoft.EntityFrameworkCore;

namespace DataSamples.Models
{
  public class AdvWorksLTDbContext : DbContext
  {
    public AdvWorksLTDbContext(
      DbContextOptions<AdvWorksLTDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Product> Products { get; set; }

    protected override void OnModelCreating(
      ModelBuilder modelBuilder)
    {
      base.OnModelCreating(modelBuilder);
    }
  }
}