using DataSamples.EntityClasses;
using DataSamples.RespositoryClasses;

namespace DataSamples.ViewModelClasses
{
  public class ProductViewModel
  {
    #region Constructors
    public ProductViewModel()
    {
    }

    public ProductViewModel(IProductRepository repo)
    {
      Repository = repo;
    }
    #endregion

    #region Properties
    public IProductRepository Repository { get; set; }
    public List<Product> Products { get; set; }
    #endregion

    #region LoadProducts Method
    public virtual void LoadProducts()
    {
      Products = Repository.Get().OrderBy(p => p.Name).ToList();
    }
    #endregion
  }
}