﻿using DataSamples.EntityClasses;
using DataSamples.Models;

namespace DataSamples.RespositoryClasses
{
  public class ProductRepository : IProductRepository
  {
    public ProductRepository(AdvWorksLTDbContext context)
    {
      _DbContext = context;
    }
    private AdvWorksLTDbContext _DbContext;

    public List<Product> Get()
    {
      return _DbContext.Products.ToList();
    }
  }
}
