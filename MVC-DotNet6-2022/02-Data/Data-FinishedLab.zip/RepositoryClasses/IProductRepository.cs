﻿using DataSamples.EntityClasses;

namespace DataSamples.RespositoryClasses
{
  public interface IProductRepository
  {
    List<Product> Get();
  }
}
