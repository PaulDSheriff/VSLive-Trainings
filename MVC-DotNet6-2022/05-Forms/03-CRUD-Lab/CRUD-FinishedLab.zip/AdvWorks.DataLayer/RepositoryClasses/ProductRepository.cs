﻿using AdvWorks.Common;
using AdvWorks.EntityLayer;

namespace AdvWorks.DataLayer
{
  public class ProductRepository : IRepository<Product, ProductSearch>
  {
    #region Constructor
    public ProductRepository(AdvWorksDbContext context)
    {
      _DbContext = context;
    }
    #endregion

    #region Private Variables
    private AdvWorksDbContext _DbContext;
    #endregion

    #region Public Properties
    public IQueryable<Product> QueryObject { get; set; }
    #endregion

    public Product Get(int id)
    {
      return _DbContext.Products.Where(row => row.ProductID == id).FirstOrDefault();
    }

    public IQueryable<Product> Search(ProductSearch search)
    {
      QueryObject = _DbContext.Products;

      // Add WHERE clause(s)
      QueryObject = AddWhereClause(QueryObject, search);

      // Add ORDER BY clause(s)
      QueryObject = AddOrderByClause(QueryObject, search);

      return QueryObject;
    }

    public IQueryable<Product> AddWhereClause(IQueryable<Product> query, ProductSearch search) {
      // Perform Searching      
      if (!string.IsNullOrEmpty(search.Name)) {
        query = query.Where(row => row.Name.StartsWith(search.Name));
      }
      if (search.ListPrice.HasValue) {
        query = query.Where(row => row.ListPrice >= search.ListPrice);
      }

      return query;
    }

    public IQueryable<Product> AddOrderByClause(IQueryable<Product> query, ProductSearch search) {
      query = query.OrderBy(row => row.Name);

      return query;
    }

    public int Count(ProductSearch search) {
      throw new NotImplementedException();
    }

    public List<Product> GetByColor(string color) {
      // Get Products by Color
      return _DbContext.Products.Where(row => row.Color == color).ToList();
    }

    public Product CreateEmpty()
    {
      return new Product {
        IsActive = true,
        Name = string.Empty,
        ProductNumber = string.Empty,
        Color = "Black",
        StandardCost = 0,
        ListPrice = 0,
        Size = string.Empty,
        Weight = null,
        SellStartDate = DateTime.Now,
        SellEndDate = null,
        DiscontinuedDate = null,
      };
    }

    public Product Insert(Product entity)
    {
      // Add new entity to Products DbSet
      _DbContext.Products.Add(entity);

      // Save changes in database
      _DbContext.SaveChanges();

      return entity;
    }

    public Product Update(Product entity)
    {
      // Update entity in Products DbSet
      _DbContext.Products.Update(entity);

      // Save changes in database
      _DbContext.SaveChanges();

      return entity;

    }

    public bool Delete(int id)
    {
      // Locate the entity to delete in the Products DbSet
      _DbContext.Products.Remove(_DbContext.Products.Find(id));

      // Save changes in database
      _DbContext.SaveChanges();

      return true;
    }
  }
}
