﻿using AdvWorks.Common;
using AdvWorks.EntityLayer;
using AdvWorks.ViewModelLayer;
using Microsoft.AspNetCore.Mvc;

namespace AdvWorks.Controllers {
  public class ProductMaintenanceController : Controller {
    public ProductMaintenanceController(ILogger<ProductMaintenanceController> logger,
      IRepository<Product, ProductSearch> repo, IRepository<Color, ColorSearch> colorRepo) {
      _logger = logger;
      _repo = repo;
      _colorRepo = colorRepo;
    }

    private readonly ILogger<ProductMaintenanceController> _logger;
    private readonly IRepository<Product, ProductSearch> _repo;
    private readonly IRepository<Color, ColorSearch> _colorRepo;

    [HttpGet]
    public IActionResult ProductMaintenance() {
      // Create view model passing in repository
      ProductViewModel vm = new(_repo);

      // Call method to load products
      vm.Search();

      return View(vm);
    }

    [HttpGet]
    public IActionResult ProductAdd() {
      // Create view model passing in repository
      ProductViewModel vm = new(_repo, _colorRepo) {
        IsDetailVisible = true
      };

      // Call method to create an empty product to add
      vm.CreateEmptyProduct();

      // Call method to load colors
      vm.LoadColors();

      return View("ProductMaintenance", vm);
    }

    [HttpGet]
    public IActionResult ProductEdit(int id) {
      // Create view model passing in repository
      ProductViewModel vm = new(_repo, _colorRepo);

      // Call method to load a product
      vm.Get(id);

      return View("ProductMaintenance", vm);
    }

    [HttpGet]
    public IActionResult ProductDelete(int id) {
      // Create view model passing in repository
      ProductViewModel vm = new(_repo);

      // Call method to delete a product
      vm.DeleteProduct(id);

      return RedirectToAction("ProductMaintenance");
    }


    [HttpGet]
    public IActionResult ProductSearch(ProductViewModel vm) {
      vm.Repository = _repo;

      // Call method to search for products
      vm.Search();

      return View("ProductMaintenance", vm);
    }

    [HttpPost]
    public IActionResult ProductMaintenance(ProductViewModel vm) {
      vm.Repository = _repo;
      vm.ColorRepository = _colorRepo;


      if (ModelState.IsValid) {
        // Save the Product
        vm.Save();

        // Redirect back to product list
        return RedirectToAction("ProductMaintenance");
      }
      else {
        vm.LoadColors();
        vm.IsDetailVisible = true;

        return View(vm);
      }
    }
  }
}
