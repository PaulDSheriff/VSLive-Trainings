﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace AdvWorks.Controllers {
  public class CategoryMaintenanceController : Controller {
    public CategoryMaintenanceController(ILogger<CategoryMaintenanceController> logger) {
      _logger = logger;
    }

    private readonly ILogger<CategoryMaintenanceController> _logger;

    public IActionResult CategoryMaintenance() {
      return View();
    }
  }
}
