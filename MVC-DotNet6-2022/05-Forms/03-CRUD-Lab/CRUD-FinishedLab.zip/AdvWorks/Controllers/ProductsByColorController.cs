﻿using AdvWorks.Common;
using AdvWorks.EntityLayer;
using AdvWorks.ViewModelLayer;
using Microsoft.AspNetCore.Mvc;

namespace AdvWorks.Controllers {
  public class ProductsByColorController : Controller {
    public ProductsByColorController(
             ILogger<ProductsByColorController> logger,
             IRepository<Product, ProductSearch> repo, IRepository<Color, ColorSearch> colorRepo) {
      _logger = logger;
      _repo = repo;
      _colorRepo = colorRepo;
    }

    private readonly ILogger<ProductsByColorController> _logger;
    private readonly IRepository<Product, ProductSearch> _repo;
    private IRepository<Color, ColorSearch> _colorRepo;

    [HttpGet]
    public IActionResult Index() {
      // Create view model passing in repository
      ProductViewModel vm = new(_repo, _colorRepo);

      vm.LoadColors();
      vm.SelectedProduct.Color = "Black";
      vm.LoadProductsByColor(vm.SelectedProduct.Color);

      return View(vm);
    }

    [HttpGet]
    public IActionResult ProductsByColor(ProductViewModel vm) {
      // Pass in repositories
      vm.Repository = _repo;
      vm.ColorRepository = _colorRepo;

      vm.LoadProductsByColor(vm.SelectedProduct.Color);
      vm.LoadColors();

      return View("Index", vm);
    }
  }
}
