﻿namespace AdvWorks.Common
{
  public class AppSettings
  {
    public int CompanyId { get; set; }
    public string CompanyName { get; set; }
  }
}
