using AdvWorks.Common;
using AdvWorks.EntityLayer;
using AdvWorks.DataLayer;

namespace AdvWorks.ViewModelLayer {
  public class ProductViewModel : ViewModelBase {
    #region Constructors
    /// <summary>
    ///  NOTE: You need to have a parameterless constructor for Post-Backs in MVC    
    /// </summary>
    public ProductViewModel() : base() {
    }

    public ProductViewModel(IRepository<Product, ProductSearch> repository) : base() {
      Repository = repository;
    }

    public ProductViewModel(IRepository<Product, ProductSearch> repository, IRepository<Color, ColorSearch> colorRepository) : base() {
      Repository = repository;
      ColorRepository = colorRepository;
    }
    #endregion

    #region Properties
    public IRepository<Product, ProductSearch> Repository { get; set; }
    public List<Product> Products { get; set; }
    public Product SelectedProduct { get; set; }
    public ProductSearch SearchEntity { get; set; }
    public IRepository<Color, ColorSearch> ColorRepository { get; set; }
    public List<Color> Colors { get; set; }
    #endregion

    #region Init Method
    public override void Init() {
      base.Init();

      SelectedProduct = new();
      SearchEntity = new();
    }
    #endregion

    #region Search Method
    public virtual void Search() {
      IsDetailVisible = false;

      if (Repository == null) {
        throw new ApplicationException("Must set the Repository property.");
      }
      else {
        Products = Repository.Search(SearchEntity).ToList();
      }

      if (Products != null) {
        TotalRows = Products.Count;
      }
    }
    #endregion

    #region Get Method
    public virtual void Get(int id) {
      IsDetailVisible = true;

      if (Repository == null) {
        throw new ApplicationException("Must set the Repository property.");
      }
      else {
        SelectedProduct = Repository.Get(id);
      }

      if (SelectedProduct != null) {
        TotalRows = 1;
      }

      // Load Colors
      LoadColors();
    }
    #endregion

    #region CreateEmptyProduct Method
    public void CreateEmptyProduct() {
      IsAdding = true;
      // Set Selected Product to an empty product
      SelectedProduct = Repository.CreateEmpty();
    }
    #endregion

    #region Save Method
    public virtual bool Save() {
      if (IsAdding) {
        // Adding a new product
        Repository.Insert(SelectedProduct);
      }
      else {
        // Editing an existing product
        Repository.Update(SelectedProduct);
      }

      return true;
    }
    #endregion

    #region DeleteProduct Method
    public bool DeleteProduct(int id) {
      Repository.Delete(id);

      return true;
    }
    #endregion

    #region LoadColors Method
    public virtual void LoadColors() {
      if (ColorRepository == null) {
        throw new ApplicationException("Must set the ColorRepository property.");
      }
      else {
        Colors = ColorRepository.Search(new ColorSearch()).OrderBy(row => row.ColorName).ToList();
      }
    }
    #endregion

    #region LoadProductsByColor Method
    public virtual void LoadProductsByColor(string color) {
      IsDetailVisible = false;

      if (Repository == null) {
        throw new ApplicationException("Must set the Repository property.");
      }
      else {
        Products = ((ProductRepository)Repository)
         .GetByColor(color).OrderBy(row => row.Name).ToList();
      }

      if (Products != null) {
        TotalRows = Products.Count;
      }
    }
    #endregion
  }
}