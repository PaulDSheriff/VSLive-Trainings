using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace AdvWorks.EntityLayer
{
  [Table("Product", Schema = "SalesLT")]
  public partial class Product
  {
    public Product()
    {
      SellStartDate = DateTime.Now;
    }

    public int ProductID { get; set; }
    [Display(Name = "Product Name")]
    public string Name { get; set; }
    [NotMapped]
    [Display(Name = "Is Active?")]
    public bool IsActive { get; set; }


    [Display(Name = "Product Number")]
    public string ProductNumber { get; set; }

    public string Color { get; set; }

    [Display(Name = "Cost")]
    public decimal? StandardCost { get; set; }

    [Display(Name = "Price")]
    public decimal? ListPrice { get; set; }

    public string Size { get; set; }

    public decimal? Weight { get; set; }

    [Display(Name = "Start Selling Date")]
    public DateTime SellStartDate { get; set; }

    [Display(Name = "End Selling Date")]
    public DateTime? SellEndDate { get; set; }

    [Display(Name = "Date Discontinued")]
    public DateTime? DiscontinuedDate { get; set; }

    public override string ToString()
    {
      return $"{Name} ({ProductID})";
    }
  }
}