﻿using AdvWorks.Common;
using AdvWorks.EntityLayer;
using AdvWorks.ViewModelLayer;
using Microsoft.AspNetCore.Mvc;

namespace AdvWorks.Controllers
{
  public class HomeController : Controller
  {
    private readonly ILogger<HomeController> _logger;
    private readonly IRepository<Product, ProductSearch> _repo;

    public HomeController(ILogger<HomeController> logger, IRepository<Product, ProductSearch> repo)
    {
      _logger = logger;
      _repo = repo;
    }

    [HttpGet]
    public IActionResult ProductList()
    {
      ProductViewModel vm = new(_repo);

      vm.Search();

      return View(vm);
    }

    public IActionResult Index()
    {
      return View();
    }

    public IActionResult Privacy()
    {
      return View();
    }
  }
}