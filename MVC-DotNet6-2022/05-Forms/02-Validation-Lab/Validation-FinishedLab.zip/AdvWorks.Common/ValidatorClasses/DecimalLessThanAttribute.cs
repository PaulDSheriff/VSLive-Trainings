﻿using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace AdvWorks.Common.Validators {
  public class DecimalLessThanAttribute : ValidationAttribute {
    private readonly string _propertyToCompare;

    public DecimalLessThanAttribute(string propToCompare) {
      _propertyToCompare = propToCompare;
    }

    protected override ValidationResult IsValid(object value, ValidationContext validationContext) {
      ErrorMessage = ErrorMessageString;
      if (value != null) {
        decimal currentValue = (decimal)value;
        decimal comparisonValue;
        PropertyInfo pi = validationContext.ObjectType.GetProperty(_propertyToCompare);

        if (pi == null) {
          throw new ArgumentException("Property: " + _propertyToCompare + " was not found.");
        }
        comparisonValue = (decimal)pi.GetValue(validationContext.ObjectInstance);

        if (currentValue > comparisonValue) {
          return new ValidationResult(ErrorMessage);
        }

        return ValidationResult.Success;
      }
      else {
        return new ValidationResult("Property: " + _propertyToCompare + " was null.");
      }
    }
  }
}
