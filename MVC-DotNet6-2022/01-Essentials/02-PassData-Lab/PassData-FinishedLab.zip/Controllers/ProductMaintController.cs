﻿using Microsoft.Extensions.Configuration;
using AdvWorks.Models;
using Microsoft.AspNetCore.Mvc;

namespace AdvWorks.Controllers
{
  public class ProductMaintController : Controller
  {
    public ProductMaintController(AppSettings settings)
    {
      _settings = settings;
    }

    private readonly AppSettings _settings;

    [HttpGet]
    public IActionResult ProductMaintenance()
    {
      ViewBag.Title = "Product Maintenance";

      return View();
    }

    [HttpGet]
    public IActionResult ProductDetail()
    {
      ViewBag.Title = "Product Information";

      ProductViewModel vm = new()
      {
        // Retrieve items from configuration settings file
        DefaultCost = _settings.DefaultCost,
        DefaultPrice = _settings.DefaultPrice,
        DefaultColor = _settings.DefaultColor,
      };

      return View(vm);
    }

    [HttpGet]
    public IActionResult ColorMaintenance()
    {
      ViewBag.Title = "Color Maintenance";

      return View();
    }

    [HttpGet]
    public IActionResult CategoryMaintenance()
    {
      ViewBag.Title = "Category Maintenance";

      return View();
    }
  }
}
