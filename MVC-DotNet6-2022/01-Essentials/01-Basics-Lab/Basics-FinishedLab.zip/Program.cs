//*************************************
// Configure Services
//*************************************
var builder = WebApplication.CreateBuilder(args);

// Add MVC services to the Web Application
builder.Services.AddControllersWithViews();

//*************************************
// Configure Application
// For a list of what services need to be started, in what order, see the following link
// https://docs.microsoft.com/en-us/aspnet/core/fundamentals/middleware/?view=aspnetcore-6.0#middleware-order
//*************************************
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
  app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
