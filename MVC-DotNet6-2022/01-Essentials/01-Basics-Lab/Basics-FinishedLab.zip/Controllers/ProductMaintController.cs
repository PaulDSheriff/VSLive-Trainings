﻿using Microsoft.AspNetCore.Mvc;

namespace AdvWorks.Controllers
{
  public class ProductMaintController : Controller
  {
    [HttpGet]
    public IActionResult ProductMaintenance()
    {
      return View();
    }

    [HttpGet]
    public IActionResult ColorMaintenance()
    {
      return View();
    }

    [HttpGet]
    public IActionResult CategoryMaintenance()
    {
      return View();
    }
  }
}
