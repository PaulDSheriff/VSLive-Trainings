﻿using AdvWorks.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace AdvWorks.Controllers
{
  public class HomeController : Controller
  {
    private readonly ILogger<HomeController> _logger;
    private readonly UserSession _session;

    public HomeController(ILogger<HomeController> logger, UserSession session)
    {
      _logger = logger;
      _session = session;
    }

    [HttpGet]
    public IActionResult Index()
    {
      // Has the user been here before?
      ViewData["Returning"] = (Request.Cookies["Returning"] != null);
      // If the user has not been there, send a cookie out
      if (!Convert.ToBoolean(ViewData["Returning"]))
      {
        CookieOptions options = new()
        {
          Expires = DateTime.Now.AddMinutes(1)
        };
        Response.Cookies.Append("Returning", "true", options);
      }
      else
      {
        _session.LastColor = "Blue";
        _session.LastCost = 10;
        _session.LastPrice = 100;
      }

      return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
      return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
  }
}