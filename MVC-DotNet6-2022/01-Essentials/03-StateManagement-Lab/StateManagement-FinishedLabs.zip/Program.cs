using AdvWorks.Models;

//*************************************
// Configure Services
//*************************************
var builder = WebApplication.CreateBuilder(args);

// Add MVC services to the Web Application
builder.Services.AddControllersWithViews();

// Create an instance of the AppSettings configuration class
builder.Services.AddSingleton<AppSettings>();
// Add a UserSession object
builder.Services.AddScoped<UserSession>();

// The next three lines are for session state
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession();
builder.Services.AddHttpContextAccessor();

//*************************************
// Configure Application
// For a list of what services need to be started, in what order, see the following link
// https://docs.microsoft.com/en-us/aspnet/core/fundamentals/middleware/?view=aspnetcore-6.0#middleware-order
//*************************************
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
  app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();
app.UseSession();

app.UseRouting();

app.UseAuthorization();

// Get the configuration settings class
AppSettings settings = app.Services.GetRequiredService<AppSettings>();
// Read settings from configuration file
settings.DefaultCost =
  app.Configuration.GetValue<decimal>("AdvWorks:DefaultCost");
settings.DefaultPrice =
  app.Configuration.GetValue<decimal>("AdvWorks:DefaultPrice");
settings.DefaultColor =
  app.Configuration.GetValue<string>("AdvWorks:DefaultColor");

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
