﻿using System;
using Microsoft.AspNetCore.Http;

namespace AdvWorks.Models
{
  public class UserSession
  {
    public UserSession(IHttpContextAccessor httpAccessor)
    {
      _httpAccessor = httpAccessor;
    }

    protected readonly IHttpContextAccessor _httpAccessor;

    public string LastColor
    {
      get { return _httpAccessor.HttpContext.Session.GetString("LastColor"); }
      set { _httpAccessor.HttpContext.Session.SetString("LastColor", value); }
    }

    public decimal LastCost
    {
      get { return Convert.ToDecimal(_httpAccessor.HttpContext.Session.GetString("LastCost")); }
      set { _httpAccessor.HttpContext.Session.SetString("LastCost", value.ToString()); }
    }

    public decimal LastPrice
    {
      get { return Convert.ToDecimal(_httpAccessor.HttpContext.Session.GetString("LastPrice")); }
      set { _httpAccessor.HttpContext.Session.SetString("LastPrice", value.ToString()); }
    }
  }
}
