﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdvWorks.Models
{
  public class AppSettings
  {
    public decimal DefaultCost { get; set; }
    public decimal DefaultPrice { get; set; }
    public string DefaultColor { get; set; }
  }
}
