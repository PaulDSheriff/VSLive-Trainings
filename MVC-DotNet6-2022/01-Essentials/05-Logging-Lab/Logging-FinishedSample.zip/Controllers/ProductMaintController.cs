﻿using Microsoft.Extensions.Configuration;
using AdvWorks.Models;
using Microsoft.AspNetCore.Mvc;

namespace AdvWorks.Controllers
{
  public class ProductMaintController : Controller
  {
    public ProductMaintController(AppSettings settings, UserSession session)
    {
      _settings = settings;
      _session = session;
    }

    private readonly AppSettings _settings;
    private readonly UserSession _session;

    [HttpGet]
    public IActionResult ProductMaintenance()
    {
      ViewBag.Title = "Product Maintenance";

      return View();
    }

    [HttpGet]
    public IActionResult ProductDetail()
    {
      ViewBag.Title = "Product Information";
      ProductViewModel vm = new();

      if (string.IsNullOrEmpty(_session.LastColor))
      {
        // Retrieve items from configuration settings file
        vm.DefaultCost = _settings.DefaultCost;
        vm.DefaultPrice = _settings.DefaultPrice;
        vm.DefaultColor = _settings.DefaultColor;
      }
      else
      {
        // Retrieve items from session
        vm.DefaultCost = _session.LastCost;
        vm.DefaultPrice = _session.LastPrice;
        vm.DefaultColor = _session.LastColor;
      }

      return View(vm);
    }

    [HttpGet]
    public IActionResult ColorMaintenance()
    {
      ViewBag.Title = "Color Maintenance";

      return View();
    }

    [HttpGet]
    public IActionResult CategoryMaintenance()
    {
      ViewBag.Title = "Category Maintenance";

      return View();
    }
  }
}
