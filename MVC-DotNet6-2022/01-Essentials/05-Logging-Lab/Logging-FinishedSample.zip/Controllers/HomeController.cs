﻿using AdvWorks.Models;
using Microsoft.AspNetCore.Mvc;

namespace AdvWorks.Controllers
{
  public class HomeController : Controller
  {
    private readonly ILogger<HomeController> _logger;
    private readonly UserSession _session;

    public HomeController(ILogger<HomeController> logger, UserSession session)
    {
      _logger = logger;
      _session = session;
    }

    [HttpGet]
    public IActionResult Index()
    {
      //throw new ApplicationException("This is an error");

      _logger.LogInformation("Entering the home page");

      // Has the user been here before?
      ViewData["Returning"] = (Request.Cookies["Returning"] != null);
      // If the user has not been there, send a cookie out
      if (!Convert.ToBoolean(ViewData["Returning"]))
      {
        _logger.LogInformation("First time entering home page");

        CookieOptions options = new()
        {
          Expires = DateTime.Now.AddMinutes(1)
        };
        Response.Cookies.Append("Returning", "true", options);
      }
      else
      {
        _logger.LogInformation("Have been to the home page before");
        _session.LastColor = "Blue";
        _session.LastCost = 10;
        _session.LastPrice = 100;
      }

      return View();
    }
  }
}