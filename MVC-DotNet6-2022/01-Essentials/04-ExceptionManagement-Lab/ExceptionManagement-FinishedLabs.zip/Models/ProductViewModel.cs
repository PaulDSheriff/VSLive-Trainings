﻿namespace AdvWorks.Models
{
  public class ProductViewModel
  {
    public decimal DefaultCost { get; set; }
    public decimal DefaultPrice { get; set; }
    public string DefaultColor { get; set; }
  }
}
