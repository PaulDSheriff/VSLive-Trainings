﻿#nullable disable

using Microsoft.EntityFrameworkCore;
using Samples;

public class Lab01 {
  public static void GetAll() {
    List<Song> list;

    using (MusicDbContext db = new()) {
      // Get All Songs
      var query = (from row in db.Songs
                   select row);

      //var query = db.Songs;

      list = query.ToList();

      // Display Songs
      foreach (Song row in list) {
        Console.WriteLine(row);
      }

      // Display Total Count
      Console.WriteLine();
      Console.WriteLine($"Total Songs: {list.Count}");

      // TODO: Show SQL Generated
      Console.WriteLine();
      Console.WriteLine(
        EntityFrameworkQueryableExtensions.ToQueryString(query));
    }

    // Pause for Results
    Console.ReadKey();
  }
}