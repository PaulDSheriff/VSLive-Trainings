﻿#nullable disable

using Microsoft.EntityFrameworkCore;
using Samples;

public class Lab03 {
  public static void OrderBy() {
    List<Song> list;

    using (MusicDbContext db = new()) {
      // Order by SongName in Descending Order
      var query = (from row in db.Songs
                   where row.GenreId == 30
                   orderby row.SongName descending
                   select row);

      // Method Syntax
      //var query = db.Songs
      //  .Where(row => row.GenreId == 30)
      //  .OrderByDescending(row => row.SongName);

      list = query.ToList();

      // Display Songs
      foreach (Song row in list) {
        Console.WriteLine(row);
      }

      // Display Total Count
      Console.WriteLine();
      Console.WriteLine($"Total Songs: {list.Count}");

      // TODO: Show SQL Generated
      Console.WriteLine();
      Console.WriteLine(
        EntityFrameworkQueryableExtensions.ToQueryString(query));
    }

    // Pause for Results
    Console.ReadKey();
  }
}