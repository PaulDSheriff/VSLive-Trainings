﻿#nullable disable

using Samples;

public class Lab04 {
  public static void Sum() {
    using (MusicDbContext db = new()) {
      // Average all Ratings
      double? avg = (from row in db.Songs
                     where row.GenreId == 30
                     select row)
                      .Average(row => row.Rating);

      //double? avg = db.Songs
      //    .Where(row => row.GenreId == 30)
      //    .Average(row => row.Rating);

      // Display Average Ratings
      Console.WriteLine();
      Console.WriteLine($"Average Song Rating: {avg:n0}");
    }

    // Pause for Results
    Console.ReadKey();
  }
}