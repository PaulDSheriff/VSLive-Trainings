﻿// Try out the Labs
//Lab01.GetAll();
//Lab02.WhereClause();
//Lab03.OrderBy();
Lab04.Sum();