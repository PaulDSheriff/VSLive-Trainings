﻿#nullable disable

using Microsoft.EntityFrameworkCore;
using System.Diagnostics;

namespace Samples;

public partial class MusicDbContext : DbContext {
  const string CONN_STRING = "Server=Localhost;Database=MusicLab;Integrated Security=True";

  public virtual DbSet<Song> Songs { get; set; }

  protected override void OnConfiguring(DbContextOptionsBuilder builder) {
    base.OnConfiguring(builder);
    builder.UseSqlServer(CONN_STRING);

    // The following line provides much more information
    // than just using the ToQueryString() method
    builder.LogTo(Console.WriteLine);
    //builder.LogTo(msg => Debug.WriteLine(msg));
  }
}
