﻿#nullable disable

using Microsoft.EntityFrameworkCore;
using Samples;

public class Lab02 {
  public static void WhereClause() {
    List<Song> list;

    using (MusicDbContext db = new()) {
      // Get All Songs Where GenreId = 30
      var query = (from row in db.Songs
                   where row.GenreId == 30
                   select row);

      // Method Syntax
      //var query = db.Songs
      //    .Where(row => row.GenreId == 30);

      list = query.ToList();

      // Display Songs
      foreach (Song row in list) {
        Console.WriteLine(row);
      }

      // Display Total Count
      Console.WriteLine();
      Console.WriteLine($"Total Songs: {list.Count}");

      // TODO: Show SQL Generated
      Console.WriteLine();
      Console.WriteLine(
        EntityFrameworkQueryableExtensions.ToQueryString(query));
    }

    // Pause for Results
    Console.ReadKey();
  }
}