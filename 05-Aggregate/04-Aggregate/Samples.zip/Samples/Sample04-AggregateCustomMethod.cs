﻿#nullable disable

namespace LINQSamples;

public class Sample04 {
  /// <summary>
  /// Use Sales Orders and calculate the total Sales by multiplying OrderQty * UnitPrice for each order
  /// </summary>
  public static void AggregateCustomMethod() {
    List<SalesOrder> sales = SalesOrderRepository.GetAll();
    decimal value;

    // Write Method Syntax Here
    value = sales.Aggregate(0M, (sum, row) => 
                            sum += (row.OrderQty * row.UnitPrice));

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
