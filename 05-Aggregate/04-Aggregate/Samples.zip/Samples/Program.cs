﻿using LINQSamples;

// Call Sample Method
Sample01.AggregateQuery();
//Sample02.AggregateMethod();
//Sample03.AggregateCustomQuery();
//Sample04.AggregateCustomMethod();
//Sample05.AggregateStrings();
//Sample06.AggregateDistinctStrings();