﻿#nullable disable

namespace LINQSamples;

public class Sample06 {
  /// <summary>
  /// Produce a comma-delimited list of distinct sizes
  /// </summary>
  public static void AggregateDistinctStrings() {
    List<Product> products = ProductRepository.GetAll();
    string value;

    // Get all distinct sizes, then aggregate sizes together
    value = products.Where(row => !string.IsNullOrEmpty(row.Size))
      .Select(row => row.Size)
      .Distinct().OrderBy(row => row)
      .Aggregate("", (sizes, row) => sizes + row + ",");

    // Display the Result, eliminating the last comma
    Console.WriteLine(value[..^1]);

    // Pause for Results
    Console.ReadKey();
  }
}
