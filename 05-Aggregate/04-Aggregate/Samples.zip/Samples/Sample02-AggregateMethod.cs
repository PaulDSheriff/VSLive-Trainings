﻿#nullable disable

namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// The Aggregate() method iterates over a collection and performs an accumulation of values. With this operator you can simulate count, sum, etc.
  /// </summary>
  public static void AggregateMethod() {
    List<Product> products = ProductRepository.GetAll();
    decimal value;

    // Write Method Syntax Here
    value = products.Aggregate(0M, (sum, row) => sum += row.ListPrice);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
