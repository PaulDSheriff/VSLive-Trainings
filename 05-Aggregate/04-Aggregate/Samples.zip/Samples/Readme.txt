﻿Description of Samples
--------------------------------------------------
01-AggregateQuery() - The Aggregate() method iterates over a collection and performs an accumulation of values. With this operator you can simulate count, sum, etc.
02-AggregateMethod() - The Aggregate() method iterates over a collection and performs an accumulation of values. With this operator you can simulate count, sum, etc.

03-AggregateCustomQuery() - Use Sales Orders and calculate the total Sales by multiplying OrderQty * UnitPrice for each order
04-AggregateCustomMethod() - Use Sales Orders and calculate the total Sales by multiplying OrderQty * UnitPrice for each order

05-AggregateStrings() - Produce a comma-delimited list of product names
06-AggregateDistinctStrings() - Produce a comma-delimited list of distinct sizes