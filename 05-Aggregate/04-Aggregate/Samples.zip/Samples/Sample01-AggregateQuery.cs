﻿#nullable disable

namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// The Aggregate() method iterates over a collection and performs an accumulation of values. With this operator you can simulate count, sum, etc.
  /// </summary>
  public static void AggregateQuery() {
    List<Product> products = ProductRepository.GetAll();
    decimal value;

    // Write Query Syntax Here
    value = (from row in products
             select row)
             .Aggregate(0M, (sum, row) =>
                        sum += row.ListPrice);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
