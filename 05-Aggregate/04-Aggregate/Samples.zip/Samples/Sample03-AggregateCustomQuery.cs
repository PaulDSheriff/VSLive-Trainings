﻿#nullable disable

namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// Use Sales Orders and calculate the total Sales by multiplying OrderQty * UnitPrice for each order
  /// </summary>
  public static void AggregateCustomQuery() {
    List<SalesOrder> sales = SalesOrderRepository.GetAll();
    decimal value;

    // Write Query Syntax Here
    value = (from row in sales
             select row)
             .Aggregate(0M, (sum, row) =>
                        sum += (row.OrderQty * row.UnitPrice));

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
