﻿#nullable disable

namespace LINQSamples;

public class Sample05 {
  /// <summary>
  /// Produce a comma-delimited list of product names
  /// </summary>
  public static void AggregateStrings() {
    List<Product> products = ProductRepository.GetAll();
    string value;

    // Get all product names
    value = products.OrderBy(row => row.Name)
      .Aggregate("", (names, row) => names + row.Name + ",");

    // Display the Result, eliminating the last comma
    Console.WriteLine(value[..^1]);

    // Pause for Results
    Console.ReadKey();
  }
}
