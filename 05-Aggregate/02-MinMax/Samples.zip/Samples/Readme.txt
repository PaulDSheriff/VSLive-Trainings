﻿Description of Samples
--------------------------------------------------
01-MinQuery() - Get the minimum value from a numeric column in a collection
02-MinMethod() - Get the minimum value from a numeric column in a collection

03-MaxQuery() - Get the maximum value from a numeric column in a collection
04-MaxMethod() - Get the maximum value from a numeric column in a collection