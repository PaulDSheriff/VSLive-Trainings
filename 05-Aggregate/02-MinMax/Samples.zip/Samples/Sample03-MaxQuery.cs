﻿#nullable disable

namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// Get the maximum value of a single property in a collection
  /// </summary>
  public static void MaxQuery() {
    List<Product> products = ProductRepository.GetAll();
    decimal value;

    // Write Query Syntax #1 Here
    value = (from row in products
             select row.ListPrice).Max();

    // Write Query Syntax #2 Here
    value = (from row in products
             select row).Max(row => row.ListPrice);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
