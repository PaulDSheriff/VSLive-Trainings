﻿#nullable disable

namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// Get the minimum value of a single property in a collection
  /// </summary>
  public static void MinMethod() {
    List<Product> products = ProductRepository.GetAll();
    decimal value;

    // Write Method Syntax #1 Here
    value = products.Select(row => row.ListPrice).Min();

    // Write Method Syntax #2 Here
    value = products.Min(row => row.ListPrice);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
