﻿#nullable disable

namespace LINQSamples;

public class Sample04 {
  /// <summary>
  /// Get the maximum value of a single property in a collection
  /// </summary>
  public static void MaxMethod() {
    List<Product> products = ProductRepository.GetAll();
    decimal value;

    // Write Method Syntax #1 Here
    value = products.Select(row => row.ListPrice).Max();

    // Write Method Syntax #2 Here
    value = products.Max(row => row.ListPrice);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
