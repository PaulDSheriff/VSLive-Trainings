﻿using LINQSamples;

// Call Sample Method
Sample01.MinQuery();
//Sample02.MinMethod();
//Sample03.MaxQuery();
//Sample04.MaxMethod();