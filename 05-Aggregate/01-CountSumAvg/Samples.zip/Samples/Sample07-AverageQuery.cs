﻿#nullable disable

namespace LINQSamples;

public class Sample07 {
  /// <summary>
  /// Get the average of all values within a single property in a collection
  /// </summary>
  public static void AverageQuery() {
    List<Product> products = ProductRepository.GetAll();
    decimal value;

    // Write Query Syntax #1 Here
    value = (from row in products 
             select row.ListPrice).Average();

    // Display the Result
    Console.WriteLine(value);

    // Write Query Syntax #2 Here
    value = (from row in products 
             select row).Average(row => row.ListPrice);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
