﻿#nullable disable

namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// Gets the total number of products in a collection
  /// </summary>
  public static void CountMethod() {
    List<Product> products = ProductRepository.GetAll();
    int value;

    // Write Method Syntax Here
    value = products.Count;  // More Efficient
    //value = products.Count();

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
