﻿#nullable disable

namespace LINQSamples;

public class Sample06 {
  /// <summary>
  /// Gets the sum of the values of a single property in a collection
  /// </summary>
  public static void SumMethod() {
    List<Product> products = ProductRepository.GetAll();
    decimal value;

    // Write Method Syntax #1 Here
    value = products.Select(row => row.ListPrice).Sum();

    // Display the Result
    Console.WriteLine(value);

    // Write Method Syntax #1 Here
    value = products.Sum(row => row.ListPrice);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
