﻿Description of Samples
--------------------------------------------------
01-CountQuery() - Count all rows in collection
02-CountMethod() - Count all rows in collection

03-CountFilteredQuery() - Can either add a Where clause or a predicate in the Count() method
04-CountFilteredMethod() - Can either add a Where clause or a predicate in the Count() method

05-SumQuery() - Get a sum of a numeric column in a collection
06-SumMethod() - Get a sum of a numeric column in a collection

07-AverageQuery() - Get the average value from a numeric column in a collection
08-AverageMethod\() - Get the average value from a numeric column in a collection