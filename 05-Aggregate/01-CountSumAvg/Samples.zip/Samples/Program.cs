﻿using LINQSamples;

// Call Sample Method
Sample01.CountQuery();
//Sample02.CountMethod();
//Sample03.CountFilteredQuery();
//Sample04.CountFilteredMethod();
//Sample05.SumQuery();
//Sample06.SumMethod();
//Sample07.AverageQuery();
//Sample08.AverageMethod();