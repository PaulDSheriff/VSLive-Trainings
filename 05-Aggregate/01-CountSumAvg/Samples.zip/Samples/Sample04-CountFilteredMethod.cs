﻿#nullable disable

namespace LINQSamples;

public class Sample04 {
  /// <summary>
  /// Can either add a Where clause or a predicate in the Count() method
  /// </summary>
  public static void CountFilteredMethod() {
    List<Product> products = ProductRepository.GetAll();
    int value;

    // Write Method Syntax #1 Here
    value = products.Count(row => row.Color == "Red");

    // Display the Result
    Console.WriteLine(value);

    // Write Method Syntax #2 Here
    value = products.Where(row => row.Color == "Red").Count();

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
