﻿#nullable disable

namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// Can either add a Where clause or a predicate in the Count() method
  /// </summary>
  public static void CountFilteredQuery() {
    List<Product> products = ProductRepository.GetAll();
    int value;

    // Write Query Syntax #1 Here
    value = (from row in products
             select row)
             .Count(row => row.Color == "Red");

    // Display the Result
    Console.WriteLine(value);

    // Write Query Syntax #2 Here
    value = (from row in products
             where row.Color == "Red"
             select row)
             .Count();

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
