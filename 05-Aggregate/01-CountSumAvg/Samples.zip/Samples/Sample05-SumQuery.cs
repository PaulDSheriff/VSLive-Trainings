﻿#nullable disable

namespace LINQSamples;

public class Sample05 {
  /// <summary>
  /// Gets the sum of the values of a single property in a collection
  /// </summary>
  public static void SumQuery() {
    List<Product> products = ProductRepository.GetAll();
    decimal value;

    // Write Query Syntax #1 Here
    value = (from row in products 
             select row.ListPrice).Sum();

    // Display the Result
    Console.WriteLine(value);

    // Write Query Syntax #2 Here
    value = (from row in products 
             select row).Sum(row => row.ListPrice);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
