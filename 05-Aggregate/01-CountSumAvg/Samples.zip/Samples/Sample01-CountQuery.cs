﻿#nullable disable

namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// Gets the total number of products in a collection
  /// </summary>
  public static void CountQuery() {
    List<Product> products = ProductRepository.GetAll();
    int value;

    // Write Query Syntax Here
    value = (from row in products
             select row).Count();

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
