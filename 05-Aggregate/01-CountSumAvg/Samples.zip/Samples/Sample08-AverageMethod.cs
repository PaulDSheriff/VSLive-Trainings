﻿#nullable disable

namespace LINQSamples;

public class Sample08 {
  /// <summary>
  /// Get the average of all values within a single property in a collection
  /// </summary>
  public static void AverageMethod() {
    List<Product> products = ProductRepository.GetAll();
    decimal value;

    // Write Method Syntax #1 Here
    value = products.Select(row => row.ListPrice).Average();

    // Display the Result
    Console.WriteLine(value);

    // Write Method Syntax #2 Here
    value = products.Average(row => row.ListPrice);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
