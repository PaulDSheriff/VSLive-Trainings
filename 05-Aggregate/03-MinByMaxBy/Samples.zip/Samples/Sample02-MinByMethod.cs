﻿#nullable disable

namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// Get the minimum value of a single property in a collection, but return the object
  /// </summary>
  public static void MinByMethod() {
    List<Product> products = ProductRepository.GetAll();
    Product value;

    // Write Method Syntax Here
    value = products.MinBy(row => row.ListPrice);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
