﻿#nullable disable

namespace LINQSamples;

public class Sample04 {
  /// <summary>
  /// Get the maximum value of a single property in a collection, but return the object
  /// </summary>
  public static void MaxByMethod() {
    List<Product> products = ProductRepository.GetAll();
    Product value;

    // Write Method Syntax Here
    value = products.MaxBy(row => row.ListPrice);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
