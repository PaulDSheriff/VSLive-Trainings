﻿#nullable disable

namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// Get the minimum value of a single property in a collection, but return the object
  /// </summary>
  public static void MinByQuery() {
    List<Product> products = ProductRepository.GetAll();
    Product value;

    // Write Query Syntax Here
    value = (from row in products
             select row).MinBy(row => row.ListPrice);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
