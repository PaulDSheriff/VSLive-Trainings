﻿using LINQSamples;

// Call Sample Method
Sample01.MinByQuery();
//Sample02.MinByMethod();
//Sample03.MaxByQuery();
//Sample04.MaxByMethod();