﻿Description of Samples
--------------------------------------------------
01-MinByQuery() - Get the minimum value from a numeric column in a collection, return object
02-MinByMethod() - Get the minimum value from a numeric column in a collection, return object

03-MaxByQuery() - Get the maximum value from a numeric column in a collection, return object
04-MaxByMethod() - Get the maximum value from a numeric column in a collection, return object
