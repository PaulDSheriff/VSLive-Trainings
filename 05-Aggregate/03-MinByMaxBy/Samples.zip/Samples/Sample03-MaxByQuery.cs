﻿#nullable disable

namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// Get the maximum value of a single property in a collection, but return the object
  /// </summary>
  public static void MaxByQuery() {
    List<Product> products = ProductRepository.GetAll();
    Product value;

    // Write Query Syntax Here
    value = (from row in products 
             select row).MaxBy(row => row.ListPrice);

    // Display the Result
    Console.WriteLine(value);

    // Pause for Results
    Console.ReadKey();
  }
}
