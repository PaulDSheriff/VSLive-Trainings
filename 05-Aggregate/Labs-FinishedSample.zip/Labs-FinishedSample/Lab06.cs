﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab06() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    string value;

    // Query Syntax
    value = (from row in songs
             orderby row.DateAdded
             select row)
             .Take(5)
             .Aggregate("", (names, row) => 
                names + row.SongName + Environment.NewLine);

    // Method Syntax
    //value = songs
    //        .OrderBy(row => row.DateAdded)
    //        .Take(5)
    //        .Aggregate("", (names, row) => 
    //                   names + row.SongName + Environment.NewLine);

    // Display Result
    Console.WriteLine();
    Console.WriteLine($"Result: {value}");

    // Pause for Results
    Console.ReadKey();
  }
}
