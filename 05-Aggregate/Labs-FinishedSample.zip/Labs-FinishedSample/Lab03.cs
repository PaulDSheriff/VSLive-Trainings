﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab03() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    double? value;

    // Query Syntax
    value = (from row in songs
             where row.GenreId == 35
             select row)
             .Average(row => row.Plays);

    // Method Syntax
    //value = songs
    //        .Where(row => row.GenreId == 35)
    //        .Average(row => row.Plays);

    // Display Result
    Console.WriteLine();
    Console.WriteLine($"Result: {value}");

    // Pause for Results
    Console.ReadKey();
  }
}
