﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab01() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    int value;

    // Query Syntax
    value = (from row in songs select row)
            .Count(row => row.GenreId == 35);

    // Method Syntax
    //value = songs
    //        .Count(row => row.GenreId == 35);

    // Display Result
    Console.WriteLine();
    Console.WriteLine($"Result: {value}");

    // Pause for Results
    Console.ReadKey();
  }
}
