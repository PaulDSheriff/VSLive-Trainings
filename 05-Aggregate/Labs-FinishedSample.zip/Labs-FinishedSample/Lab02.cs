﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab02() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    int? value;

    // Query Syntax
    value = (from row in songs
             where row.GenreId == 35
             select row)
             .Sum(row => row.Plays);

    // Method Syntax
    //value = songs
    //        .Where(row => row.GenreId == 35)
    //        .Sum(row => row.Plays);

    // Display Result
    Console.WriteLine();
    Console.WriteLine($"Result: {value}");

    // Pause for Results
    Console.ReadKey();
  }
}
