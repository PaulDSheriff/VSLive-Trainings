﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab05() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    Song? value;

    // Query Syntax
    value = (from row in songs
             select row)
             .MinBy(row => row.Rating);

    // Method Syntax
    //value = songs
    //        .MinBy(row => row.Rating);

    // Display Result
    Console.WriteLine();
    Console.WriteLine($"Result: {value}");

    // Pause for Results
    Console.ReadKey();
  }
}
