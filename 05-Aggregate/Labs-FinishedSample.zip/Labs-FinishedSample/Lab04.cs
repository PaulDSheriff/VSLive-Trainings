﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab04() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    int? value;

    // Query Syntax
    value = (from row in songs
             select row)
             .Min(row => row.Rating);

    // Method Syntax
    //value = songs
    //        .Min(row => row.Rating);

    // Display Result
    Console.WriteLine();
    Console.WriteLine($"Result: {value}");

    // Pause for Results
    Console.ReadKey();
  }
}
