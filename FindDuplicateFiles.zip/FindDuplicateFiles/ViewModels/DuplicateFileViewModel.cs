﻿#nullable disable

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Common.Library;

namespace FindDuplicateFiles.ViewModels;

public class DuplicateFileViewModel : ViewModelBase
{
  #region Properties
  private List<FileInfo> _AllFiles = new List<FileInfo>();
  private List<FileDetail> _DuplicateFiles = new List<FileDetail>();
  private string _TopFolderName = @"D:\";
  private string _FileExtensions = "*.*";
  private bool _IsEnabled = true;
  private bool _DisplayGrid = false;
  private bool _DisplayMessage = false;

  /// <summary>
  /// Get/Set Files
  /// </summary>
  public List<FileInfo> AllFiles
  {
    get { return _AllFiles; }
    set {
      _AllFiles = value;
      RaisePropertyChanged("AllFiles");
    }
  }

  /// <summary>
  /// Get/Set DuplicateFiles
  /// </summary>
  public List<FileDetail> DuplicateFiles
  {
    get { return _DuplicateFiles; }
    set {
      _DuplicateFiles = value;
      RaisePropertyChanged("DuplicateFiles");
    }
  }

  /// <summary>
  /// Get/Set TopFolderName
  /// </summary>
  public string TopFolderName
  {
    get { return _TopFolderName; }
    set {
      _TopFolderName = value;
      RaisePropertyChanged("TopFolderName");
    }
  }

  /// <summary>
  /// Get/Set FileExtensions
  /// </summary>
  public string FileExtensions
  {
    get { return _FileExtensions; }
    set {
      _FileExtensions = value;
      RaisePropertyChanged("FileExtensions");
    }
  }

  /// <summary>
  /// Get/Set IsEnabled
  /// </summary>
  public bool IsEnabled
  {
    get { return _IsEnabled; }
    set {
      _IsEnabled = value;
      RaisePropertyChanged("IsEnabled");
    }
  }

  /// <summary>
  /// Get/Set DisplayGrid
  /// </summary>
  public bool DisplayGrid
  {
    get { return _DisplayGrid; }
    set {
      _DisplayGrid = value;
      RaisePropertyChanged("DisplayGrid");
    }
  }

  /// <summary>
  /// Get/Set DisplayMessage
  /// </summary>
  public bool DisplayMessage
  {
    get { return _DisplayMessage; }
    set {
      _DisplayMessage = value;
      RaisePropertyChanged("DisplayMessage");
    }
  }
  #endregion

  #region LoadAllFiles Method
  public void LoadAllFiles()
  {
    string[] ext;

    // Initialize the AllFiles collection
    AllFiles = new List<FileInfo>();

    // Get Directory Info
    DirectoryInfo di = new DirectoryInfo(TopFolderName);
    
    // Split out all file extensions to locate
    ext = FileExtensions.Split(",".ToCharArray());

    // Get all files by extension in all directories
    for (int i = 0; i < ext.Length; i++) {
      if (!string.IsNullOrEmpty(ext[i])) {
        try {
          AllFiles.AddRange(di.GetFiles(ext[i], SearchOption.AllDirectories).ToList());
        }
        catch {
          // Ignore Exception
        }
      }
    }

    RaisePropertyChanged("AllFiles");
  }
  #endregion

  #region FindDuplicateFiles Method
  public void FindDuplicateFiles()
  {
    List<FileDetail> list;

    // Set visibility properties
    IsEnabled = false;
    DisplayMessage = true;

    // Load files if none loaded already
    if (AllFiles.Count == 0) {
      LoadAllFiles();
    }

    // Create a Hash from file contents
    // Any duplicate files should have the same hash
    // This hash value is used to group duplicate files together
    list = AllFiles.Select(f => new FileDetail
    {
      Name = f.Name,
      DirectoryName = f.DirectoryName,
      FullName = f.FullName,
      Length = f.Length,
      Hash = CreateHash(f)
    }).ToList();

    // Find duplicate files by grouping on the Hash value
    var grouped = list.GroupBy(file => file.Hash)
                      .Where(files => files.Count() > 1)
                      .Select(grp => grp);

    // Use SelectMany() to flatten the files in the grouped list
    DuplicateFiles = grouped.SelectMany(files => files).ToList();

    // Reset visibility properties
    IsEnabled = true;
    DisplayMessage = false;
    DisplayGrid = true;
  }
  #endregion

  #region CreateHash Method  
  private string CreateHash(FileInfo fi)
  {
    string ret;

    try {
      // Open the file for reading
      using (var fs = new FileStream(fi.FullName, FileMode.Open, FileAccess.Read)) {
        // Use the entire contents of the file for the Hash
        ret = BitConverter.ToString(SHA1.Create().ComputeHash(fs));
      }
    }
    catch {
      // Ignore exception and create a default hash
      ret = fi.Name + fi.Length.ToString();
    }

    return ret;
  }
  #endregion
}
