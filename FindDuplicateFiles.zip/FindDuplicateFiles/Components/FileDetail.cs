﻿#nullable disable

using System;

namespace Common.Library;

public class FileDetail : ViewModelBase
{
  public string Name { get; set; }
  public string DirectoryName { get; set; }
  public string FullName { get; set; }
  public string Hash { get; set; }
  public long Length { get; set; }
  public DateTime CreationTime { get; set; }
}
