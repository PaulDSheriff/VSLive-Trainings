﻿#nullable disable

using FindDuplicateFiles.ViewModels;
using System;
using System.Windows;
using System.Windows.Threading;

namespace FindDuplicateFiles { 
  public partial class MainWindow : Window {
    public MainWindow() {
      InitializeComponent();

      // Connect to instance of the view model created by the XAML
      _viewModel = (DuplicateFileViewModel)this.Resources["viewModel"];
    }

    // View model class
    private readonly DuplicateFileViewModel _viewModel = null;

    private async void LoadFiles_Click(object sender, RoutedEventArgs e) {
      await Dispatcher.BeginInvoke(new Action(() =>
      {
        _viewModel.LoadAllFiles();
      }), DispatcherPriority.Background);
    }

    private async void FindFiles_Click(object sender, RoutedEventArgs e) {
      _viewModel.IsEnabled = false;
      _viewModel.DisplayMessage = true;

      await Dispatcher.BeginInvoke(new Action(() =>
      {
        _viewModel.FindDuplicateFiles();
      }), DispatcherPriority.Background);
    }

    private void TopLevelSelect_Click(object sender, RoutedEventArgs e) {
      //using (var dialog = new System.Windows.Forms.FolderBrowserDialog()) {
      //  dialog.SelectedPath = _viewModel.TopFolderName;
      //  System.Windows.Forms.DialogResult result = dialog.ShowDialog();
      //  if (result == System.Windows.Forms.DialogResult.OK) {
      //    _viewModel.TopFolderName = dialog.SelectedPath;
      //  }
      //}
    }
  }
}
