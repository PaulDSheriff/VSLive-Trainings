﻿namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// The Union() method when using a Comparer class combines two lists together, but skips duplicates. This is like the UNION SQL operator.
  /// </summary>
  public static void UnionQuery() {
    List<Product> list1 = ProductRepository.GetAll();
    List<Product> list2 = ProductRepository.GetAll();
    ProductComparer pc = new();
    List<Product> list;

    // Write Query Syntax Here
    list = (from row in list1
            select row)
            .Union(list2, pc)
            .OrderBy(row => row.Name).ToList();

    // Display Products
    foreach (Product product in list) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
