﻿namespace LINQSamples;

public class Sample04 {
  /// <summary>
  /// The Union() method when using a Comparer class combines two lists together, but skips duplicates. This is like the UNION SQL operator.
  /// </summary>
  public static void UnionMethod() {
    List<Product> list1 = ProductRepository.GetAll();
    List<Product> list2 = ProductRepository.GetAll();
    ProductComparer pc = new();
    List<Product> list;

    // Write Method Syntax Here
    list = list1.Union(list2, pc)
                .OrderBy(row => row.Name).ToList();

    // Display Products
    foreach (Product product in list) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
