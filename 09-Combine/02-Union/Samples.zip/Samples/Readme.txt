﻿Description of Samples
--------------------------------------------------
01-UnionIntegersQuery() - The Union() method combines two lists together, but skips duplicates. This is like the UNION SQL operator
02-UnionIntegersMethod() - The Union() method combines two lists together, but skips duplicates. This is like the UNION SQL operator

03-UnionQuery() - The Union() method when using a Comparer class combines two lists together, but skips duplicates. This is like the UNION SQL operator.
04-UnionMethod() - The Union() method when using a Comparer class combines two lists together, but skips duplicates. This is like the UNION SQL operator.

05-UnionByQuery() - The UnionBy() method combines two lists together using DISTINCT on the property specified. This avoids the need for a Comparer class.
06-UnionByMethod() - The UnionBy() method combines two lists together using DISTINCT on the property specified. This avoids the need for a Comparer class.