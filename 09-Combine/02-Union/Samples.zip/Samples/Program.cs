﻿using LINQSamples;

// Call Sample Method
Sample01.UnionIntegersQuery();
//Sample02.UnionIntegersMethod();
//Sample03.UnionQuery();
//Sample04.UnionMethod();
//Sample05.UnionByQuery();
//Sample06.UnionByMethod();