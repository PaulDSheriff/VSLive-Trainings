﻿namespace LINQSamples;

public class Sample06 {
  /// <summary>
  /// The UnionBy() method combines two lists together using DISTINCT on the property specified. This avoids the need for a Comparer class.
  /// </summary>
  public static void UnionByMethod() {
    List<Product> list1 = ProductRepository.GetAll();
    List<Product> list2 = ProductRepository.GetAll();
    List<Product> list;

    // Write Method Syntax Here
    list = list1.UnionBy(list2, row => row.Color)
                .OrderBy(row => row.Name).ToList();

    // Display Products
    foreach (Product product in list) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
