﻿namespace LINQSamples;

public class Sample05 {
  /// <summary>
  /// The UnionBy() method combines two lists together using DISTINCT on the property specified. This avoids the need for a Comparer class.
  /// </summary>
  public static void UnionByQuery() {
    List<Product> list1 = ProductRepository.GetAll();
    List<Product> list2 = ProductRepository.GetAll();
    List<Product> list;

    // Write Query Syntax Here
    list = (from row in list1
            select row)
            .UnionBy(list2, row => row.Color)
            .OrderBy(row => row.Name).ToList();

    // Display Products
    foreach (Product product in list) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
