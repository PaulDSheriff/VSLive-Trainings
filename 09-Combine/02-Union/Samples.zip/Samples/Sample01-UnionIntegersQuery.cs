﻿namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// The Union() method combines two lists together, but skips duplicates. This is like the UNION SQL operator
  /// </summary>
  public static void UnionIntegersQuery() {
    List<int> list1 = new() { 5, 2, 3, 4, 5 };
    List<int> list2 = new() { 1, 2, 3, 4, 5 };
    List<int> list;

    // Write Query Syntax Here
    list = (from row in list1
            select row)
            .Union(list2)
            .OrderBy(row => row).ToList();

    // Display integers
    foreach (int item in list) {
      Console.WriteLine(item);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
