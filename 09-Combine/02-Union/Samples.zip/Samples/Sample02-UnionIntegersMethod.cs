﻿namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// The Union() method combines two lists together, but skips duplicates. This is like the UNION SQL operator
  /// </summary>
  public static void UnionIntegersMethod() {
    List<int> list1 = new() { 5, 2, 3, 4, 5 };
    List<int> list2 = new() { 1, 2, 3, 4, 5 };
    List<int> list;

    // Write Query Syntax Here
    list = list1.Union(list2)
            .OrderBy(row => row).ToList();

    // Display integers
    foreach (int item in list) {
      Console.WriteLine(item);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
