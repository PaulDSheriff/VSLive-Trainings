﻿namespace LINQSamples;

public class Sample08 {
  /// <summary>
  /// Perform a left join between Products and Sales using DefaultIfEmpty() and SelectMany()
  /// </summary>
  public static void LeftOuterJoinMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<SalesOrder> sales = SalesOrderRepository.GetAll();
    List<ProductOrder> list;

    // Write Method Syntax Here
    list = products.SelectMany(
            prod =>
            sales.Where(row => row.ProductID == prod.ProductID).DefaultIfEmpty(),
            (prod, sale) => new ProductOrder {
              ProductID = prod.ProductID,
              Name = prod.Name,
              Color = prod.Color,
              StandardCost = prod.StandardCost,
              ListPrice = prod.ListPrice,
              Size = prod.Size,
              SalesOrderID = sale?.SalesOrderID,  // Use the null-conditional operator
              OrderQty = sale?.OrderQty,
              UnitPrice = sale?.UnitPrice,
              LineTotal = sale?.LineTotal
            }).OrderBy(row => row.Name).ToList();

    // Display Product Orders
    foreach (ProductOrder product in list) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Result
    Console.ReadKey();
  }
}
