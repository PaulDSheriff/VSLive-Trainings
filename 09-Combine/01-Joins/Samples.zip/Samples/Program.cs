﻿using LINQSamples;

// Call Sample Method
Sample01.InnerJoinQuery();
//Sample02.InnerJoinMethod();
//Sample03.InnerJoinTwoFieldsQuery();
//Sample04.InnerJoinTwoFieldsMethod();
//Sample05.JoinIntoQuery();
//Sample06.JoinIntoMethod();
//Sample07.LeftOuterJoinQuery();
//Sample08.LeftOuterJoinMethod();