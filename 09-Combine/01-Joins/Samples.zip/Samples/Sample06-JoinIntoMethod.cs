﻿namespace LINQSamples;

public class Sample06 {
  /// <summary>
  /// Use 'into' to create a new object with a Sales collection for each Product
  /// This is like a combination of an inner join and left outer join
  /// The GroupJoin() method replaces the into keyword
  /// </summary>
  public static void JoinIntoMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<SalesOrder> sales = SalesOrderRepository.GetAll();
    List<ProductSales> list;

    // Write Method Syntax Here
    list = products.OrderBy(row => row.ProductID).GroupJoin(sales,
            prod => prod.ProductID,
            sale => sale.ProductID,
            (prod, newSales) => new ProductSales {
              Product = prod,
              Sales = newSales.OrderBy(row => row.SalesOrderID).ToList()
            }).ToList();

    // Display Product Sales
    foreach (ProductSales product in list) {
      Console.Write(product.Product);

      if (product.Sales.Any()) {
        Console.WriteLine("** Orders for this Product **");
        // Loop through the products in each sale
        foreach (SalesOrder sale in product.Sales) {
          Console.Write(sale);
        }
      }
      else {
        Console.WriteLine("   ** No Sales for this Product **");
      }
      Console.WriteLine();
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products/Sales: {list.Count}");

    // Pause for Result
    Console.ReadKey();
  }
}
