﻿namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// Join a Sales Order collection with Products, Create new ProductOrder object. NOTE: This is an equijoin or an inner join
  /// </summary>
  public static void InnerJoinQuery() {
    List<Product> products = ProductRepository.GetAll();
    List<SalesOrder> sales = SalesOrderRepository.GetAll();
    List<ProductOrder> list;

    // Write Query Syntax Here
    list = (from prod in products
            join sale in sales
            on prod.ProductID equals sale.ProductID
            select new ProductOrder {
              ProductID = prod.ProductID,
              Name = prod.Name,
              Color = prod.Color,
              StandardCost = prod.StandardCost,
              ListPrice = prod.ListPrice,
              Size = prod.Size,
              SalesOrderID = sale.SalesOrderID,
              OrderQty = sale.OrderQty,
              UnitPrice = sale.UnitPrice,
              LineTotal = sale.LineTotal
            }).OrderBy(p => p.Name).ToList();

    // Display Product Orders
    foreach (ProductOrder product in list) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Result
    Console.ReadKey();
  }
}
