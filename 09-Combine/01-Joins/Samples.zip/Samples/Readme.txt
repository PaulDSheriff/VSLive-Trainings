﻿Description of Samples
--------------------------------------------------
01-InnerJoinQuery() - Join a Sales Order collection with Products, Create new ProductOrder object. NOTE: This is an equijoin or an inner join
02-InnerJoinMethod() - Join a Sales Order collection with Products, Create new ProductOrder object. NOTE: This is an equijoin or an inner join

03-InnerJoinTwoFieldsQuery() - Join a Sales Order collection with Products collection using two fields. NOTE: The Type and the Names must match between the two anonymous types
04-InnerJoinTwoFieldsMethod() - Join a Sales Order collection with Products collection using two fields. NOTE: The Type and the Names must match between the two anonymous types

05-JoinIntoQuery() - Use 'into' to create a new object with a Sales collection for each Product
06-JoinIntoMethod() - Use 'into' to create a new object with a Sales collection for each Product

07-LeftOuterJoinQuery() - Perform a left join between Products and Sales using DefaultIfEmpty() and SelectMany().
08-LeftOuterJoinMethod() - Perform a left join between Products and Sales using DefaultIfEmpty() and SelectMany().
