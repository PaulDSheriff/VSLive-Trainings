﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab01() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    List<MusicGenre> genres = MusicGenreRepository.GetAll();
    List<SongGenre> songGenres;

    // Query Syntax
    songGenres = (from row in songs
                  join genreRow in genres
                  on row.GenreId equals genreRow.GenreId
                  select new SongGenre {
                    SongId = row.SongId,
                    SongName = row.SongName,
                    Artist = row.Artist,
                    Album = row.Album,
                    GenreId = row.GenreId,
                    GenreName = genreRow.Genre
                  }).OrderBy(row => row.GenreId).ToList();

    // Method Syntax
    //songGenres = songs.Join(genres,
    //              row => row.GenreId,
    //              genreRow => genreRow.GenreId,
    //              (row, genreRow) => new SongGenre {
    //                SongId = row.SongId,
    //                SongName = row.SongName,
    //                Artist = row.Artist,
    //                Album = row.Album,
    //                GenreId = row.GenreId,
    //                GenreName = genreRow.Genre
    //              }).OrderBy(row => row.GenreId).ToList();

    // Display the Results
    foreach (var song in songGenres) {
      System.Diagnostics.Debug.WriteLine(song);
    }
  }
}
