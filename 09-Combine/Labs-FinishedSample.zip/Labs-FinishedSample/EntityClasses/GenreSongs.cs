#nullable disable

using System.Text;

namespace LINQLab.EntityClasses;

public partial class GenreSongs
{
  public int GenreId { get; set; }
  public string GenreName { get; set; }
  public List<Song> Songs { get; set; }

  #region ToString Override
  public override string ToString() {
    StringBuilder sb = new(1024);

    sb.AppendLine($"Genre: {GenreName}  Genre ID: {GenreId}");
    foreach (var song in Songs) {
      sb.AppendLine($"  {song.SongName} - {song.Artist}");
    }

    return sb.ToString();
  }
  #endregion
}