#nullable disable

namespace LINQLab.EntityClasses;

public partial class MusicKind
{
  public int KindId { get; set; }
  public string Kind { get; set; }
  public DateTime LastUpdated { get; set; }

  #region ToString Override
  public override string ToString() {
    return $"{Kind} ({KindId})";
  }
  #endregion
}
