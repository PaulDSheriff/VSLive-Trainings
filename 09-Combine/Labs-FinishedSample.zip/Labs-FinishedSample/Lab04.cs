﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab04() {
    // Declare variables and fill data
    List<Song> songs;
    List<Song> songs1 = SongRepository.GetAll().Where(row => row.GenreId == 1).ToList();
    List<Song> songs2 = SongRepository.GetAll().Where(row => row.GenreId == 2).ToList();

    // Query Syntax
    songs = (from row in songs1
             select row)
              .UnionBy(songs2, row => row.SongId)
              .OrderBy(row => row.SongName).ToList();

    // Method Syntax
    //songs = songs1.UnionBy(songs2, row => row.SongId)
    //        .OrderBy(row => row.SongName).ToList();

    // Display the Results
    foreach (var song in songs) {
      System.Diagnostics.Debug.WriteLine(song);
    }

    // Display count
    System.Diagnostics.Debug.WriteLine($"Total Count: {songs.Count}");
  }
}
