﻿#nullable disable

using LINQLab.EntityClasses;

namespace LINQLab;

public class SongComparer : EqualityComparer<Song> {
  public override bool Equals(Song x, Song y) {
    return (x.SongId == y.SongId);
  }

  public override int GetHashCode(Song obj) {
    return obj.SongId.GetHashCode();
  }
}
