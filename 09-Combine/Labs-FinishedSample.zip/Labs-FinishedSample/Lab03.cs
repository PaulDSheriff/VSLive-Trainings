﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab03() {
    // Declare variables and fill data
    List<Song> songs;
    List<Song> songs1 = SongRepository.GetAll().Where(row => row.GenreId == 1).ToList();
    List<Song> songs2 = SongRepository.GetAll().Where(row => row.GenreId == 2).ToList();
    SongComparer sc = new();

    // Query Syntax
    songs = (from row in songs1
             select row)
              .Union(songs2, sc)
              .OrderBy(row => row.SongName).ToList();

    // Method Syntax
    //songs = songs1.Union(songs2, sc)
    //        .OrderBy(row => row.SongName).ToList();

    // Display the Results
    foreach (var song in songs) {
      System.Diagnostics.Debug.WriteLine(song);
    }

    // Display count
    System.Diagnostics.Debug.WriteLine($"Total Count: {songs.Count}");
  }
}
