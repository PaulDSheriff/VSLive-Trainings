﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab02() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    List<MusicGenre> genres = MusicGenreRepository.GetAll();
    List<GenreSongs> genreSongs;

    // Query Syntax
    genreSongs = (from row in genres
                  orderby row.GenreId
                  join songRow in songs
                  on row.GenreId equals songRow.GenreId
                  into songsByGenre
                  select new GenreSongs {
                    GenreId = row.GenreId,
                    GenreName = row.Genre,
                    Songs = songsByGenre.OrderBy(song => song.SongName).ToList()
                  }).ToList();

    // Method Syntax
    //genreSongs = genres.OrderBy(row => row.GenreId)
    //              .GroupJoin(songs,
    //              row => row.GenreId,
    //              songRow => songRow.GenreId,
    //              (row, songsByGenre) => new GenreSongs {
    //                GenreId = row.GenreId,
    //                GenreName = row.Genre,
    //                Songs = songsByGenre.OrderBy(song => song.SongName).ToList()
    //              }).ToList();

    // Display the Results
    foreach (var song in genreSongs) {
      System.Diagnostics.Debug.WriteLine(song);
    }
  }
}
