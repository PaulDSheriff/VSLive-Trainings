﻿namespace LINQSamples;

public class Sample04 {
  /// <summary>
  /// The Concat() method combines two lists together and does NOT check for duplicates. This is like the UNION ALL SQL operator.
  /// </summary>
  public static void ConcatMethod() {
    List<Product> list1 = ProductRepository.GetAll();
    List<Product> list2 = ProductRepository.GetAll();
    List<Product> products;

    // Write Method Syntax Here
    products = list1.Concat(list2)
                    .OrderBy(row => row.Name).ToList();

    // Display Products
    foreach (Product product in products) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {products.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
