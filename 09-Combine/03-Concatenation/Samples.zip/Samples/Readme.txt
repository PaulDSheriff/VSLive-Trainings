﻿Description of Samples
--------------------------------------------------
01-ConcatIntegersQuery() - The Concat() method combines two lists together and does NOT check for duplicates. This is like the UNION ALL SQL operator.
02-ConcatIntegersMethod() - The Concat() method combines two lists together and does NOT check for duplicates. This is like the UNION ALL SQL operator.

03-ConcatQuery() - The Concat() method combines two lists together and does NOT check for duplicates. This is like the UNION ALL SQL operator.
04-ConcatMethod() - The Concat() method combines two lists together and does NOT check for duplicates. This is like the UNION ALL SQL operator.