﻿namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// The Concat() method combines two lists together and does NOT check for duplicates. This is like the UNION ALL SQL operator.
  /// </summary>
  public static void ConcatIntegersQuery() {
    List<int> list1 = new() { 5, 2, 3, 4, 5 };
    List<int> list2 = new() { 1, 2, 3, 4, 5 };
    List<int> list;

    // Write Query Syntax Here
    list = (from row in list1
            select row)
            .Concat(list2)
            .OrderBy(row => row).ToList();

    // Display Integers
    foreach (int item in list) {
      Console.WriteLine(item);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
