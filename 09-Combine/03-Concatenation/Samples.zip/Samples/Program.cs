﻿using LINQSamples;

// Call Sample Method
Sample01.ConcatIntegersQuery();
//Sample02.ConcatIntegersMethod();
//Sample03.ConcatQuery();
//Sample04.ConcatMethod();