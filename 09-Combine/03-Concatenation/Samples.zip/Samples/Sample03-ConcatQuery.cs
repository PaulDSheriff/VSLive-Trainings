﻿namespace LINQSamples
  {
  public class Sample03 {
    /// <summary>
    /// The Concat() method combines two lists together and does NOT check for duplicates. This is like the UNION ALL SQL operator.
    /// </summary>
    public static void ConcatQuery() {
      List<Product> list1 = ProductRepository.GetAll();
      List<Product> list2 = ProductRepository.GetAll();
      List<Product> list;

      // Write Query Syntax Here
      list = (from row in list1
              select row)
              .Concat(list2)
              .OrderBy(row => row.Name).ToList();

      // Display Products
      foreach (Product product in list) {
        Console.Write(product);
      }

      Console.WriteLine();
      Console.WriteLine($"Total Products: {list.Count}");

      // Pause for Results
      Console.ReadKey();
    }
  }
}
