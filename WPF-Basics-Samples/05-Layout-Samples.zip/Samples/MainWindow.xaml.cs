﻿using System.Windows;

namespace XamlLayoutWPF
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void MultipleControlsInGrid_Click(object sender, RoutedEventArgs e)
    {
      new MultipleControlsInGrid().Show();
    }

    private void StackPanelLayout_Click(object sender, RoutedEventArgs e)
    {
      new StackPanelLayout().Show();
    }

    private void HorizontalAlignment_Click(object sender, RoutedEventArgs e)
    {
      new HorizontalAlignment().Show();
    }

    private void VerticalAlignment_Click(object sender, RoutedEventArgs e)
    {
      new VerticalAlignment().Show();
    }

    private void NestedStackPanel_Click(object sender, RoutedEventArgs e)
    {
      new NestedStackPanel().Show();
    }

    private void MarginAndPadding_Click(object sender, RoutedEventArgs e)
    {
      new MarginAndPadding().Show();
    }

    private void GridLayout_Click(object sender, RoutedEventArgs e)
    {
      new GridLayout().Show();
    }

    private void AutoAndStar_Click(object sender, RoutedEventArgs e)
    {
      new AutoAndStar().Show();
    }

    private void StackPanelWithinGridColumn_Click(object sender, RoutedEventArgs e)
    {
      new StackPanelWithinGridColumn().Show();
    }
  }
}
