﻿namespace Common.Library;

public class EntityBase : CommonBase
{
  #region Init Method
  /// <summary>
  /// Initialize any properties of this class
  /// </summary>
  public override void Init()
  {
    base.Init();
  }
  #endregion
}
