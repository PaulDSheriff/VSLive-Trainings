﻿namespace Common.Library;

public class ViewModelBase : CommonBase
{
  #region Init Method
  /// <summary>
  /// Initialize any properties of this class
  /// </summary>
  public override void Init()
  {
    base.Init();
  }
  #endregion
}
