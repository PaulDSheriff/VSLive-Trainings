﻿using System.Windows.Controls;

namespace AdventureWorks.WPF.Views {
  public partial class HomeView : UserControl {
    public HomeView() {
      InitializeComponent();
    }
  }
}
