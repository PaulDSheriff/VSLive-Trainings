﻿using System.Windows.Controls;

namespace AdventureWorks.WPF.Views {
  public partial class LoginView : UserControl {
    public LoginView() {
      InitializeComponent();
    }
  }
}
