﻿namespace Common.Library;

/// <summary>
/// This class should be inherited by all your view model classes
/// </summary>
public class ViewModelBase : CommonBase
{
}
