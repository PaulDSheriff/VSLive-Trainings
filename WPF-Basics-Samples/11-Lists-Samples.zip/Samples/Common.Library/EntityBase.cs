﻿namespace Common.Library;

/// <summary>
/// This class should be inherited by all your entity classes
/// </summary>
public class EntityBase : CommonBase
{
}
