﻿using System.Windows;

namespace SimpleDataBindingSamples
{
  public partial class VisiblityConverter : Window
  {
    public VisiblityConverter()
    {
      InitializeComponent();
    }
  }
}
