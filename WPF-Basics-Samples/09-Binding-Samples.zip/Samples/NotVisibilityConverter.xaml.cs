﻿using System.Windows;

namespace SimpleDataBindingSamples
{
  public partial class NotVisiblityConverter : Window
  {
    public NotVisiblityConverter()
    {
      InitializeComponent();
    }
  }
}
