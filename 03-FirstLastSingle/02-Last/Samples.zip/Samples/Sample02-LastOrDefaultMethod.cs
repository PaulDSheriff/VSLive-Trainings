﻿#nullable disable

namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// Locate a specific product using LastOrDefault(). LastOrDefault() searches from the end of the list backwards.
  /// NOTE: LastOrDefault returns the last value in a collection or a null if no values are found
  /// </summary>
  public static void LastOrDefaultMethod() {
    List<Product> products = ProductRepository.GetAll();
    string color = "Red";
    Product value;

    // Write Method Syntax Here
    value = products.LastOrDefault(row => row.Color == color);

    if (value == null) {
      Console.WriteLine("No Product Found");
    }
    else {
      // Display the Product Found
      Console.WriteLine(value);
    }

    Console.ReadKey();
  }
}
