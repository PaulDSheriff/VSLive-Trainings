﻿#nullable disable

namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// Locate a specific product using Last(). Last() searches from the end of the list backwards.
  /// NOTE: Last returns the last value from a collection, or throws an exception if no value is found
  /// </summary>
  public static void LastQuery() {
    List<Product> products = ProductRepository.GetAll();
    string color = "Red";
    Product value;

    try {
      // Write Query Syntax Here
      value = (from row in products
               select row)
               .Last(row => row.Color == color);

      // Display the Product Found
      Console.WriteLine(value);
    }
    catch (InvalidOperationException) {
      Console.WriteLine("No Product Found With That Color");
    }

    Console.ReadKey();
  }
}
