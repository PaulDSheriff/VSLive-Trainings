﻿#nullable disable

namespace LINQSamples;

public class Sample04 {
  /// <summary>
  /// Locate a specific product using Last(). Last() searches from the end of the list backwards.
  /// NOTE: Last returns the last value from a collection, or throws an exception if no value is found
  /// </summary>
  public static void LastMethod() {
    List<Product> products = ProductRepository.GetAll();
    string color = "Red";
    Product value;

    try {
      // Write Method Syntax Here
      value = products.Last(row => row.Color == color);

      // Display the Product Found
      Console.WriteLine(value);
    }
    catch (InvalidOperationException) {
      Console.WriteLine("No Product Found With That Color");
    }

    Console.ReadKey();
  }
}
