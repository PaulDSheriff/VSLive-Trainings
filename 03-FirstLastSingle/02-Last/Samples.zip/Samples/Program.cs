﻿using LINQSamples;

// Call Sample
Sample01.LastOrDefaultQuery();
//Sample02.LastOrDefaultMethod();
//Sample03.LastQuery();
//Sample04.LastMethod();
//Sample05.LastOrDefaultWithDefault();