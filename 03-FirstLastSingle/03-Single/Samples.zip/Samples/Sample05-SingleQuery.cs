﻿#nullable disable

namespace LINQSamples;

public class Sample05 {
  /// <summary>
  /// Locate a specific product using Single().
  /// NOTE: Single() expects only a single element to be found in the collection, otherwise an exception is thrown
  /// Single() always searches the complete collection
  /// </summary>
  public static void SingleQuery() {
    List<Product> products = ProductRepository.GetAll();
    int id = 706;
    Product value;

    try {
      // Write Query Syntax Here
      value = (from row in products
               select row)
               .Single(row => row.ProductID == id);

      // Display the Product Found
      Console.WriteLine(value);
    }
    catch (ArgumentNullException ex) {
      // This collection was null
      Console.WriteLine(ex.Message);
    }
    catch (InvalidOperationException ex) {
      // Not Found or Multiple Items Found
      Console.WriteLine(ex.Message);
    }
    catch (Exception ex) {
      Console.WriteLine(ex.Message);
    }

    Console.ReadKey();
  }
}
