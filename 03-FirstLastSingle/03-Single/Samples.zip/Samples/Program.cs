﻿using LINQSamples;

// Call Sample
Sample01.SingleOrDefaultQuery();
//Sample02.SingleOrDefaultMethod();
//Sample03.SingleOrDefaultMultiple();
//Sample04.SingleOrDefaultEmptyCollection();
//Sample05.SingleQuery();
//Sample06.SingleMethod();
//Sample07.SingleMultiple();