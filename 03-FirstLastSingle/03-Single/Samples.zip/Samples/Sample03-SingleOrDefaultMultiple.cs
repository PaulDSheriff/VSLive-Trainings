﻿#nullable disable

namespace LINQSamples;

public class Sample03 {   
  /// <summary>
  /// Attempt to locate a specific product using SingleOrDefault()
  /// If multiple values are returned, an exception is thrown
  /// SingleOrDefault() always searches the complete collection
  /// </summary>
  public static void SingleOrDefaultMultiple() {
    List<Product> products = ProductRepository.GetAll();
    string color = "Red";
    Product value;

    try {
      // Write Method Syntax Here
      value = products.SingleOrDefault(row => row.Color == color);

      if (value == null) {
        Console.WriteLine("No Product Found");
      }
      else {
        // Display the Product Found
        Console.WriteLine(value);
      }
    }
    catch (InvalidOperationException ex) {
      // Multiple Items Found
      Console.WriteLine(ex.Message);
    }

    Console.ReadKey();
  }
}
