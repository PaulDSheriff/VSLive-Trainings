﻿Description of Samples
--------------------------------------------------
01-SingleOrDefaultQuery() - Locate a specific product using SingleOrDefault(). NOTE: SingleOrDefault() returns a single element found in the collection, or a null value if none found in the collection, if multiple values are found an exception is thrown.
02-SingleOrDefaultMethod() - Locate a specific product using SingleOrDefault(). NOTE: SingleOrDefault() returns a single element found in the collection, or a null value if none found in the collection, if multiple values are found an exception is thrown.

03-SingleOrDefaultMultiple() - Show exception when multiple values are found

04-SingleOrDefaultEmptyCollection() - Search using an empty collection

05-SingleQuery() - Locate a specific product using Single(). NOTE: Single() expects only a single element to be found in the collection, otherwise an exception is thrown
06-SingleMethod() - Locate a specific product using Single(). NOTE: Single() expects only a single element to be found in the collection, otherwise an exception is thrown

07-SingleMultiple() - Show exception when multiple values are found