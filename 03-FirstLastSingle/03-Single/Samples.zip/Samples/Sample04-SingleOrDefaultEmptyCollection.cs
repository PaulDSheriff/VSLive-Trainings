﻿#nullable disable

namespace LINQSamples;

public class Sample04 {
  /// <summary>
  /// Attempt to locate a specific product using SingleOrDefault()
  /// Returns default value if collection is empty
  /// SingleOrDefault() always searches the complete collection
  /// </summary>
  public static void SingleOrDefaultEmptyCollection() {
    List<Product> products = new();
    int id = 706;
    Product value;

    // Write Method Syntax Here
    value = products.SingleOrDefault(row => row.ProductID == id,
      new Product { ProductID = -1 });

    if (value == null) {
      Console.WriteLine("No Product Found");
    }
    else {
      // Display the Product Found
      Console.WriteLine(value);
    }

    Console.ReadKey();
  }
}
