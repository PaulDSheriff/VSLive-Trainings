﻿#nullable disable

namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// Locate a specific product using SingleOrDefault()
  /// NOTE: SingleOrDefault() returns a single element found in the collection, or a null value if none found in the collection, if multiple values are found an exception is thrown.
  /// SingleOrDefault() always searches the complete collection
  /// </summary>
  public static void SingleOrDefaultQuery() {
    List<Product> products = ProductRepository.GetAll();
    int id = 706;
    Product value;

    // Write Query Syntax Here
    value = (from row in products
             select row)
            .SingleOrDefault(row => row.ProductID == id);

    if (value == null) {
      Console.WriteLine("No Product Found");
    }
    else {
      // Display the Product Found
      Console.WriteLine(value);
    }

    Console.ReadKey();
  }
}
