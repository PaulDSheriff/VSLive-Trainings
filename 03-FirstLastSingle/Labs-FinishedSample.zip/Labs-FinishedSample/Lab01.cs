﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab01() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    Song? value;

    // Query Syntax
    value = (from row in songs select row).FirstOrDefault(row => row.GenreId == 11117);

    // Method Syntax
    //value = songs.FirstOrDefault(row => row.GenreId == 17);

    // Was the data in the collection?
    if (value == null) {
      Console.WriteLine("Genre Not Found");
    }
    else {
      // Display the Data Found
      Console.WriteLine(value);
    }

    // Pause for Results
    Console.ReadKey();
  }
}
