﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab05() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    Song? value;

    try {
      // Query Syntax
      value = (from row in songs select row)
                .First(row => row.GenreId == 17);

      // Method Syntax
      //value = songs.First(row => row.GenreId == 17);

      // Display the Data Found
      Console.WriteLine(value);
    }
    catch (InvalidOperationException) {
      Console.WriteLine("Genre Not Found");
    }
    catch (Exception ex) {
      Console.WriteLine(ex.Message);
    }

    // Pause for Results
    Console.ReadKey();
  }
}
