﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab03() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    Song? value;

    // Query Syntax
    value = (from row in songs select row)
      .FirstOrDefault(row => row.GenreId == 17,
      new Song { SongId = -1, SongName = "Genre Not Found" });

    // Method Syntax
    //value = songs.FirstOrDefault(row => row.GenreId == 17,
    //  new Song { SongId = -1, SongName = "Genre Not Found" });

    // Was the data in the collection?
    if (value == null) {
      Console.WriteLine("Genre Not Found");
    }
    else {
      // Display the Data Found
      Console.WriteLine(value);
    }

    // Pause for Results
    Console.ReadKey();
  }
}
