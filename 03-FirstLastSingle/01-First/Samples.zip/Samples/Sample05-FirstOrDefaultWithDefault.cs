﻿#nullable disable

namespace LINQSamples;

public class Sample05 {
  /// <summary>
  /// Locate a specific product using FirstOrDefault(). FirstOrDefault() searches forward in the list.
  /// NOTE: You may specify the return value with FirstOrDefault() if not found
  /// Use FirstOrDefault() when you DON'T know if a collection might have one element you are looking for
  /// Using FirstOrDefault() avoids throwing an exception which can hurt performance
  /// </summary>
  public static void FirstOrDefaultWithDefaultMethod() {
    List<Product> products = ProductRepository.GetAll();
    string color = "Red";
    Product value;

    // Write Method Syntax Here
    value = products
             .FirstOrDefault(row => row.Color == color,
               new Product { ProductID = -1, Name = "No Product Found" });

    if (value.ProductID == -1) {
      Console.WriteLine("No Product Found");
    }
    else {
      // Display the Product Found
      Console.WriteLine(value);
    }

    Console.ReadKey();
  }
}
