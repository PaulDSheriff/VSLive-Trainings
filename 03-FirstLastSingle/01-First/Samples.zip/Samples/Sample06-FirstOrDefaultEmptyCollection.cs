﻿#nullable disable

namespace LINQSamples;

public class Sample06 {
  /// <summary>
  /// Attempt to locate a specific product using FirstOrDefault(). FirstOrDefault() searches forward in the list.
  /// If the collection is empty, returns the default value
  /// </summary>
  public static void FirstOrDefaultEmptyCollection() {
    List<Product> products = new();
    string color = "Red";
    Product value;

    // Write Method Syntax Here
    value = products
             .FirstOrDefault(row => row.Color == color,
               new Product { ProductID = -1, Name = "No Product Found" });

    if (value.ProductID == -1) {
      Console.WriteLine("No Product Found");
    }
    else {
      // Display the Product Found
      Console.WriteLine(value);
    }

    Console.ReadKey();
  }
}
