﻿using LINQSamples;

// Call Sample
Sample01.FirstOrDefaultQuery();
//Sample02.FirstOrDefaultMethod();
//Sample03.FirstQuery();
//Sample04.FirstMethod();
//Sample05.FirstOrDefaultWithDefaultMethod();
//Sample06.FirstOrDefaultEmptyCollection();