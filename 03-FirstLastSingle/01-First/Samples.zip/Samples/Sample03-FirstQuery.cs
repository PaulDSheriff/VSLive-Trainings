﻿#nullable disable

namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// Locate a specific product using First(). First() searches forward in the collection.
  /// NOTE: First() throws an exception if the result does not produce any values
  /// Use First() when you know or expect the sequence to have at least one element.
  /// Exceptions should be exceptional, so try to avoid them.
  /// </summary>
  public static void FirstQuery() {
    List<Product> products = ProductRepository.GetAll();
    string color = "Red";
    Product value;

    try {
      // Write Query Syntax Here
      value = (from row in products
               select row)
               .First(row => row.Color == color);

      // Display the Product Found
      Console.WriteLine(value);
    }
    catch (InvalidOperationException) {
      Console.WriteLine("No Product Found With That Color");
    }

    Console.ReadKey();
  }
}
