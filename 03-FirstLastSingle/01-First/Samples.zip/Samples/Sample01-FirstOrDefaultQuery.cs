﻿#nullable disable

namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// Locate a specific product using FirstOrDefault(). FirstOrDefault() searches forward in the list.
  /// NOTE: FirstOrDefault() returns a null if no value is found
  /// Use FirstOrDefault() when you DON'T know if a collection might have one element you are looking for
  /// Using FirstOrDefault() avoids throwing an exception which can hurt performance
  /// </summary>
  public static void FirstOrDefaultQuery() {
    List<Product> products = ProductRepository.GetAll();
    string color = "Red";
    Product value;

    // Write Query Syntax Here
    value = (from row in products
             select row)
             .FirstOrDefault(row => row.Color == color);

    if (value == null) {
      Console.WriteLine("No Product Found");
    }
    else {
      // Display the Product Found
      Console.WriteLine(value);
    }

    Console.ReadKey();
  }
}
