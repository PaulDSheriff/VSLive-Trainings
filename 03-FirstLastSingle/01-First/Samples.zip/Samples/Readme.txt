﻿Description of Samples
--------------------------------------------------
01-FirstOrDefaultQuery() - Locate a specific product using FirstOrDefault(). FirstOrDefault() searches forward in the list. NOTE: FirstOrDefault() returns a null if no value is found
02-FirstOrDefaultMethod() - Locate a specific product using FirstOrDefault(). FirstOrDefault() searches forward in the list. NOTE: FirstOrDefault() returns a null if no value is found

03-FirstQuery() - Locate a specific product using First(). First() searches forward in the collection. NOTE: First() throws an exception if the result does not produce any values
04-FirstMethod() - Locate a specific product using First(). First() searches forward in the collection. NOTE: First() throws an exception if the result does not produce any values

05-FirstOrDefaultWithDefault() - Use a custom default value when not found

06-FirstOrDefaultEmptyCollection() - Searching through an empty collection
