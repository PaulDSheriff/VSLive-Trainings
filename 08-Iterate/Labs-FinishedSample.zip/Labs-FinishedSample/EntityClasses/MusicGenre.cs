#nullable disable

namespace LINQLab.EntityClasses;

public partial class MusicGenre {
  public int GenreId { get; set; }
  public string Genre { get; set; }
  public DateTime LastUpdated { get; set; }

  #region ToString Override
  public override string ToString() {
    return $"{Genre} ({GenreId})";
  }
  #endregion
}
