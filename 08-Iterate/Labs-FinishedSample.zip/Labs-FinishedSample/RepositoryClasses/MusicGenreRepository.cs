#nullable disable

using LINQLab.EntityClasses;

namespace LINQLab.RepositoryClasses;

public partial class MusicGenreRepository {
  #region GetAll Method
  /// <summary>
  /// Get all MusicGenre objects
  /// </summary>
  /// <returns>A list of MusicGenre objects</returns>
  public static List<MusicGenre> GetAll() {
    return new List<MusicGenre>
    {
      new MusicGenre {
         GenreId = 1,
         Genre = @"General Country",
         LastUpdated = Convert.ToDateTime("9/6/2011 3:01:31 PM"),
      },
      new MusicGenre {
         GenreId = 2,
         Genre = @"Rock",
         LastUpdated = Convert.ToDateTime("9/3/2011 1:22:36 AM"),
      },
      new MusicGenre {
         GenreId = 3,
         Genre = @"Comedy",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 4,
         Genre = @"Disco",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 5,
         Genre = @"Alternative Rock",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 6,
         Genre = @"Books & Spoken",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 7,
         Genre = @"Soundtrack",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 8,
         Genre = @"Unclassifiable",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 9,
         Genre = @"Blues",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 10,
         Genre = @"Ska",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 11,
         Genre = @"Other",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 12,
         Genre = @"World",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 13,
         Genre = @"Singer/Songwriter",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 14,
         Genre = @"Spoken & Audio",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 15,
         Genre = @"Top 40",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 16,
         Genre = @"Rock & Roll",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 17,
         Genre = @"Jazz",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 18,
         Genre = @"Punk",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 19,
         Genre = @"Reggae",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 20,
         Genre = @"Rock/Pop",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 21,
         Genre = @"R&B/Soul",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 22,
         Genre = @"Easy Listening",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 23,
         Genre = @"Old Time Radio",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 24,
         Genre = @"Vocal",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 25,
         Genre = @"New Wave",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 26,
         Genre = @"Soft Rock",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 27,
         Genre = @"Alternative & Punk",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 28,
         Genre = @"Christian & Gospel",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 29,
         Genre = @"Classic Rock",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 30,
         Genre = @"Pop",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 31,
         Genre = @"Children’s Music",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 32,
         Genre = @"Progressive Rock",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 33,
         Genre = @"R&B",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 34,
         Genre = @"Hip Hop/Rap",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 35,
         Genre = @"Country-2",
         LastUpdated = Convert.ToDateTime("10/12/2011 7:06:32 PM"),
      },
      new MusicGenre {
         GenreId = 36,
         Genre = @"Folk",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 37,
         Genre = @"Latino",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 38,
         Genre = @"Hard Rock",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 39,
         Genre = @"New Age",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 40,
         Genre = @"Electronic",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 41,
         Genre = @"Southern Rock",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 42,
         Genre = @"Dance",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 43,
         Genre = @"Alternative",
         LastUpdated = Convert.ToDateTime("9/2/2011 8:48:24 PM"),
      },
      new MusicGenre {
         GenreId = 44,
         Genre = @"Death Metal",
         LastUpdated = Convert.ToDateTime("10/2/2011 8:48:24 PM"),
      }
    };
  }
  #endregion

  #region Get Method
  /// <summary>
  /// Get a single MusicGenre object
  /// </summary>
  /// <param name="id">The value to locate</param>
  /// <returns>A valid MusicGenre object object, or null if not found</returns>
  public MusicGenre Get(int id) {
    return GetAll().Where(row => row.GenreId == id).FirstOrDefault();
  }
  #endregion

  #region Insert Method
  /// <summary>
  /// Insert a new MusicGenre object
  /// </summary>
  /// <param name="entity">The data to insert</param>
  /// <returns>The inserted MusicGenre object</returns>
  public MusicGenre Insert(MusicGenre entity) {
    GetAll().Add(entity);

    // TODO: Insert into data store
    entity.GenreId = GetAll().Max(row => row.GenreId) + 1;

    return entity;
  }
  #endregion

  #region Update Method
  /// <summary>
  /// Update existing MusicGenre object
  /// </summary>
  /// <param name="entity">The data to update</param>
  /// <returns>The updated MusicGenre object</returns>
  public MusicGenre Update(MusicGenre entity) {
    // Look up the data by the specified id
    MusicGenre current = Get(entity.GenreId);

    if (current != null) {
      // TODO: Update the entity
      current.Genre = entity.Genre;
      current.LastUpdated = entity.LastUpdated;

      // TODO: Update data store

    }

    return current;
  }
  #endregion

  #region Delete Method
  /// <summary>
  /// Delete a MusicGenre object
  /// </summary>
  /// <param name="id">The value to delete</param>
  /// <returns>True if delete, false if not found</returns>
  public bool Delete(int id) {
    bool ret = false;

    // Look up the data by the specified id
    MusicGenre current = Get(id);

    if (current != null) {
      // TODO: Delete data from data store
      GetAll().RemoveAll(row => row.GenreId == id);
      ret = true;
    }

    return ret;
  }
  #endregion
}