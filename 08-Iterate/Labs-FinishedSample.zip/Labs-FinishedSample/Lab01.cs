﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab01() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();

    // Query Syntax
    (from row in songs
     let tmp = row.SongArtistAlbum = row.SongName + Environment.NewLine + row.Artist + Environment.NewLine + row.Album + Environment.NewLine
     select row).ToList();

    // Method Syntax
    //songs.ForEach(row => row.SongArtistAlbum = row.SongName + Environment.NewLine + row.Artist + Environment.NewLine + row.Album + Environment.NewLine);

    // Display the Results
    foreach (var song in songs) {
      // Display the SongArtistAlbum property
      Console.WriteLine(song.SongArtistAlbum);
    }

    // Pause for Results
    Console.ReadKey();
  }
}
