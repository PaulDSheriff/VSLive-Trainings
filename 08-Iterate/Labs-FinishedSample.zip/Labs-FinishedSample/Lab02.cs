﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab02() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    List<MusicGenre> genres = MusicGenreRepository.GetAll();

    // Query Syntax
    (from row in songs
     let tmp = row.GenreName =
       (from genreRow in genres
        where row.GenreId == genreRow.GenreId
        select genreRow.Genre).FirstOrDefault()
     select row).ToList();

    // Method Syntax
    //songs.ForEach(row => row.GenreName = 
    //   genres.Where(genreRow => row.GenreId == genreRow.GenreId)
    //         .Select(genreRow => genreRow.Genre)
    //         .FirstOrDefault());

    // Display the Results
    foreach (var song in songs) {
      // Display the Genre Information
      Console.WriteLine($"GenreId: {song.GenreId}\tGenre Name: {song.GenreName}");
    }

    // Pause for Results
    Console.ReadKey();
  }
}
