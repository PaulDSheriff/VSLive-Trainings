﻿Description of Samples
--------------------------------------------------
01-ForEachQuery() - ForEach allows you to iterate over a collection to perform assignments within each object.
02-ForEachMethod() - ForEach allows you to iterate over a collection to perform assignments within each object.

03-ForEachCalculateNameLength() - Calculate length of each Name property