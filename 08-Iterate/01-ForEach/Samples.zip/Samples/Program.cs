﻿using LINQSamples;

// Call Sample Method
Sample01.ForEachQuery();
//Sample02.ForEachMethod();
//Sample03.ForEachCalculateNameLengthQuery();