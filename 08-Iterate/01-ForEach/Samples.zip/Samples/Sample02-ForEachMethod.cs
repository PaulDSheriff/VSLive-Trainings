﻿namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// ForEach allows you to iterate over a collection to perform assignments within each object.
  /// Assign the LineTotal from the OrderQty * UnitPrice
  /// </summary>
  public static void ForEachMethod() {
    // Get all Sales Data
    List<SalesOrder> sales = SalesOrderRepository.GetAll();

    // Write Method Syntax Here
    sales.ForEach(row => row.LineTotal = row.OrderQty * row.UnitPrice);

    // Display Sales
    foreach (SalesOrder sale in sales) {
      Console.Write(sale);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Sales: {sales.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
