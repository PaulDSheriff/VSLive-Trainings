﻿namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// Calculate length of each Name property
  /// </summary>
  public static void ForEachCalculateNameLengthQuery() {
    List<Product> products = ProductRepository.GetAll();

    // Write Query Syntax Here
    (from row in products
     let tmp = row.NameLength = row.Name.Length
     select row).ToList();

    // Display Products
    foreach (Product product in products) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {products.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
