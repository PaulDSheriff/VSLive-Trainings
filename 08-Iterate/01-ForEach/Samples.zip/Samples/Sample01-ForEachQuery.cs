﻿namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// ForEach allows you to iterate over a collection to perform assignments within each object.
  /// Assign the LineTotal from the OrderQty * UnitPrice
  /// When using the Query syntax, assign the result to a temporary variable.
  /// </summary>
  public static void ForEachQuery() {
    // Get all Sales Data
    List<SalesOrder> sales = SalesOrderRepository.GetAll();

    // Write Query Syntax Here
    (from row in sales
     let tmp = row.LineTotal = row.OrderQty * row.UnitPrice
     select row).ToList();

    // Display Sales
    foreach (SalesOrder sale in sales) {
      Console.Write(sale);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Sales: {sales.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
