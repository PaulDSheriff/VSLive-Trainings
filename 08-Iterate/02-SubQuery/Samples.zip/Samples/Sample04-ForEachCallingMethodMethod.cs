﻿namespace LINQSamples;

public class Sample04 {
  /// <summary>
  /// Iterate over each object in the collection and call a method to set a property.
  /// This method passes in each Product object into the SalesForProduct() method.
  /// In the CalculateTotalSalesForProduct() method, the total sales for each Product is calculated.
  /// The total is placed into each Product objects' TotalSales property.
  /// </summary>
  public static void ForEachCallingMethodMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<SalesOrder> sales = SalesOrderRepository.GetAll();

    // Write Method Syntax Here
    products.ForEach(row => row.TotalSales = CalculateTotalSalesForProduct(row, sales));
    products = products.Where(row => row.TotalSales > 0).ToList();

    // Display Products
    foreach (Product product in products.Where(row => row.TotalSales > 0)) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {products.Count}");

    // Pause for Results
    Console.ReadKey();
  }

  /// <summary>
  /// Helper method called by LINQ to sum sales for a product
  /// </summary>
  /// <param name="product">A product</param>
  /// <returns>Total Sales for Product</returns>
  private static decimal CalculateTotalSalesForProduct(Product product, List<SalesOrder> sales) {
    return sales.Where(salesRow => salesRow.ProductID == product.ProductID)
                .Sum(salesRow => salesRow.LineTotal);
  }
}
