﻿using LINQSamples;

// Call Sample Method
Sample01.ForEachSubQueryQuery();
//Sample02.ForEachSubQueryMethod();
//Sample03.ForEachCallingMethodQuery();
//Sample04.ForEachCallingMethodMethod();