﻿namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// Iterate over each object in the collection and use a sub query to calculate total sales
  /// </summary>
  public static void ForEachSubQueryQuery() {
    List<Product> products = ProductRepository.GetAll();
    List<SalesOrder> sales = SalesOrderRepository.GetAll();

    // Write Query Syntax Here
    (from row in products
     let tmp = row.TotalSales =
       (from salesRow in sales 
        where row.ProductID == salesRow.ProductID 
        select salesRow.LineTotal).Sum()
     select row).ToList();

    // Display Products
    foreach (Product product in products.Where(row => row.TotalSales > 0)) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {products.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
