﻿Description of Samples
--------------------------------------------------
01-ForEachSubQuery() - Iterate over each object in the collection and use a sub query to calculate total sales
02-ForEachSubMethod() - Iterate over each object in the collection and use a sub query to calculate total sales

03-ForEachCallingMethodQuery() - Iterate over each object in the collection and call a method to set a property
04-ForEachCallingMethodMethod() - Iterate over each object in the collection and call a method to set a property