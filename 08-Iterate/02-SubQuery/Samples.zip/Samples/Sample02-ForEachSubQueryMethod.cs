﻿namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// Iterate over each object in the collection and use a sub query to calculate total sales
  /// </summary>
  public static void ForEachSubQueryMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<SalesOrder> sales = SalesOrderRepository.GetAll();

    // Write Method Syntax Here
    products.ForEach(row => row.TotalSales =
      sales.Where(salesRow => salesRow.ProductID == salesRow.ProductID)
           .Sum(salesRow => salesRow.LineTotal));

    // Display Products
    foreach (Product product in products.Where(row => row.TotalSales > 0)) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {products.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
