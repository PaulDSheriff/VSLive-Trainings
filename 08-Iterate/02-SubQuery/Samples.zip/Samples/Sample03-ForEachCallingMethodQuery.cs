﻿namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// Iterate over each object in the collection and call a method to set a property.
  /// This method passes in each Product object into the SalesForProduct() method.
  /// In the CalculateTotalSalesForProduct() method, the total sales for each Product is calculated.
  /// The total is placed into each Product objects' TotalSales property.
  /// </summary>
  public static void ForEachCallingMethodQuery() {
    List<Product> products = ProductRepository.GetAll();
    List<SalesOrder> sales = SalesOrderRepository.GetAll();

    // Write Query Syntax Here
    (from row in products
     let tmp = row.TotalSales = CalculateTotalSalesForProduct(row, sales)
     select row).ToList();

    products = products.Where(row => row.TotalSales > 0).ToList();

    // Display Products
    foreach (Product product in products.Where(row => row.TotalSales > 0)) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {products.Count}");

    // Pause for Results
    Console.ReadKey();
  }

  /// <summary>
  /// Helper method called by LINQ to sum sales for a product
  /// </summary>
  /// <param name="product">A product</param>
  /// <returns>Total Sales for Product</returns>
  private static decimal CalculateTotalSalesForProduct(Product product, List<SalesOrder> sales) {
    return (from salesRow in sales
            where product.ProductID == salesRow.ProductID
            select salesRow.LineTotal).Sum();
  }
}
