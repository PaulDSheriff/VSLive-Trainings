﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab01() {
    // Declare variables and fill data
    List<Song> songs1 = SongRepository.GetAll();
    List<Song> songs2 = SongRepository.GetAll();
    bool value;

    // Query Syntax
    value = (from row in songs1
             select row)
             .SequenceEqual(songs2);

    // Method Syntax
    //value = songs1
    //        .SequenceEqual(songs2);

    // Display the Results
    Console.WriteLine($"Result: {value}");

    // Pause for results
    Console.ReadKey();
  }
}
