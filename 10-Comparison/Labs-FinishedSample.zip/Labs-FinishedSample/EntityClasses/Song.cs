#nullable disable

using System.Text;

namespace LINQLab.EntityClasses;

public partial class Song
{
  public int SongId { get; set; }
  public string SongName { get; set; }
  public string Artist { get; set; }
  public string Album { get; set; }
  public int? GenreId { get; set; }
  public int? KindId { get; set; }
  public string TrackNumber { get; set; }
  public int? Rating { get; set; }
  public int? Year { get; set; }
  public DateTime? ReleaseDate { get; set; }
  public string Size { get; set; }
  public int? Plays { get; set; }
  public DateTime? DateAdded { get; set; }
  public string SongArtistAlbum { get; set; }
  public string GenreName { get; set; }

  #region ToString Override
  public override string ToString() {
    StringBuilder sb = new(1024);

    sb.AppendLine($"Song: {SongName}  ID: {SongId}");
    sb.AppendLine($"  Artist: {Artist}");
    sb.AppendLine($"  Album: {Album}");
    sb.AppendLine($"  Year: {Year}");

    return sb.ToString();
  }
  #endregion
}