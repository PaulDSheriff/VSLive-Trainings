#nullable disable

using System.Text;

namespace LINQLab.EntityClasses;

public partial class SongGenre
{
  public int SongId { get; set; }
  public string SongName { get; set; }
  public string Artist { get; set; }
  public string Album { get; set; }
  public int? GenreId { get; set; }
  public string GenreName { get; set; }

  #region ToString Override
  public override string ToString() {
    StringBuilder sb = new(1024);

    sb.AppendLine($"Song: {SongName}  ID: {SongId}");
    sb.AppendLine($"  Artist: {Artist}");
    sb.AppendLine($"  Album: {Album}");
    sb.AppendLine($"  Genre: {GenreName}");

    return sb.ToString();
  }
  #endregion
}