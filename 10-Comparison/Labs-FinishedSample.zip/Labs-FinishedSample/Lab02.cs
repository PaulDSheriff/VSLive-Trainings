﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab02() {
    // Declare variables and fill data
    List<Song> songs1 = SongRepository.GetAll();
    List<Song> songs2 = SongRepository.GetAll();
    SongComparer sc = new();
    bool value;

    // Query Syntax
    value = (from row in songs1
             select row)
             .SequenceEqual(songs2, sc);

    // Method Syntax
    //value = songs1.SequenceEqual(songs2, sc);

    // Display the Results
    Console.WriteLine($"Result: {value}");

    // Pause for results
    Console.ReadKey();
  }
}
