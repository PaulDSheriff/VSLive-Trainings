﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab03() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    List<MusicGenre> genres = MusicGenreRepository.GetAll();
    List<int> list;

    // Query Syntax
    list = (from row in genres
            select row.GenreId)
            .Except(from row in songs
                    select row.GenreId.HasValue ? row.GenreId.Value : -1).ToList();

    // Method Syntax
    //list = genres.Select(row => row.GenreId)
    //             .Except(songs.Select(row => row.GenreId.HasValue ? row.GenreId.Value : -1)).ToList();

    // Display the Results
    foreach (var value in list) {
      Console.WriteLine(value);
    }

    // Display Count
    Console.WriteLine($"Result: {list.Count}");

    // Pause for results
    Console.ReadKey();
  }
}
