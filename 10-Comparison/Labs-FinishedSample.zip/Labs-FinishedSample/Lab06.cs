﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab06() {
    // Declare variables and fill data
    List<Song> songs1 = SongRepository.GetAll()
                        .Where(row => row.TrackNumber == "3").ToList();
    List<Song> songs2 = SongRepository.GetAll()
                          .Where(row => row.GenreId == 30).ToList();
    List<int> list;

    // Query Syntax
    list = (from row in songs1
            select row.SongId)
            .Intersect(from row in songs2
                       select row.SongId).ToList();

    // Method Syntax
    //list = songs1.Select(row => row.SongId)
    //       .Intersect(songs2.Select(row => row.SongId)).ToList();

    // Display the Results
    foreach (var value in list) {
      Console.WriteLine(value);
    }

    // Display Count
    Console.WriteLine($"Result: {list.Count}");

    // Pause for results
    Console.ReadKey();
  }
}
