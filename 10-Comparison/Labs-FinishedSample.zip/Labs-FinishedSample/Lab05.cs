﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab05() {
    // Declare variables and fill data
    List<Song> songs1 = SongRepository.GetAll()
                        .Where(row => row.TrackNumber == "3").ToList();
    List<Song> songs2 = SongRepository.GetAll()
                        .Where(row => row.GenreId == 30).ToList();
    List<Song> list;

    // Query Syntax
    list = (from row in songs1
            select row)
            .ExceptBy<Song, int>(from row in songs2
                                 select row.SongId,
                                 row => row.SongId).ToList();

    // Method Syntax
    //list = songs1
    //       .ExceptBy<Song, int>(songs2.Select(row => row.SongId),
    //                            row => row.SongId).ToList();

    // Display the Results
    foreach (var value in list) {
      Console.WriteLine(value);
    }

    // Display Count
    Console.WriteLine($"Result: {list.Count}");

    // Pause for results
    Console.ReadKey();
  }
}
