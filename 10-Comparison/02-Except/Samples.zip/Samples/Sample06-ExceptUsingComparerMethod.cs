﻿namespace LINQSamples;

public class Sample06 {
  /// <summary>
  /// Find all products that are in one list but not the other using a comparer class
  /// </summary>
  public static void ExceptUsingComparerMethod() {
    List<Product> list1 = ProductRepository.GetAll();
    List<Product> list2 = ProductRepository.GetAll();
    ProductComparer pc = new();
    List<Product> list;

    // Remove all products with color = "Black" from 'list2'
    // to give us a difference in the two lists
    list2.RemoveAll(row => row.Color == "Black");

    // Write Method Syntax Here
    list = list1.Except(list2, pc).ToList();

    // Display Products
    foreach (Product product in list) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
