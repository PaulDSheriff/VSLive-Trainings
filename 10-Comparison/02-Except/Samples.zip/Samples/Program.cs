﻿using LINQSamples;

// Call Sample Method
Sample01.ExceptIntegersQuery();
//Sample02.ExceptIntegersMethod();
//Sample03.ExceptProductSalesQuery();
//Sample04.ExceptProductSalesMethod();
//Sample05.ExceptUsingComparerQuery();
//Sample06.ExceptUsingComparerMethod();