﻿namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// Find all products that do not have sales
  /// </summary>
  public static void ExceptProductSalesQuery() {
    List<Product> products = ProductRepository.GetAll();
    List<SalesOrder> sales = SalesOrderRepository.GetAll();
    List<int> list;

    // Write Query Syntax Here
    list = (from row in products
            select row.ProductID)
            .Except(from row in sales
                    select row.ProductID).ToList();

    // Display Product ID's
    foreach (int item in list) {
      Console.WriteLine(item);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
