﻿Description of Samples
--------------------------------------------------
01-ExceptIntegersQuery() - Find all values in one list that are not in the other list
02-ExceptIntegersMethod() - Find all values in one list that are not in the other list

03-ExceptProductSalesQuery() - Find all products that do not have sales
04-ExceptProductSalesMethod() - Find all products that do not have sales

05-ExceptUsingComparerQuery() - Find all products that are in one list but not the other using a comparer class
05-ExceptUsingComparerMethod() - Find all products that are in one list but not the other using a comparer class
