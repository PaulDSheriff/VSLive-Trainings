﻿namespace LINQSamples;

public class Sample04 {
  /// <summary>
  /// Find all products that have sales
  /// </summary>
  public static void IntersectProductSalesMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<SalesOrder> sales = SalesOrderRepository.GetAll();
    List<int> list;

    // Write Method Syntax Here
    list = products.Select(row => row.ProductID)
            .Intersect(sales.Select(row => row.ProductID)).ToList();

    // Display Integers
    foreach (int item in list) {
      Console.WriteLine(item);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
