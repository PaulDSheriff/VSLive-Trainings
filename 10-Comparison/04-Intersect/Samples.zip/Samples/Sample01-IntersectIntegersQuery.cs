﻿namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// Intersect() finds all values in one list that are also in the other list
  /// </summary>
  public static void IntersectIntegersQuery() {
    List<int> list1 = new() { 5, 2, 3, 4, 5 };
    List<int> list2 = new() { 3, 4, 5 };
    List<int> list;

    // Write Query Syntax Here
    list = (from row in list1
            select row)
            .Intersect(list2).ToList();

    // Display Integers
    foreach (int item in list) {
      Console.WriteLine(item);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
