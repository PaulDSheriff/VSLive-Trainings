﻿namespace LINQSamples;

public class Sample05 {
  /// <summary>
  /// Intersect() finds all products that are in common between two collections using a comparer class
  /// </summary>
  public static void IntersectUsingComparerQuery() {
    // Get all products where color is NOT black
    List<Product> list1 = ProductRepository.GetAll().Where(row => row.Color != "Black").ToList();
    // Get all products where color is NOT red
    List<Product> list2 = ProductRepository.GetAll().Where(row => row.Color != "Red").ToList();
    ProductComparer pc = new();
    List<Product> list;

    // Write Query Syntax Here
    list = (from row in list1
            select row)
            .Intersect(list2, pc).ToList();

    // Display Products
    foreach (Product product in list) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
