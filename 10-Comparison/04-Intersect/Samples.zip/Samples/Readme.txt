﻿Description of Samples
--------------------------------------------------
01-IntersectIntegersQuery() - Intersect() finds all values in one list that are also in the other list
02-IntersectIntegersMethod() - Intersect() finds all values in one list that are also in the other list

03-IntersectProductSalesQuery() - Find all products that have sales
04-IntersectProductSalesMethod() - Find all products that have sales

05-IntersectUsingComparerQuery() - Find all products that are in common between two collections using a comparer class
06-IntersectUsingComparerMethod() - Find all products that are in common between two collections using a comparer class