﻿namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// Find all products that have sales
  /// </summary>
  public static void IntersectProductSalesQuery() {
    List<Product> products = ProductRepository.GetAll();
    List<SalesOrder> sales = SalesOrderRepository.GetAll();
    List<int> list;

    // Write Query Syntax Here
    list = (from row in products
            select row.ProductID)
            .Intersect(from row in sales
                       select row.ProductID).ToList();

    // Display Integers
    foreach (int item in list) {
      Console.WriteLine(item);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
