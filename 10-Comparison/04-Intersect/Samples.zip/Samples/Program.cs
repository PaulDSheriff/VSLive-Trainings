﻿using LINQSamples;

// Call Sample Method
Sample01.IntersectIntegersQuery();
//Sample02.IntersectIntegersMethod();
//Sample03.IntersectProductSalesQuery();
//Sample04.IntersectProductSalesMethod();
//Sample05.IntersectUsingComparerQuery();
//Sample06.IntersectUsingComparerMethod();