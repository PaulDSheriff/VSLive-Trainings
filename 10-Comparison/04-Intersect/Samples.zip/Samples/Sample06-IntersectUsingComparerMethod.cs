﻿namespace LINQSamples;

public class Sample06 {
  /// <summary>
  /// Intersect() finds all products that are in common between two collections using a comparer class
  /// </summary>
  public static void IntersectUsingComparerMethod() {
    // Get all products where color is NOT black
    List<Product> list1 = ProductRepository.GetAll().Where(row => row.Color != "Black").ToList();
    // Get all products where color is NOT red
    List<Product> list2 = ProductRepository.GetAll().Where(row => row.Color != "Red").ToList();
    ProductComparer pc = new();
    List<Product> list;

    // Write Method Syntax Here
    list = list1.Intersect(list2, pc).ToList();

    // Display Products
    foreach (Product product in list) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
