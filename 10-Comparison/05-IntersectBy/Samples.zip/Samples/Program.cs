﻿using LINQSamples;

// Call Sample Method
Sample01.IntersectByQuery();
//Sample02.IntersectByMethod();
//Sample03.IntersectByProductSalesQuery();
//Sample04.IntersectByProductSalesMethod();