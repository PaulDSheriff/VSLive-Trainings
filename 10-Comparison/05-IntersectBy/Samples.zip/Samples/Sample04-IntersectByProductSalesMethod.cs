﻿namespace LINQSamples;

public class Sample04 {
  /// <summary>
  /// Find all products that have sales using a 'int' key selector
  /// Change the default comparer for IntersectBy()
  /// </summary>
  public static void IntersectByProductSalesMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<SalesOrder> sales = SalesOrderRepository.GetAll();
    List<Product> list;

    // Write Method Syntax Here
    list = products
      .IntersectBy<Product, int>(sales.Select(row => row.ProductID),
                                 row => row.ProductID).ToList();

    // Display Products
    foreach (Product product in list) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
