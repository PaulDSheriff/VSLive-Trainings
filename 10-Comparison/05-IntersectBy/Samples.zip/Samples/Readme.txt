﻿Description of Samples
--------------------------------------------------
01-IntersectByQuery() - Find products within a collection by comparing a List<string> against a specified property in the collection.
02-IntersectByMethod() - Find products within a collection by comparing a List<string> against a specified property in the collection.

03-IntersectByProductSalesQuery() - Find all products that have sales using a 'int' key selector
04-IntersectByProductSalesMethod() - Find all products that have sales using a 'int' key selector