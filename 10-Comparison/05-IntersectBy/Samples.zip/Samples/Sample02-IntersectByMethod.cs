﻿namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// IntersectBy() finds DISTINCT products within a collection by comparing a List<string> against a specified property in the collection.
  /// </summary>
  public static void IntersectByMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<Product> list;

    // The list of colors to locate in the list
    List<string> colors = new() { "Red", "Black" };

    // Write Method Syntax Here
    list = products.IntersectBy(colors, row => row.Color).ToList();

    // Display Products
    foreach (Product product in list) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
