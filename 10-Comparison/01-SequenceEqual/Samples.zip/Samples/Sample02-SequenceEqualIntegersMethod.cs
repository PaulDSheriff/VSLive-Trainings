﻿namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// The SequenceEqual() methods compares two different collections to see if the values in each element are equal. When using simple data types such as int, string, a direct comparison between values is performed
  /// </summary>
  public static void SequenceEqualIntegersMethod() {
    List<int> list1 = new() { 5, 2, 3, 4, 5 };
    List<int> list2 = new() { 1, 2, 3, 4, 5 };
    bool value;

    // Write Method Syntax Here
    value = list1.SequenceEqual(list2);

    // Display Value
    Console.WriteLine($"Lists are the same? {value}");

    // Pause for Results
    Console.ReadKey();
  }
}
