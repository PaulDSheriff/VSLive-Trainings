﻿namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// When using a collection of objects, SequenceEqual() performs a comparison to see if the two object references point to the same object
  /// </summary>
  public static void SequenceEqualObjectsQuery() {
    bool value;

    // Create a list of products
    List<Product> list1 = new()
    {
      new Product { ProductID = 1, Name = "Product 1" },
      new Product { ProductID = 2, Name = "Product 2" },
    };
    // Create a list of products
    List<Product> list2 = new()
    {
      new Product { ProductID = 1, Name = "Product 1" },
      new Product { ProductID = 2, Name = "Product 2" },
    };

    // Make Collections the Same
    // list2 = list1;

    // Write Query Syntax Here
    value = (from row in list1
             select row)
             .SequenceEqual(list2);

    // Display Value
    Console.WriteLine($"Lists are the same? {value}");

    // Pause for Results
    Console.ReadKey();
  }
}
