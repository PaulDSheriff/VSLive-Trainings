﻿Description of Samples
--------------------------------------------------
01-SequenceEqualIntegersQuery() - The SequenceEqual() methods compares two different collections to see if the values in each element are equal. When using simple data types such as int, string, a direct comparison between values is performed
02-SequenceEqualIntegersMethod() - The SequenceEqual() methods compares two different collections to see if the values in each element are equal. When using simple data types such as int, string, a direct comparison between values is performed

03-SequenceEqualObjectsQuery() - When using a collection of objects, SequenceEqual() performs a comparison to see if the two object references point to the same object
04-SequenceEqualObjectsMethod() - When using a collection of objects, SequenceEqual() performs a comparison to see if the two object references point to the same object

05-SequenceEqualUsingComparerQuery() - Use an EqualityComparer class to determine if the objects are the same based on the values in properties
06-SequenceEqualUsingComparerMethod() - Use an EqualityComparer class to determine if the objects are the same based on the values in properties
