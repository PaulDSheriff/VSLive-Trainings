﻿namespace LINQSamples;

public class Sample05 {
  /// <summary>
  /// Use an EqualityComparer class to determine if the objects are the same based on the values in properties
  /// </summary>
  public static void SequenceEqualUsingComparerQuery() {
    List<Product> list1 = ProductRepository.GetAll();
    List<Product> list2 = ProductRepository.GetAll();
    ProductComparer pc = new();
    bool value;

    // Remove an element from 'list1' to make the collections different
    //list1.RemoveAt(0);

    // Write Query Syntax Here
    value = (from row in list1
             select row)
             .SequenceEqual(list2, pc);

    // Display Value
    Console.WriteLine($"Lists are the same? {value}");

    // Pause for Results
    Console.ReadKey();
  }
}
