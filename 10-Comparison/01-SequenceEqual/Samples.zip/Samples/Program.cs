﻿using LINQSamples;

// Call Sample Method
Sample01.SequenceEqualIntegersQuery();
//Sample02.SequenceEqualIntegersMethod();
//Sample03.SequenceEqualObjectsQuery();
//Sample04.SequenceEqualObjectsMethod();
//Sample05.SequenceEqualUsingComparerQuery();
//Sample06.SequenceEqualUsingComparerMethod();