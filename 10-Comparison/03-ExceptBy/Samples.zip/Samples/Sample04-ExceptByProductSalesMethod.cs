﻿namespace LINQSamples;

public class Sample04 {
  /// <summary>
  /// Find all products that do not have sales
  /// Change the default comparer for ExceptBy()
  /// </summary>
  public static void ExceptByProductSalesMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<SalesOrder> sales = SalesOrderRepository.GetAll();
    List<Product> list;

    // Write Method Syntax Here
    list = products
      .ExceptBy<Product, int>(sales.Select(row => row.ProductID),
                              row => row.ProductID).ToList();

    // Display Products
    foreach (Product product in list) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
