﻿namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// ExceptBy() finds products within a collection that DO NOT compare to a List<string> against a specified property in the collection.
  /// The default comparer for ExceptBy() is 'string'
  /// </summary>
  public static void ExceptByMethod() {
    List<Product> list;
    // Load all Product Data
    List<Product> products = ProductRepository.GetAll();

    // The list of colors to exclude from the list
    List<string> colors = new() { "Red", "Black" };

    // Write Method Syntax Here
    list = products.ExceptBy(colors, row => row.Color).ToList();

    // Display Products
    foreach (Product product in list) {
      Console.Write(product);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
