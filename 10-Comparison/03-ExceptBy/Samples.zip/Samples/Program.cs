﻿using LINQSamples;

// Call Sample Method
Sample01.ExceptByQuery();
//Sample02.ExceptByMethod();
//Sample03.ExceptByProductSalesQuery();
//Sample04.ExceptByProductSalesMethod();