﻿Description of Samples
--------------------------------------------------
01-ExceptByQuery() - Find products within a collection that DO NOT compare to a List<string> against a specified property in the collection.
02-ExceptByMethod() - Find products within a collection that DO NOT compare to a List<string> against a specified property in the collection.

03-ExceptByProductSalesQuery() - Find all products that do not have sales using a 'int' key selector
04-ExceptByProductSalesMethod() - Find all products that do not have sales using a 'int' key selector