﻿using LINQSamples;

List<Product> products = ProductRepository.GetAll();
List<Product> list;

// Write Query Syntax Here
list = (from row in products
        select row).ToList();

// Display products
foreach (Product product in list) {
  Console.Write(product);
}

// Display Total Count
Console.WriteLine();
Console.WriteLine($"Total Products: {list.Count}");

// Pause for Results
Console.ReadKey();