﻿using AdvWorksAPI.BaseClasses;
using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace AdvWorksAPI.Controllers;

[Route("api/[controller]")]
[ApiController]
public class CustomerController : ControllerBaseAPI
{
  private readonly IRepository<Customer> _Repo;
  private readonly AdvWorksAPIDefaults _Settings;

  public CustomerController(IRepository<Customer> repo, ILogger<CustomerController> logger, IOptionsMonitor<AdvWorksAPIDefaults> settings) : base(logger)
  {
    _Repo = repo;
    _Settings = settings.CurrentValue;
  }

  [HttpGet]
  //[Route("")]
  //[Route("GetAllCustomers")]
  //[Produces("application/xml")]
  [ProducesResponseType(StatusCodes.Status200OK)]
  [ProducesResponseType(StatusCodes.Status404NotFound)]
  [ProducesResponseType(StatusCodes.Status500InternalServerError)]
  public ActionResult<IEnumerable<Customer>> Get()
  {
    ActionResult<IEnumerable<Customer>> ret;
    List<Customer> list;
    InfoMessage = "No Customers are available.";

    try {
      // Intentionally Cause an Exception
      //throw new ApplicationException("ERROR!");

      // Get all data
      list = _Repo.Get();

      if (list != null && list.Count > 0) {
        ret = StatusCode(StatusCodes.Status200OK, list);
      }
      else {
        ret = StatusCode(StatusCodes.Status404NotFound, InfoMessage);
      }
    }
    catch (Exception ex) {
      InfoMessage = _Settings.InfoMessageDefault
        .Replace("{Verb}", "GET").Replace("{ClassName}", "Customer");

      ErrorLogMessage = "Error in CustomerController.Get()";

      ret = HandleException<IEnumerable<Customer>>(ex);
    }

    return ret;
  }

  [HttpGet("{id}")]
  [ProducesResponseType(StatusCodes.Status200OK)]
  [ProducesResponseType(StatusCodes.Status404NotFound)]
  public ActionResult<Customer> Get(int id)
  {
    ActionResult<Customer> ret;
    Customer? entity;

    entity = _Repo.Get(id);
    if (entity != null) {
      // Found data, return '200 OK'
      ret = StatusCode(StatusCodes.Status200OK, entity);
    }
    else {
      // Did not find data, return '404 Not Found'
      ret = StatusCode(StatusCodes.Status404NotFound, $"Can't find Customer with a Customer Id of '{id}'.");
    }

    return ret;
  }

  [HttpGet]
  [Route("SearchByTitle")]
  [ProducesResponseType(StatusCodes.Status200OK)]
  [ProducesResponseType(StatusCodes.Status404NotFound)]
  public ActionResult<IEnumerable<Customer>> SearchByTitle(string title)
  {
    ActionResult<IEnumerable<Customer>> ret;
    List<Customer> list;

    // Get all data
    list = _Repo.Get()
      .Where(row => row.Title == title)
      .OrderBy(row => row.LastName).ToList();

    if (list != null && list.Count > 0) {
      ret = StatusCode(StatusCodes.Status200OK, list);
    }
    else {
      ret = StatusCode(StatusCodes.Status404NotFound, 
        $"No Customers found matching the title '{title}'.");
    }

    return ret;
  }

  [HttpGet]
  [Route("SearchByFirstLast/First/{first}/Last/{last}")]
  [ProducesResponseType(StatusCodes.Status200OK)]
  [ProducesResponseType(StatusCodes.Status404NotFound)]
  public ActionResult<IEnumerable<Customer>> SearchByFirstLast(string first, string last)
  {
    ActionResult<IEnumerable<Customer>> ret;
    List<Customer> list;

    // Get all data
    list = _Repo.Get()
      .Where(row => row.FirstName.Contains(first, StringComparison.InvariantCultureIgnoreCase) &&
             row.LastName.Contains(last, StringComparison.InvariantCultureIgnoreCase))
      .OrderBy(row => row.LastName).ToList();

    if (list != null && list.Count > 0) {
      ret = StatusCode(StatusCodes.Status200OK, list);
    }
    else {
      ret = StatusCode(StatusCodes.Status404NotFound,
        "No Customers found matching the criteria passed in.");
    }

    return ret;
  }

  [HttpPost]
  //[Consumes("application/xml")]
  //[Produces("application/xml")]
  [ProducesResponseType(StatusCodes.Status201Created)]
  public ActionResult<Customer> Post(Customer entity)
  {
    ActionResult<Customer> ret;

    // TODO: Insert Data into Data Store
    entity.ModifiedDate = DateTime.Now;

    ret = StatusCode(StatusCodes.Status201Created, entity);

    return ret;
  }
}
