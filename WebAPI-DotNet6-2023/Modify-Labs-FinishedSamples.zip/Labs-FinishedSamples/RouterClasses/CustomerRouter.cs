﻿using AdvWorksAPI.BaseClasses;
using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.RepositoryLayer;
using AdvWorksAPI.ValidationClasses;

namespace AdvWorksAPI.RouterClasses;

public class CustomerRouter : RouterBase
{
  private readonly IRepository<Customer> _Repo;
  private readonly AdvWorksAPIDefaults _Settings;

  public CustomerRouter(IRepository<Customer> repo, ILogger<CustomerRouter> logger, AdvWorksAPIDefaults settings) : base(logger)
  {
    UrlFragment = "api/Customer";
    TagName = "Customer";
    _Repo = repo;
    _Settings = settings;
  }

  /// <summary>
  /// Add routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app)
  {
    app.MapGet($"/{UrlFragment}", () => Get())
       .WithTags(TagName)
       .Produces(200)
       .Produces<List<Customer>>()
       .Produces(404)
       .Produces(500);
    //.RequireAuthorization("GetCustomersClaim");

    app.MapGet($"/{UrlFragment}/{{id:int}}", (int id) => Get(id))
       .WithTags(TagName)
       .Produces(200)
       .Produces<Customer>()
       .Produces(404);

    app.MapPost($"/{UrlFragment}", (Customer entity) => Insert(entity))
       .WithTags(TagName)
       .Produces(200)
       .Produces<Customer>()
       .Produces(404)
       .Produces(500);

    app.MapPut($"/{UrlFragment}/{{id:int}}", (int id, Customer entity) => Update(id, entity))
       .WithTags(TagName)
       .Produces(200)
       .Produces<Customer>()
       .Produces(404)
       .Produces(500);

    app.MapDelete($"/{UrlFragment}/{{id:int}}", (int id) => Delete(id))
       .WithTags(TagName)
       .Produces(200)
       .Produces<Customer>()
       .Produces(404)
       .Produces(500);
  }

  protected virtual IResult Get()
  {
    IResult ret;
    List<Customer> list;
    InfoMessage = "No Customers Found.";

    try {
      // Intentionally Cause an Exception
      //throw new ApplicationException("ERROR!");

      list = _Repo.Get();

      //list.Clear();
      if (list == null || list.Count == 0) {
        ret = Results.NotFound(InfoMessage);
      }
      else {
        ret = Results.Ok(list);
      }
    }
    catch (Exception ex) {
      // Return generic message for the user
      InfoMessage = _Settings.InfoMessageDefault
          .Replace("{Verb}", "GET")
          .Replace("{ClassName}", "Customer");

      ErrorLogMessage = "Error in CustomerRouter.Get()";

      ret = HandleException(ex);
    }

    return ret;
  }

  protected virtual IResult Get(int id)
  {
    Customer? entity;

    // Attempt to get a single product
    entity = _Repo.Get(id);
    if (entity == null) {
      return Results.NotFound($"Customer with Customer ID = '{id}' Not Found.");
    }
    else {
      return Results.Ok(entity);
    }
  }

  protected virtual IResult Insert(Customer entity)
  {
    IResult ret;
    Dictionary<string, string[]> msgs;

    // Serialize entity
    SerializeEntity<Customer>(entity);

    try {
      if (entity != null) {
        // Validate the Entity object
        msgs = ValidationHelper.Validate<Customer>(entity);
        if (msgs == null || msgs.Count == 0) {
          // Attempt to update the database
          entity = _Repo.Insert(entity);

          // Return a '201 Created' with the new entity
          ret = Results.Ok(entity);
        }
        else {
          ret = Results.ValidationProblem(msgs);
        }
      }
      else {
        InfoMessage = $"Customer object passed to POST method is empty.";
        // Return a '400 Bad Request'
        ret = Results.BadRequest(InfoMessage);
        // Log an informational message
        _Logger.LogInformation("{InfoMessage}", InfoMessage);
      }
    }
    catch (Exception ex) {
      // Return generic message for the user
      InfoMessage = _Settings.InfoMessageDefault
        .Replace("{Verb}", "POST")
        .Replace("{ClassName}", "Customer");

      // Log the exception and return a '500' status
      ErrorLogMessage = $"CustomerRouter.Post() - Exception trying to insert a new customer: {EntityAsJson}";

      ret = HandleException(ex);
    }

    return ret;
  }

  protected virtual IResult Update(int id, Customer entity)
  {
    IResult ret;
    Dictionary<string, string[]> msgs;

    // Serialize entity
    SerializeEntity<Customer>(entity);

    try {
      if (entity != null) {
        // Validate the Entity object
        msgs = ValidationHelper.Validate<Customer>(entity);
        if (msgs == null || msgs.Count == 0) {
          // Attempt to locate the data to update
          Customer? current = _Repo.Get(id);

          if (current != null) {
            // Combine changes into current record
            entity = _Repo.SetValues(current, entity);

            // Attempt to update the database
            current = _Repo.Update(current);

            // Pass back a '200 Ok'
            ret = Results.Ok(current);
          }
          else {
            InfoMessage = $"Can't find Customer Id '{id}' to update.";
            // Did not find data, return '404 Not Found'
            ret = Results.NotFound(InfoMessage);
            // Log an informational message
            _Logger.LogInformation("{InfoMessage}", InfoMessage);
          }
        }
        else {
          ret = Results.ValidationProblem(msgs);
        }
      }
      else {
        InfoMessage = $"Customer object passed to PUT method is empty.";
        // Return a '400 Bad Request'
        ret = Results.BadRequest(InfoMessage);
        // Log an informational message
        _Logger.LogInformation("{InfoMessage}", InfoMessage);
      }
    }
    catch (Exception ex) {
      // Return generic message for the user
      InfoMessage = _Settings.InfoMessageDefault
        .Replace("{Verb}", "PUT")
        .Replace("{ClassName}", "Customer");

      // Log the exception and return a '500' status
      ErrorLogMessage = $"CustomerRouter.Put() - Exception trying to update customer: {EntityAsJson}";

      ret = HandleException(ex);
    }

    return ret;
  }

  protected virtual IResult Delete(int id)
  {
    IResult ret;

    try {
      // Attempt to delete from the database    
      if (_Repo.Delete(id)) {
        // Return '204 No Content'
        ret = Results.NoContent();
      }
      else {
        InfoMessage = $"Can't find Customer Id '{id}' to delete.";
        // Did not find data, return '404 Not Found'
        ret = Results.NotFound(InfoMessage);
        // Log an informational message
        _Logger.LogInformation("{InfoMessage}", InfoMessage);
      }
    }
    catch (Exception ex) {
      // Return generic message for the user
      InfoMessage = _Settings.InfoMessageDefault
        .Replace("{Verb}", "DELETE")
        .Replace("{ClassName}", "Customer");

      // Log the exception and return a '500' status
      ErrorLogMessage = $"CustomerRouter.Delete() - Exception trying to delete CustomerID: '{id}'.";

      ret = HandleException(ex);
    }

    return ret;
  }
}
