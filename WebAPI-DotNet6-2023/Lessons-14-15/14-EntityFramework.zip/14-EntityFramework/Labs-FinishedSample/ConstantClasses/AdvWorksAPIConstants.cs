﻿namespace AdvWorksAPI.ConstantClasses;

public class AdvWorksAPIConstants
{
  public const string CORS_POLICY = "AdvWorksAPICorsPolicy";
}
