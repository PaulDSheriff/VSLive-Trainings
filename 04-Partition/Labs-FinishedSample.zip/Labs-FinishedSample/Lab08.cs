﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab08() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    List<int?> list;

    // Query Syntax
    list = (from row in songs
            orderby row.Rating
            select row.Rating).Distinct().ToList();

    // Method Syntax
    list = songs.OrderBy(row => row.Rating)
            .Select(row => row.Rating).Distinct().ToList();

    // Display data
    foreach (int? id in list) {
      Console.WriteLine(id);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Ratings: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
