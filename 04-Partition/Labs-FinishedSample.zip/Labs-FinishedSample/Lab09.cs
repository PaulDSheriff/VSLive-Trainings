﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab09() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    List<Song> list;

    // Query Syntax
    list = (from row in songs
            orderby row.Rating
            select row).DistinctBy(row => row.Rating).ToList();

    // Method Syntax
    //list = songs.OrderBy(row => row.Rating)
    //       .DistinctBy(row => row.Rating).ToList();

    // Display data
    foreach (Song song in list) {
      Console.Write(song);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Ratings: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
