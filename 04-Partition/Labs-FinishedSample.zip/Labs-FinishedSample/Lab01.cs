﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab01() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    List<Song> list;

    // Query Syntax
    list = (from row in songs
            orderby row.SongName
            select row).Skip(1000).ToList();

    // Method Syntax
    //list = songs.OrderBy(row => row.SongName).Skip(1000).ToList();

    // Display data
    foreach (Song song in list) {
      Console.Write(song);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Songs: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
