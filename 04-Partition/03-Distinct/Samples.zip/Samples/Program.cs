﻿using LINQSamples;

// Call Sample Method
Sample01.DistinctQuery();
//Sample02.DistinctMethod();
//Sample03.DistinctByQuery();
//Sample04.DistinctByMethod();