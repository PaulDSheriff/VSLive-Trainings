﻿Description of Samples
--------------------------------------------------
01-DistinctQuery() - The Distinct() operator finds all unique values within a collection
02-DistinctMethod() - The Distinct() operator finds all unique values within a collection

03-DistinctByQuery() - The DistinctBy() operator finds all unique values within a collection using a property and returns the objects
04-DistinctByMethod() - The DistinctBy() operator finds all unique values within a collection using a property and returns the objects