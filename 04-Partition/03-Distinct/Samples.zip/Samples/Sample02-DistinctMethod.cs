﻿namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// The Distinct() operator finds all unique values within a collection.
  /// </summary>
  public static void DistinctMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<string> list;

    // Write Method Syntax Here
    list = products.Select(row => row.Color)
      .Distinct().OrderBy(row => row).ToList();

    // Display Colors
    foreach (string item in list) {
      Console.Write(item);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Colors: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
