﻿Description of Samples
--------------------------------------------------
01-TakeQuery() - Use Take() to select a specified number of items from the beginning of a collection
02-TakeMethod() - Use Take() to select a specified number of items from the beginning of a collection

03-TakeLastQuery() - Use TakeLast() to get the specified number of items from the end of the collection
04-TakeLastMethod() - Use TakeLast() to get the specified number of items from the end of the collection

05-TakeRangeQuery() - Use Take(n..n) to select items based on a specified range
06-TakeRangeMethod() - Use Take(n..n) to select items based on a specified range

07-TakeLastRange() - Use Take(^n..^n) to select items based on a range from the end of the collection

08-TakeWhileQuery() - Use TakeWhile() to select a set of items from the beginning of a collection based on a condition
09-TakeWhileMethod() - Use TakeWhile() to select a set of items from the beginning of a collection based on a condition