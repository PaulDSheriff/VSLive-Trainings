﻿namespace LINQSamples;

public class Sample06 {
  /// <summary>
  /// Use Take(n..n) to select items based on a specified range
  /// </summary>
  public static void TakeRangeMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<Product> list;

    // Write Query Syntax Here
    list = products.OrderBy(row => row.Name).Take(5..8).ToList();

    // Display products
    foreach (Product product in list) {
      Console.Write(product);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
