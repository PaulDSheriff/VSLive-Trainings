﻿using LINQSamples;

// Call Sample Method
Sample01.TakeQuery();
Sample02.TakeMethod();
Sample03.TakeLastQuery();
Sample04.TakeRangeMethod();
Sample05.TakeRangeQuery();
Sample06.TakeRangeMethod();
Sample07.TakeLastRange();
Sample08.TakeWhileQuery();
Sample09.TakeWhileMethod();