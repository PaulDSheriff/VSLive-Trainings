﻿namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// Use Take() to select a specified number of items from the beginning of a collection
  /// </summary>
  public static void TakeMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<Product> list;

    // Write Query Syntax Here
    list = products.OrderBy(row => row.Name).Take(5).ToList();

    // Display products
    foreach (Product product in list) {
      Console.Write(product);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
