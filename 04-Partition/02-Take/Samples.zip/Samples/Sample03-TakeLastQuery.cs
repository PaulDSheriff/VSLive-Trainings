﻿namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// Use TakeLast() to get the specified number of items from the end of the collection
  /// </summary>
  public static void TakeLastQuery() {
    List<Product> products = ProductRepository.GetAll();
    List<Product> list;

    // Write Query Syntax Here
    list = (from row in products
            orderby row.Name
            select row).TakeLast(5).ToList();

    // Display products
    foreach (Product product in list) {
      Console.Write(product);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
