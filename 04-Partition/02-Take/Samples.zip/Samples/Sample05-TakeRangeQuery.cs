﻿namespace LINQSamples;

public class Sample05 {
  /// <summary>
  /// Use Take(n..n) to select items based on a specified range
  /// </summary>
  public static void TakeRangeQuery() {
    List<Product> products = ProductRepository.GetAll();
    List<Product> list;

    // Write Query Syntax Here
    list = (from row in products
            orderby row.Name
            select row).Take(5..8).ToList();

    // Display products
    foreach (Product product in list) {
      Console.Write(product);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
