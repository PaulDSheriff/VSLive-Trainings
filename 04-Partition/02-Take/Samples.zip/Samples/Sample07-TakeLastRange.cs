﻿namespace LINQSamples;

public class Sample07 {
  /// <summary>
  /// Use Take(^n..^n) to select items based on a range from the end of the collection
  /// </summary>
  public static void TakeLastRange() {
    List<Product> products = ProductRepository.GetAll();
    List<Product> list;

    // Write Query Syntax Here
    list = products.OrderBy(row => row.Name).Take(^8..^5).ToList();

    // Display products
    foreach (Product product in list) {
      Console.Write(product);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
