﻿namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// Use SkipLast() to return all items from the list, minus the last n items
  /// </summary>
  public static void SkipLastQuery() {
    List<Product> products = ProductRepository.GetAll();
    List<Product> list;

    // Write Query Syntax Here
    list = (from row in products
            orderby row.Name
            select row).SkipLast(30).ToList();

    // Display products
    foreach (Product product in list) {
      Console.Write(product);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
