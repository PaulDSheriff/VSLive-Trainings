﻿using LINQSamples;

// Call Sample Method
Sample01.SkipQuery();
//Sample02.SkipMethod();
//Sample03.SkipLastQuery();
//Sample04.SkipLastMethod();
//Sample05.SkipWhileQuery();
//Sample06.SkipWhileMethod();