﻿namespace LINQSamples;

public class Sample02 {
  /// <summary>
  /// Use Skip() to move past a specified number of items from the beginning of a collection
  /// </summary>
  public static void SkipMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<Product> list;

    // Write Method Syntax Here
    list = products.OrderBy(row => row.Name).Skip(30).ToList();

    // Display products
    foreach (Product product in list) {
      Console.Write(product);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
