﻿namespace LINQSamples;

public class Sample05 {
  /// <summary>
  /// Use SkipWhile() to move past a specified number of items from the beginning of a collection based on a condition
  /// </summary>
  public static void SkipWhileQuery() {
    List<Product> products = ProductRepository.GetAll();
    List<Product> list;

    // Write Query Syntax Here
    list = (from row in products
            orderby row.Name
            select row)
            .SkipWhile(row => row.Name.StartsWith("A")).ToList();

    // Display products
    foreach (Product product in list) {
      Console.Write(product);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
