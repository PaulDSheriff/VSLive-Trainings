﻿Description of Samples
--------------------------------------------------
01-SkipQuery() - Use Skip() to move past a specified number of items from the beginning of a collection
02-SkipMethod() - Use Skip() to move past a specified number of items from the beginning of a collection

03-SkipLastQuery() - Use SkipLast() to return all items from the list, minus the last n items
04-SkipLastMethod() - Use SkipLast() to return all items from the list, minus the last n items

05-SkipWhileQuery() - Use SkipWhile() to move past a specified number of items from the beginning of a collection based on a condition
06-SkipWhileMethod() - Use SkipWhile() to move past a specified number of items from the beginning of a collection based on a condition