﻿namespace LINQSamples;

public class Sample06 {
  /// <summary>
  /// Use SkipWhile() to move past a specified number of items from the beginning of a collection based on a true condition
  /// </summary>
  public static void SkipWhileMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<Product> list;

    // Write Method Syntax Here
    list = products.OrderBy(row => row.Name)
      .SkipWhile(row => row.Name.StartsWith("A")).ToList();

    // Display products
    foreach (Product product in list) {
      Console.Write(product);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
