namespace XamlBindingMAUI.Views;

public partial class CheckBoxIsEnabledView : ContentPage
{
	public CheckBoxIsEnabledView()
	{
		InitializeComponent();
	}
}