namespace XamlBindingMAUI.Views;

public partial class CheckBoxIsVisibleView : ContentPage
{
	public CheckBoxIsVisibleView()
	{
		InitializeComponent();
	}
}