namespace XamlBindingMAUI.Views;

public partial class SwitchView : ContentPage
{
	public SwitchView()
	{
		InitializeComponent();
	}
}