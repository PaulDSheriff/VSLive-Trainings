namespace XamlBindingMAUI.Views;

public partial class PickerToLabelView : ContentPage
{
	public PickerToLabelView()
	{
		InitializeComponent();
	}
}