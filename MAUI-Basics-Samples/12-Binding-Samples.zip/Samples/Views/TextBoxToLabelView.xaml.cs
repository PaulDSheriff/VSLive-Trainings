namespace XamlBindingMAUI.Views;

public partial class TextBoxToLabelView : ContentPage
{
	public TextBoxToLabelView()
	{
		InitializeComponent();
	}
}