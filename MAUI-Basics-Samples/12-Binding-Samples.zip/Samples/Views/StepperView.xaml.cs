namespace XamlBindingMAUI.Views;

public partial class StepperView : ContentPage
{
	public StepperView()
	{
		InitializeComponent();
	}
}