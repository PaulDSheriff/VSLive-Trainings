namespace XamlBasicsMAUI.Views;

public partial class LabelView : ContentPage
{
	public LabelView()
	{
		InitializeComponent();
	}
}