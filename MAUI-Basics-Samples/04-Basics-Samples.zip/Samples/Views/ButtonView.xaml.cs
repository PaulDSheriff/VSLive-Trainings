namespace XamlBasicsMAUI.Views;

public partial class ButtonView : ContentPage
{
  public ButtonView()
  {
    InitializeComponent();
  }

  private async void ClickMeButton_Clicked(object sender, EventArgs e)
  {
    await DisplayAlert("Click!", "You Clicked Me!", "OK");
  }

  private void ContentPage_Loaded(object sender, EventArgs e)
  {
    this.ClickMeButton.Text = "Click Me NOW!";
  }
}