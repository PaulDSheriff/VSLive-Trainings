namespace XamlBasicsMAUI.Views;

public partial class EntryView : ContentPage
{
	public EntryView()
	{
		InitializeComponent();
	}
}