namespace XamlStackLayoutMAUI.Views;

public partial class FlexLayoutView : ContentPage
{
	public FlexLayoutView()
	{
		InitializeComponent();
	}
}