namespace XamlStackLayoutMAUI.Views;

public partial class TextAlignmentView : ContentPage
{
	public TextAlignmentView()
	{
		InitializeComponent();
	}
}