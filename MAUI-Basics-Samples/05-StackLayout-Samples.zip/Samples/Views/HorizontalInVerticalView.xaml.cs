namespace XamlStackLayoutMAUI.Views;

public partial class HorizontalInVerticalView : ContentPage
{
	public HorizontalInVerticalView()
	{
		InitializeComponent();
	}
}