namespace XamlStackLayoutMAUI.Views;

public partial class MarginPaddingView : ContentPage
{
	public MarginPaddingView()
	{
		InitializeComponent();
	}
}