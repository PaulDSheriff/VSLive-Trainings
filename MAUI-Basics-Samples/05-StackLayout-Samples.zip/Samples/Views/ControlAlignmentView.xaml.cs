namespace XamlStackLayoutMAUI.Views;

public partial class ControlAlignmentView : ContentPage
{
	public ControlAlignmentView()
	{
		InitializeComponent();
	}
}