namespace XamlStackLayoutMAUI.Views;

public partial class NestedStackLayoutView : ContentPage
{
	public NestedStackLayoutView()
	{
		InitializeComponent();
	}
}