namespace XamlStackLayoutMAUI.Views;

public partial class StackLayoutView : ContentPage
{
	public StackLayoutView()
	{
		InitializeComponent();
	}
}