namespace XamlStackLayoutMAUI.Views;

public partial class VerticalStackLayoutView : ContentPage
{
	public VerticalStackLayoutView()
	{
		InitializeComponent();
	}
}