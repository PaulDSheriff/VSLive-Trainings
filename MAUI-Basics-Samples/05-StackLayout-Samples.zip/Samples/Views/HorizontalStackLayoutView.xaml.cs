namespace XamlStackLayoutMAUI.Views;

public partial class HorizontalStackLayoutView : ContentPage
{
	public HorizontalStackLayoutView()
	{
		InitializeComponent();
	}
}