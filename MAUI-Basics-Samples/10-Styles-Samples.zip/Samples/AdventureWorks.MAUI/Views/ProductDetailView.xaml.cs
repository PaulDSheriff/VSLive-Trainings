namespace AdventureWorks.MAUI.Views;

public partial class ProductDetailView : ContentPage
{
	public ProductDetailView()
	{
		InitializeComponent();
	}
}