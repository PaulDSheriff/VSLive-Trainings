namespace AdventureWorks.MAUI.Resources.Styles;

public partial class StandardStyles : ResourceDictionary
{
	public StandardStyles()
	{
		InitializeComponent();
	}
}