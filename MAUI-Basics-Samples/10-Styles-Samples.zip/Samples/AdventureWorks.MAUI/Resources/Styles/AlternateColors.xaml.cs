namespace AdventureWorks.MAUI.Resources.Styles;

public partial class AlternateColors : ResourceDictionary
{
	public AlternateColors()
	{
		InitializeComponent();
	}
}