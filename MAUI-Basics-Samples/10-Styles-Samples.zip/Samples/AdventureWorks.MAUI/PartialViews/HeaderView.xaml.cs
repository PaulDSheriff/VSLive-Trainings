namespace AdventureWorks.MAUI.PartialViews;

public partial class HeaderView : ContentView
{
	public HeaderView()
	{
		InitializeComponent();
	}
}