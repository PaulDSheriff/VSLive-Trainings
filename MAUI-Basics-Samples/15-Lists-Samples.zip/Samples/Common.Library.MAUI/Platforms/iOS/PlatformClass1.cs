﻿namespace Common.Library.MAUI
{
  // All the code in this file is only included on iOS.
  public class PlatformClass1
  {
  }
}