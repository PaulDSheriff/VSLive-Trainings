namespace XamlTabNavigation.Views;

public partial class UserDetailView : ContentPage
{
	public UserDetailView()
	{
		InitializeComponent();
	}
}