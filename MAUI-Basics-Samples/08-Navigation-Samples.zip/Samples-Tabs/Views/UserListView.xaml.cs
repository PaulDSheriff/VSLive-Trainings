namespace XamlTabNavigation.Views;

public partial class UserListView : ContentPage
{
  public UserListView()
  {
    InitializeComponent();
  }

  private void UserDetail_Click(object sender, EventArgs e)
  {
    Shell.Current.GoToAsync(nameof(Views.UserDetailView));
  }
}