namespace XamlBasicsMAUI.Views;

public partial class BoxViewView : ContentPage
{
	public BoxViewView()
	{
		InitializeComponent();
	}
}