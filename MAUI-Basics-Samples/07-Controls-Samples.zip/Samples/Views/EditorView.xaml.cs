namespace XamlBasicsMAUI.Views;

public partial class EditorView : ContentPage
{
	public EditorView()
	{
		InitializeComponent();
	}
}