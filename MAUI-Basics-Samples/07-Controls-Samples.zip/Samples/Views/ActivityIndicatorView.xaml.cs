namespace XamlBasicsMAUI.Views;

public partial class ActivityIndicatorView : ContentPage
{
	public ActivityIndicatorView()
	{
		InitializeComponent();
	}
}