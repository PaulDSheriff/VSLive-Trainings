namespace XamlBasicsMAUI.Views;

public partial class ImageView : ContentPage
{
	public ImageView()
	{
		InitializeComponent();
	}
}