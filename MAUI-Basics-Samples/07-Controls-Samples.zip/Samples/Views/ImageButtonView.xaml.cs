namespace XamlBasicsMAUI.Views;

public partial class ImageButtonView : ContentPage
{
	public ImageButtonView()
	{
		InitializeComponent();
	}
}