﻿namespace XamlGridLayoutMAUI
{
  public partial class MainPage : ContentPage
  {
    public MainPage()
    {
      InitializeComponent();
    }
  }
}