namespace XamlGridLayoutMAUI.Views;

public partial class GridRowsColumns : ContentPage
{
	public GridRowsColumns()
	{
		InitializeComponent();
	}
}