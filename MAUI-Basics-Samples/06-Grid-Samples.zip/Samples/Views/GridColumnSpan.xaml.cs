namespace XamlGridLayoutMAUI.Views;

public partial class GridColumnSpan : ContentPage
{
	public GridColumnSpan()
	{
		InitializeComponent();
	}
}