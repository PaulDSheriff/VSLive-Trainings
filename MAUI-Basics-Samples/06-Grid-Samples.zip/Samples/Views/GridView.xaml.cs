namespace XamlGridLayoutMAUI.Views;

public partial class GridView : ContentPage
{
	public GridView()
	{
		InitializeComponent();
	}
}