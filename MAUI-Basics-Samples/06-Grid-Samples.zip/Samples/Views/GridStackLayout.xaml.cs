namespace XamlGridLayoutMAUI.Views;

public partial class GridStackLayout : ContentPage
{
	public GridStackLayout()
	{
		InitializeComponent();
	}
}