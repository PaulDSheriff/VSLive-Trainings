﻿namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// Filter products using where. If the data is not found, an empty list is returned
  /// </summary>
  public static void WhereQuery() {
    List<Product> products = ProductRepository.GetAll();
    List<Product> list;

    // Write Query Syntax Here
    list = (from row in products
            where row.Name.StartsWith("S")
            select row).ToList();

    // Display products
    foreach (Product product in list) {
      Console.Write(product);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
