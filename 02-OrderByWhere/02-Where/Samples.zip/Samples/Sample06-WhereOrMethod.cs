﻿namespace LINQSamples;

public class Sample06 {
  /// <summary>
  /// Filter products using where with two fields and the || operator. If the data is not found, an empty list is returned
  /// </summary>
  public static void WhereOrMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<Product> list;

    // Write Method Syntax Here
    list = products.Where(row => row.Color == "Black" ||
                                 row.StandardCost < 100).ToList();

    // Display products
    foreach (Product product in list) {
      Console.Write(product);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
