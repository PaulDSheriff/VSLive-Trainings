﻿using LINQSamples;

// Call Sample
Sample01.WhereQuery();
//Sample02.WhereMethod();
//Sample03.WhereAndQuery();
//Sample04.WhereAndMethod();
//Sample05.WhereOrQuery();
//Sample06.WhereOrMethod();