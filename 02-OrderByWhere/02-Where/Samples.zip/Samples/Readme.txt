﻿Description of Samples
--------------------------------------------------
01-WhereQuery() - Filter products using where. If the data is not found, an empty list is returned
02-WhereMethod() - Filter products using where. If the data is not found, an empty list is returned

03-WhereAndQuery() - Filter products using where with two fields and the && operator. If the data is not found, an empty list is returned
04-WhereAndMethod() - Filter products using where with two fields and the && operator. If the data is not found, an empty list is returned

05-WhereOrQuery() - Filter products using where with two fields and the || operator. If the data is not found, an empty list is returned
06-WhereOrMethod() - Filter products using where with two fields and the || operator. If the data is not found, an empty list is returned
