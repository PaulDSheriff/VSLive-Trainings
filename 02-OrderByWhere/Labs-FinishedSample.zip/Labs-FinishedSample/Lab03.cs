﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab03() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    List<Song> list;

    // Query Syntax
    list = (from row in songs
            orderby row.Artist descending, row.SongName
            select row).ToList();

    // Method Syntax
    //list = songs.OrderByDescending(row => row.Artist).ThenBy(row => row.SongName).ToList();

    // Display Songs
    foreach (Song song in list) {
      Console.WriteLine(song);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Songs: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
