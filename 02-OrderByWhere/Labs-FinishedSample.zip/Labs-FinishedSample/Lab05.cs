﻿using LINQLab.EntityClasses;
using LINQLab.RepositoryClasses;

namespace LINQLab;

public partial class Program {
  public static void Lab05() {
    // Declare variables and fill data
    List<Song> songs = SongRepository.GetAll();
    List<Song> list;

    // Query Syntax
    list = (from row in songs
            where row.Year == 2005 && row.Plays > 20
            orderby row.SongName
            select row).ToList();

    // Method Syntax
    //list = songs.Where(row => row.Year == 2005 && row.Plays > 20).OrderBy(row => row.SongName).ToList();

    // Display Songs
    foreach (Song song in list) {
      Console.Write(song);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Songs: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
