﻿namespace LINQSamples;

public class Sample01 {
  /// <summary>
  /// Order products by Name
  /// </summary>
  public static void OrderByQuery() {
    List<Product> products = ProductRepository.GetAll();
    List<Product> list;

    // Write Query Syntax Here
    list = (from row in products
            orderby row.Name
            select row).ToList();

    // Display products
    foreach (Product product in list) {
      Console.Write(product);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
