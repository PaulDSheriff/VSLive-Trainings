﻿Description of the Samples
--------------------------------------------------
01-OrderByQuery() - Order products by Name
02-OrderByMethod() - Order products by Name

03-OrderByDescendingQuery() - Order products by name in descending order
04-OrderByDescendingMethod() - Order products by name in descending order

05-OrderByTwoFieldsQuery() - Order products by Color descending, then Name
06-OrderByTwoFieldsMethod() - Order products by Color descending, then Name

07-OrderByTwoFieldsDescendingMethod() - Order products by Color descending, then Name Descending