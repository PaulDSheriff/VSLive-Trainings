﻿namespace LINQSamples;

public class Sample03 {
  /// <summary>
  /// Order products by name in descending order
  /// </summary>
  public static void OrderByDescendingQuery() {
    List<Product> products = ProductRepository.GetAll();
    List<Product> list;

    // Write Query Syntax Here
    list = (from row in products
            orderby row.Name descending
            select row).ToList();

    // Display products
    foreach (Product product in list) {
      Console.Write(product);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
