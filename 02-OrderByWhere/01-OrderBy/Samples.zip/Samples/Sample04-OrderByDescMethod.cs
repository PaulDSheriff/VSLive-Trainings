﻿namespace LINQSamples;

public class Sample04 {
  /// <summary>
  /// Order products by name in descending order
  /// </summary>
  public static void OrderByDescendingMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<Product> list;

    // Write Method Syntax Here
    list = products.OrderByDescending(row => row.Name).ToList();

    // Display products
    foreach (Product product in list) {
      Console.Write(product);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
