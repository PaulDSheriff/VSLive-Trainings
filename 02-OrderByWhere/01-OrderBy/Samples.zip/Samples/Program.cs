﻿using LINQSamples;

// Call Sample
Sample01.OrderByQuery();
//Sample02.OrderByMethod();
//Sample03.OrderByDescendingQuery();
//Sample04.OrderByDescendingMethod();
//Sample05.OrderByTwoFieldsQuery();
//Sample06.OrderByTwoFieldsMethod();
//Sample07.OrderByTwoFieldsDescendingMethod();