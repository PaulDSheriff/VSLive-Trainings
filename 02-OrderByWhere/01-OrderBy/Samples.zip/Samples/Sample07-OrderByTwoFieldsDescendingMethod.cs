﻿namespace LINQSamples;

public class Sample07 {
  /// <summary>
  /// Order products by Color descending, then Name Descending
  /// </summary>
  public static void OrderByTwoFieldsDescendingMethod() {
    List<Product> products = ProductRepository.GetAll();
    List<Product> list;

    // Write Method Syntax Here
    list = products.OrderByDescending(row => row.Color)
                   .ThenByDescending(row => row.Name).ToList();

    // Display products
    foreach (Product product in list) {
      Console.Write(product);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Products: {list.Count}");

    // Pause for Results
    Console.ReadKey();
  }
}
