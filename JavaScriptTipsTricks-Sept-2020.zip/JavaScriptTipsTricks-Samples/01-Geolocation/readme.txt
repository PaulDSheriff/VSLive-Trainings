Geolocation API
-------------------------------
01 - Get Lat/Long
02 - Get Lat/Long With Error Handling
03 - Get Lat/Long With Options
04 - Create a Geolocation Closure
  Separate functionality from displaying values
05 - Using watchPosition()
  Need to test this on a cell phone