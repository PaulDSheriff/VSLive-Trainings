﻿Upload Multiple Files Asynchronously
---------------------------------------
These samples show how to upload multiple files asynchronously and display a progress bar

Add title and description on client
Modified controller to get title and description information
