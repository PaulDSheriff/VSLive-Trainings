﻿using System.IO;
using System.Web;
using System.Web.Http;

namespace UploadMultipleFilesAsync.Controllers
{
  public class FileUploadController : ApiController
  {
    [HttpPost]
    public int UploadFile()
    {
      byte[] contents;

      // Retrieve file to upload
      HttpPostedFile fileToUpload = HttpContext.Current.Request.Files["fileUploadObject"];

      if (fileToUpload != null && fileToUpload.ContentLength > 0)
      {
        // Get the uploaded file contents
        using (MemoryStream ms = new MemoryStream())
        {
          fileToUpload.InputStream.CopyTo(ms);
          ms.Position = 0;
          contents = ms.ToArray();
        }

        // Gather file information into anonymous type
        var fileInfo = new
        {
          ContentLength = fileToUpload.ContentLength,
          ContentType = fileToUpload.ContentType,
          FilePath = Path.GetDirectoryName(fileToUpload.FileName),
          FileName = Path.GetFileName(fileToUpload.FileName),
          Contents = contents
        };

        // Write File to Server File System
        var file = HttpContext.Current.Server.MapPath("/UploadedFiles/" + fileInfo.FileName);
        System.Diagnostics.Debug.WriteLine(file);
        File.WriteAllBytes(file, contents);
      }

      return 0;
    }
  }
}